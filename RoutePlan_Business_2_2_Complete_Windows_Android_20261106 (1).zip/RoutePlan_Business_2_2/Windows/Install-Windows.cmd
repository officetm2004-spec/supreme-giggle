@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
if errorlevel 1 (
 echo Installation failed. Keep the error message and contact your administrator.
 pause
 exit /b 1
)
endlocal
