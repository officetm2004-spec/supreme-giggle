param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'This installer is for Windows 10/11.' }
$source = $PSScriptRoot
$clientRoot = Join-Path $env:LOCALAPPDATA 'RoutePlanBusiness\Client'
New-Item -ItemType Directory -Force -Path $clientRoot | Out-Null
foreach ($name in @('RoutePlan.exe','Check-Connection.ps1','Check-Connection.cmd','Uninstall.ps1')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $clientRoot $name) -Force
}
$config = Join-Path $clientRoot 'server.txt'
if (-not (Test-Path -LiteralPath $config)) {
    Copy-Item -LiteralPath (Join-Path $source 'server.txt') -Destination $config
}
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
$menu = Join-Path $programs 'RoutePlan Business'
New-Item -ItemType Directory -Force -Path $menu | Out-Null
$shell = New-Object -ComObject WScript.Shell
foreach ($path in @((Join-Path $desktop 'RoutePlan Business.lnk'), (Join-Path $menu 'RoutePlan Business.lnk'))) {
    $shortcut = $shell.CreateShortcut($path)
    $shortcut.TargetPath = Join-Path $clientRoot 'RoutePlan.exe'
    $shortcut.WorkingDirectory = $clientRoot
    $shortcut.IconLocation = (Join-Path $clientRoot 'RoutePlan.exe') + ',0'
    $shortcut.Description = 'RoutePlan Business - shared sales and delivery workspace'
    $shortcut.Save()
}
Write-Host 'RoutePlan Business installed. Desktop and Start menu shortcuts are ready.'
Write-Host 'Your server address and browser profile are preserved when reinstalling.'
if (-not $NoLaunch) { Start-Process -FilePath (Join-Path $clientRoot 'RoutePlan.exe') }
