$ErrorActionPreference = 'Stop'
$config = Join-Path $PSScriptRoot 'server.txt'
$origin = (Get-Content -LiteralPath $config -Raw).Trim().TrimEnd('/')
$uri = [uri]$origin
if (-not $uri.IsAbsoluteUri -or $uri.Scheme -notin @('https','http') -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') { throw 'Use a server origin only in server.txt.' }
$report = [ordered]@{ checkedAt = [DateTime]::UtcNow.ToString('o'); clientVersion = '2.2-business'; server = $origin; windowsVersion = [Environment]::OSVersion.VersionString; checks = @(); scope = 'Server reachability only; does not certify GPS, offline sync or all workflows.' }
foreach ($path in @('/api/status','/')) {
    try {
        $r = Invoke-WebRequest -Uri ($origin + $path) -UseBasicParsing -TimeoutSec 20
        $item = [ordered]@{ path = $path; status = [int]$r.StatusCode; success = ($r.StatusCode -eq 200) }
        if ($path -eq '/api/status') { $item['appVersion'] = ($r.Content | ConvertFrom-Json).appVersion }
        $report.checks += $item
    } catch {
        $report.checks += [ordered]@{ path = $path; success = $false; error = $_.Exception.Message }
    }
}
$target = Join-Path ([Environment]::GetFolderPath('Desktop')) 'RoutePlan-Connection-Report.json'
$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $target -Encoding UTF8
Write-Host ('Report saved: ' + $target)
Get-Content -LiteralPath $target
