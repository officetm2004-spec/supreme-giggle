#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <winhttp.h>
#include <stdio.h>
#include <wchar.h>

static const wchar_t *DEFAULT_SERVER=L"https://routeplan-web-production.up.railway.app";
static int exists(const wchar_t *p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES&&!(a&FILE_ATTRIBUTE_DIRECTORY);}
static int valid_server(wchar_t *url){
 URL_COMPONENTS u={0};u.dwStructSize=sizeof(u);u.dwSchemeLength=(DWORD)-1;u.dwHostNameLength=(DWORD)-1;u.dwUserNameLength=(DWORD)-1;u.dwPasswordLength=(DWORD)-1;u.dwUrlPathLength=(DWORD)-1;u.dwExtraInfoLength=(DWORD)-1;
 for(const wchar_t *s=url;*s;s++)if(*s<=32||*s==L'"'||*s==L'\\')return 0;
 if(!WinHttpCrackUrl(url,0,0,&u)||!u.dwHostNameLength||u.dwUserNameLength||u.dwPasswordLength||u.dwExtraInfoLength||(u.dwUrlPathLength&&!(u.dwUrlPathLength==1&&u.lpszUrlPath[0]==L'/')))return 0;
 if(u.nScheme==INTERNET_SCHEME_HTTPS)return 1;
 if(u.nScheme!=INTERNET_SCHEME_HTTP)return 0;
 wchar_t host[256];if(u.dwHostNameLength>=256)return 0;wmemcpy(host,u.lpszHostName,u.dwHostNameLength);host[u.dwHostNameLength]=0;
 if(!_wcsicmp(host,L"localhost")||!wcscmp(host,L"127.0.0.1"))return 1;
 unsigned a,b,c,d;wchar_t tail;
 if(swscanf(host,L"%u.%u.%u.%u%c",&a,&b,&c,&d,&tail)!=4||a>255||b>255||c>255||d>255)return 0;
 return a==10||(a==172&&b>=16&&b<=31)||(a==192&&b==168);
}
static int load_server(const wchar_t *folder,wchar_t *url){
 wchar_t path[2048];swprintf(path,2048,L"%ls\\server.txt",folder);wcscpy(url,DEFAULT_SERVER);
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f!=INVALID_HANDLE_VALUE){char bytes[2048];DWORD n=0;BOOL ok=ReadFile(f,bytes,sizeof(bytes)-1,&n,NULL);CloseHandle(f);if(!ok||n>=sizeof(bytes)-1)return 0;bytes[n]=0;char *start=bytes;if(n>=3&&(unsigned char)bytes[0]==239&&(unsigned char)bytes[1]==187&&(unsigned char)bytes[2]==191)start+=3;
  while(*start==' '||*start=='\r'||*start=='\n'||*start=='\t')start++;size_t len=strlen(start);while(len&&(start[len-1]==' '||start[len-1]=='\r'||start[len-1]=='\n'||start[len-1]=='\t'))start[--len]=0;
  if(!len||!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,start,-1,url,1024))return 0;
 }
 return valid_server(url);
}
static int find_browser(wchar_t *out){
 const wchar_t *envs[]={L"ProgramFiles(x86)",L"ProgramFiles",L"LOCALAPPDATA"};
 const wchar_t *tails[]={L"Microsoft\\Edge\\Application\\msedge.exe",L"Google\\Chrome\\Application\\chrome.exe"};
 for(int b=0;b<2;b++)for(int i=0;i<3;i++){wchar_t root[1024];DWORD n=GetEnvironmentVariableW(envs[i],root,1024);if(n&&n<1024){swprintf(out,2048,L"%ls\\%ls",root,tails[b]);if(exists(out))return 1;}}
 return 0;
}
static void log_line(FILE *f,const char *label,const wchar_t *value){char utf8[8192];int n=WideCharToMultiByte(CP_UTF8,0,value,-1,utf8,sizeof(utf8),NULL,NULL);if(n)fprintf(f,"%s=%s\n",label,utf8);}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,LPWSTR cmd,int show){
 (void)inst;(void)prev;(void)cmd;(void)show;
 int argc=0;wchar_t **argv=CommandLineToArgvW(GetCommandLineW(),&argc);int test=argc==3&&!wcscmp(argv[1],L"--self-test");
 wchar_t folder[1024],url[1024],browser[2048]={0},local[1024],profile[2048],command[8192];
 DWORD n=GetModuleFileNameW(NULL,folder,1024);if(!n||n>=1024)return 2;wchar_t *slash=wcsrchr(folder,L'\\');if(!slash)return 2;*slash=0;
 int valid=load_server(folder,url);int found=find_browser(browser);
 if(SHGetFolderPathW(NULL,CSIDL_LOCAL_APPDATA,NULL,SHGFP_TYPE_CURRENT,local)!=S_OK)return 4;
 swprintf(profile,2048,L"%ls\\RoutePlanBusiness\\BrowserProfile",local);
 if(test){FILE *f=_wfopen(argv[2],L"wb");if(!f)return 5;fprintf(f,"version=2.2-business\nvalidServer=%d\nbrowserFound=%d\n",valid,found);if(valid)log_line(f,"server",url);if(found)log_line(f,"browser",browser);log_line(f,"profile",profile);fclose(f);LocalFree(argv);return valid?(found?0:3):2;}
 LocalFree(argv);
 if(!valid){MessageBoxW(NULL,L"The server address in server.txt is invalid. Use an HTTPS server origin without a path, password or query.",L"RoutePlan Business",MB_OK|MB_ICONERROR);return 2;}
 if(!found){MessageBoxW(NULL,L"Install Microsoft Edge or Google Chrome, then open RoutePlan again. Windows 10/11 is required.",L"RoutePlan Business",MB_OK|MB_ICONINFORMATION);return 3;}
 int made=SHCreateDirectoryExW(NULL,profile,NULL);if(made!=ERROR_SUCCESS&&made!=ERROR_ALREADY_EXISTS&&made!=ERROR_FILE_EXISTS){MessageBoxW(NULL,L"Unable to create the RoutePlan browser profile. Check your Windows user-folder permissions.",L"RoutePlan Business",MB_OK|MB_ICONERROR);return 4;}
 swprintf(command,8192,L"\"%ls\" --app=\"%ls\" --user-data-dir=\"%ls\" --no-first-run --no-default-browser-check",browser,url,profile);
 STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
 if(!CreateProcessW(browser,command,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)){MessageBoxW(NULL,L"RoutePlan could not open the desktop window. Close existing RoutePlan windows and try again.",L"RoutePlan Business",MB_OK|MB_ICONERROR);return 6;}
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return 0;
}
