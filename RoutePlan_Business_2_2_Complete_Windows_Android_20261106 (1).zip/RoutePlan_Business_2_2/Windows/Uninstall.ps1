$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'RoutePlan Business'
$shortcut = Join-Path $desktop 'RoutePlan Business.lnk'
if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut -Force }
if (Test-Path -LiteralPath $menu) { Remove-Item -LiteralPath $menu -Recurse -Force }
Write-Host 'RoutePlan shortcuts removed. Client files, login profile and unsynced device notes were retained.'
Write-Host 'Close RoutePlan windows before removing any retained files. Synchronize device notes first.'
