# RoutePlan Business 2.2 — 2026-11-06

Server: https://routeplan-web-production.up.railway.app

## Windows ස්ථාපනය
Windows folder එක extract කර Install-Windows.cmd double-click කරන්න. Desktop RoutePlan shortcut එකෙන් විවෘත කරන්න. Windows 10/11 64-bit සහ Microsoft Edge හෝ Google Chrome අවශ්‍යයි. මෙය installed browser එකේ වෙනම app window එකක් විවෘත කරන compiled Windows client එකකි; client PC එකට Python අවශ්‍ය නැහැ. EXE එක Authenticode-signed නොවේ.

## Android ස්ථාපනය
Android/RoutePlan-Business-2.2.apk phone එකට copy කර විවෘත කරන්න. අවශ්‍ය විට එම file source එකට Install unknown apps අවසර දෙන්න. Android 8+ අවශ්‍යයි. RoutePlan Business app එක පැරණි RoutePlan සමඟ වෙනම install වේ. පැරණි app එකේ pending offline deliveries sync කර අවසන් කරන තුරු uninstall නොකරන්න. Server address පෙර සකසා තිබෙනවා. දැනට ඇති ආයතනික account එකෙන් login වන්න; අලුත් password එකක් මෙම package එකේ නැහැ.

## නව පෙනුම
Deep Blue + Teal වර්ණ, SVG icons, Light/Dark theme, mobile bottom navigation, පැහැදිලි Shop/GPS cards සහ touch-friendly buttons. Theme වෙනස් කිරීමට හිරු/සඳ button එක භාවිත කරන්න. More මඟින් අමතර screens සහ account actions ලබාගන්න. Phone tools ⋮ මඟින් GPS, diagnostics, offline deliveries සහ server settings ලබාගන්න.

## දත්ත සහ server
Online server එක 2.2-business වෙත යාවත්කාලීන කර ඇත. Database schema හෝ accounts වෙනස් කර නැහැ. Browser/phone data clear කිරීමට පෙර pending delivery notes sync කරන්න. Server folder එක self-hosting/maintenance source සඳහාය; දැනට online server භාවිත කරන client PC එකේ එය run කිරීම අවශ්‍ය නැහැ. පැරණි source reports ඉතිහාස වාර්තාය; වර්තමාන තත්ත්වය RELEASE_QA.json බලන්න.

## පරීක්ෂණ සීමා
Frontend/backend automated checks සහ phone/tablet/desktop browser layout checks සමත්. Live server backup එක වෙනම restore කර tables 16ක schema/rows ගැළපීම තහවුරු කර ඇත. Windows EXE build/static checks සමත්; සැබෑ Windows PC runtime පරීක්ෂණය ඉතිරියි. නව 2.2 APK එක install/launch, Phone tools සහ native HTTPS HTTP200 diagnostics සමත්. Android emulator proxy පරිසරයේ සම්පූර්ණ online workflow තහවුරු නොවීය. සැබෑ phone එකේ නව APK login, GPS accuracy, map/route, offline-to-online sync සහ delivery/sales වැඩපිළිවෙළ pilot පරීක්ෂා කර පසුව සියලු සේවකයන්ට නිකුත් කරන්න. මෙය ආයතනය පුරා පරීක්ෂා කර සහතික කළ release එකක් ලෙස නොසලකන්න.

## හිමිකරුට
PRIVATE signing kit එක සේවකයන්ට බෙදා නොදෙන්න. Android future updates සඳහා එහි key එක ආරක්ෂා කර තබන්න. මෙහි distributed apps/source වල private signing key/password නැහැ.

## Colour Studio UI update — 2026-11-06
Blue, Teal, Purple සහ Amber card accents, gradient buttons සහ readable Dark mode analytics යාවත්කාලීන කර ඇත. Dark mode chart headings/labels, donut centre සහ insights wrapper හි අළු පසුබිම නිවැරදි කර ඇත. Phone/tablet/desktop widths 360, 390, 768, 1440 දෙකම Light/Dark themes පරීක්ෂණ සමත්. App ⋮ → Refresh කරන්න හෝ සම්පූර්ණයෙන් close කර නැවත open කරන්න. Data clear/uninstall කිරීම අවශ්‍ය නැහැ. පැරණි RoutePlan app එකේ native blue bar එක පෙන්විය හැක; RoutePlan Business APK එක වෙනම install කිරීමෙන් නව device tools/header භාවිත කළ හැක. APK binary එක මෙම CSS-only update එකේ වෙනස් කර නැහැ.
