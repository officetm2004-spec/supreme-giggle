@echo off
setlocal
cd /d "%~dp0"
set "ROUTEPLAN_PORT=8082"
set "ROUTEPLAN_DATA_DIR=%~dp0data_release_candidate_test"
echo =====================================================
echo ROUTEPLAN RELEASE CANDIDATE - ISOLATED TEST MODE
 echo Data: %ROUTEPLAN_DATA_DIR%
echo Browser: http://localhost:8082
echo Production database is NOT used by this launcher.
echo =====================================================
python server.py
pause
