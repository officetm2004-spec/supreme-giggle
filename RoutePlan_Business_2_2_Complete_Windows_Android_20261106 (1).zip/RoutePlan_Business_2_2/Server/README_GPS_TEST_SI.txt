HISTORICAL NOTES — superseded by 00_START_HERE_SI.txt and DEVELOPMENT_CHECKS.txt.

ROUTEPLAN GPS + EXCEL TEST RELEASE — 2026-11-05

This is a TEST COPY. No production database is included.

1. Extract ZIP to a new folder; do not overwrite your original project.
2. Run Python server.py with ROUTEPLAN_DATA_DIR pointing to a new empty test data folder.
3. Sign in / set up a TEST administrator.
4. Import the original Excel workbook via Excel Planning (preview first).
5. Add test shops with Area matching an imported Excel Route, and save latitude+longitude.
6. Select Excel Route, click Build Smart Route, select GPS-marked customers, preview, open Google Maps.
7. Check unmarked shops are shown but cannot be selected.
8. Open on Android browser using same trusted LAN and verify shared test shops.
9. NEVER use Restore or import a production DB during testing.

Limits: Excel workbook provides route/salesman records, not shop-level IDs. Shop membership is matched using saved Area/Route; actual customer-to-plan mapping requires an additional customer-level Excel sheet or mapping table. GPS route order is straight-line heuristic, not road-optimized. Android APK compilation/device testing not included.
