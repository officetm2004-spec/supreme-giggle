# RoutePlan — Dispatch සහ Routing Release Candidate

2026-11-06 (ශ්‍රී ලංකා වේලාව). මෙය ක්‍රියාත්මක updates සහ පරීක්ෂණ වෙන් කර පෙන්වන release candidate එකකි. Physical Windows/Android certification සම්පූර්ණ යැයි නොසලකන්න.

## දැනට ක්‍රියාත්මක දේ

1. **ශ්‍රී ලංකා OSRM:** country graph වෙනම සකස් කර checksum සහිත archive එකෙන් load කරයි. Pinned OSRM v26.11.0 image, single routing thread සහ mmap භාවිත කරයි. Runtime එකේ PBF preprocessing නොකරයි. Hosted app → private routing network හරහා Colombo, Colombo–Kandy, Jaffna–Galle distance/time/GeoJSON පරීක්ෂණ සමත්. මෙය live traffic හෝ සැබෑ රථයේ මිනුම්ගත travel time නොවේ.
2. **Daily Dispatch Board:** Delivery Workspace තුළ වාහනය, driver, දිනය සහ load unit අනුව planned/delivered/remaining quantities සහ customers/stops පෙන්වයි. Units වෙනස් quantities එකතු නොකරයි.
3. **Plan vs Actual:** තෝරාගත් scheduled date හි වත්මන් Delivered/Partial/Failed/Pending තත්ත්ව, failure reason, revisit අවශ්‍යතාව සහ CSV export. DEVICE ONLY වෙනස්කම් provisional ලෙස සලකුණු වේ.
4. **Delivery proof:** optional receiver name/photo සහ delivery time. Phone එකේ photo එක JPEG බවට resize/compress කර max 180 KB; source JPEG/PNG 12 MB දක්වා. Server validation, recorded timestamp, revisions, offline queue, conflict review සහ full backup තුළ proof ඇතුළත් වේ. සැබෑ camera/device පරීක්ෂාව තවම pending.
5. **System status:** routing configured/actually responding, checked time, unsynced notes, conflicts සහ අවසන් backup. Routing probe තත්පර 30ක් cache කරයි. Offline විට Unknown/checked-time label පෙන්වයි.
6. **Constrained route planning:** date/driver/vehicle/unit, capacity, depot, work start/end (Sri Lanka local time), service minutes සහ loading minutes ඇතුළත් කරයි. Verified GPS හා road-time matrix භාවිත කර එක් return-to-depot trip එකක් සැලසුම් කරයි. ධාරිතාව/වේලාව ඉක්මවන stops හේතු සමඟ වෙන් කරයි. මෙය fleet-wide globally optimal solver එකක් නොවේ; එක් එක් vehicle trip වෙනම ගණනය කරන්න. Money sales එකෙන් cartons/kg අනුමාන නොකරයි; planned delivery quantities අවශ්‍යයි.
7. **Saved route details offline:** authorized drivers වෙත saved trips ලැබේ. Snapshot එකේ customer addresses, GPS, stop order, planned arrival/departure, quantities සහ schematic saved road geometry ඇත. Delivery revisions වෙනස් නම් STALE පෙන්වයි. Offline basemap tiles/live navigation/සම්පූර්ණ app එක offline නොවේ.
8. **Customer audit:** Admin → Data & Backup → Review customer data. Assignment/GPS missing, changed/unconfirmed coordinates, Sri Lanka review bounds සහ possible duplicate names. Read-only; customers auto-merge/delete නොකරයි. GPS bounds හෝ user confirmation එකම physical location නිවැරදි බවට සාක්ෂියක් නොවේ.
9. **Backup restore:** Admin → Verify backup restore. Consistent SQLite backup එක වෙනම directory එකකට restore කර schema සහ සියලු table rows සසඳයි. Hosting startup verification ද enabled. Local integration test එක වෙනත් application process එකක් restored DB මත ආරම්භ කර driver login, photo proof සහ saved routes පරීක්ෂා කරයි. වෙනත් physical Windows PC/external drive restore පරීක්ෂාව වෙනම අවශ්‍යයි.

## භාවිත පිළිවෙළ

- Private activation link එකෙන් ඔබගේ administrator username/password ඔබම සාදන්න. Credentials ZIP එකට ඇතුළත් කර නැත.
- සැබෑ customers ඇතුළත්/restore කර salesman IDs සම්බන්ධ කරන්න; map එකෙන් GPS පරීක්ෂා කර confirm කරන්න.
- Driver account සාදා delivery එකකට vehicle, unit, planned quantity සහ දිනය දෙන්න.
- Capacity/work-window form එකේ සැබෑ අගයන් දෙන්න. Sync නොවූ සටහන් තිබේ නම් මුලින් sync කරන්න.
- ගණනය කළ trip සහ excluded stops පරීක්ෂා කරන්න. Driver online Delivery Workspace එක විවෘත කර snapshot ලබාගත් පසු offline විවෘත කළ හැකියි.
- Partial delivery update එකේ quantity යනු එම delivery record එකේ cumulative delivered quantity එකයි.
- Full backup download එක වෙනත් drive/ආරක්ෂිත ස්ථානයකට තබන්න. Server storage එකම offsite backup එකක් නොවේ.

## තවම අවශ්‍ය දේ

Hosted database එකේ අවසන් තහවුරු කළ snapshot එකේ customers=0, deliveries=0, users=0 (original Excel daily sales 150 සහ plans 12 ඇත). එබැවින් සැබෑ customer cleanup/assignment/GPS හෝ real delivery route acceptance තහවුරු කර නැත.

Windows startup/print/file transfer, Android installation/camera/GPS/permissions, Wi-Fi ↔ mobile-data transitions සහ physical touch acceptance තවම device reports අවශ්‍යයි. RUN_WINDOWS_NETWORK_CHECK.bat සහ APK Connection diagnostics → Copy report භාවිත කරන්න. Desktop/mobile-width browser visual QA හෝ simulated network tests ඒවාට සමාන නොවේ.

## Visual QA

/visual-qa.html යනු SYNTHETIC DATA banner සහිත read-only fixture preview එකකි. සැබෑ backend writes නොකරයි; storage isolated වේ. Desktop ප්‍රධාන තිර 9 සහ 390px phone-width menu/initial delivery layout පරීක්ෂා කර ඇත. Table wrappers තුළ scroll වීම සාමාන්‍යයි; පරීක්ෂා කළ root layouts වල page-level horizontal overflow නැත. අවසන් mobile reload පරීක්ෂාවේ browser connection stalled නිසා සම්පූර්ණ physical/mobile visual certification තවම pending.
