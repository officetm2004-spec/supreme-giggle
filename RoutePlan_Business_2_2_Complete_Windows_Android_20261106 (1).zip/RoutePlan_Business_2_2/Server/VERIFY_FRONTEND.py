"""Optional Node/jsdom development check. Install tests dependencies first."""
import subprocess,os,time,sys,urllib.request,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='routeplan_frontend_') as tmp:
    env=os.environ.copy();env.update(ROUTEPLAN_DATA_DIR=tmp,ROUTEPLAN_HOST='127.0.0.1',ROUTEPLAN_PORT='8101')
    server=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,stdout=subprocess.DEVNULL)
    try:
        for _ in range(50):
            if server.poll() is not None:raise RuntimeError('Temporary server did not start; port 8101 may be busy.')
            try:urllib.request.urlopen('http://127.0.0.1:8101/api/status',timeout=1);break
            except Exception:time.sleep(.1)
        result=subprocess.run(['node',str(ROOT/'tests'/'frontend.cjs')],timeout=45)
        sys.exit(result.returncode)
    finally:server.terminate();server.wait(timeout=5)
