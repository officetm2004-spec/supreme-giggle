#!/usr/bin/env python3
"""Offline administrator password reset; run locally with RoutePlan stopped."""
from getpass import getpass
from server import init_db, get_db, password_hash


def main():
    print('ROUTEPLAN ADMIN PASSWORD RESET')
    print('Run this on the host PC. Stop the RoutePlan server first.')
    init_db()
    with get_db() as db:
        users = [r['username'] for r in db.execute('SELECT username FROM users ORDER BY username')]
    if not users:
        print('No administrator exists yet. Start RoutePlan and create the first account in the browser.')
        return
    print('Accounts:', ', '.join(users))
    username = input('Username to reset: ').strip()
    if username.lower() not in [u.lower() for u in users]:
        print('Username not found. No change made.')
        return
    p1 = getpass('New password (at least 10 characters): ')
    if len(p1) < 10:
        print('Password must be at least 10 characters. No change made.')
        return
    p2 = getpass('Repeat new password: ')
    if p1 != p2:
        print('Passwords do not match. No change made.')
        return
    salt, digest = password_hash(p1)
    with get_db() as db:
        db.execute('UPDATE users SET salt=?, password_hash=? WHERE username=? COLLATE NOCASE', (salt, digest, username))
    print('Password reset successful. Start RoutePlan and sign in with the new password.')

if __name__ == '__main__':
    main()
