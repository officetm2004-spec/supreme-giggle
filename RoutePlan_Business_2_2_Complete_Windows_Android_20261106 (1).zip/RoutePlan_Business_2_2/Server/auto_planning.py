"""AMITH E DASHBOARD H2 thresholds and DATA BASE AL date cutoff.
No road distance estimates or vehicle limits are invented here.
"""
import hashlib
from datetime import datetime,timedelta,timezone
RULES=((900000,1,'HIGH'),(500000,2,'MEDIUM'),(300000,3,'SMALL'),(100000,4,'LOW'))

def classify(amount):
    return next(((rank,label) for minimum,rank,label in RULES if amount>=minimum),(None,'BELOW MINIMUM'))

def amount_band(amount):
    # Literal colour legend in original conditional formatting, ROUTE F2:F26.
    if amount>3000000:return {'key':'red','label':'රතු','next':None,'minimum':3000000}
    if amount>=2000000:return {'key':'orange','label':'තැඹිලි','next':3000000,'minimum':2000000}
    if amount>=1500000:return {'key':'yellow','label':'කහ','next':2000000,'minimum':1500000}
    if amount>=1000000:return {'key':'green','label':'කොළ','next':1500000,'minimum':1000000}
    return {'key':'blue','label':'නිල්','next':1000000,'minimum':0}

def current_amounts(db):
    # Excel SUMIF(date headers, ">" & last dispatch date, sales values).
    return {r['area']:float(r['amount'] or 0) for r in db.execute("""SELECT s.area,SUM(s.amount) amount FROM sales_entries s
      LEFT JOIN dispatch d ON d.area=s.area WHERE s.date>COALESCE(d.last_date,'') GROUP BY s.area""")}

def reconcile(db,stamp):
    db.execute('BEGIN IMMEDIATE') if not db.in_transaction else None
    day=datetime.now(timezone(timedelta(hours=5,minutes=30))).date().isoformat()
    amounts=current_amounts(db);rows=[];created=0
    dispatch={r['area']:r['last_date'] for r in db.execute('SELECT area,last_date FROM dispatch')}
    for area in [r['name'] for r in db.execute('SELECT name FROM areas ORDER BY name')]:
        amount=amounts.get(area,0);rank,label=classify(amount);cycle=dispatch.get(area,'')
        pid='amith-'+hashlib.sha256((area+'|'+cycle).encode()).hexdigest()[:32]
        people=[dict(r) for r in db.execute('SELECT no,name FROM salesmen WHERE area=? ORDER BY no',(area,))]
        # Explicit salesman IDs determine customer membership; no area-name matching.
        ids=[p['no'] for p in people]
        count=db.execute('SELECT COUNT(DISTINCT shop_id) FROM customer_links WHERE salesman_no IN ('+','.join('?' for _ in ids)+')',ids).fetchone()[0] if ids else 0
        notes=f'AMITH E automatic planning | {label} | Rank {rank or "—"} | Current LKR {amount:.2f} | Sales dates after {cycle or "start"} | {count} explicitly assigned customers. Road stop sequence requires verified GPS and routing service.'
        old=db.execute('SELECT * FROM plans WHERE id=?',(pid,)).fetchone()
        if rank:
            manual=db.execute("SELECT id FROM plans WHERE area=? AND type='Delivery' AND status IN ('Planned','In Progress') AND id!=? LIMIT 1",(area,pid)).fetchone()
            if not old and not manual:
                db.execute('INSERT INTO plans VALUES (?,?,?,?,?,?,?,?,?,?)',(pid,day,'Delivery',area,'','08:00','Planned',notes,stamp,'AMITH_AUTO'));created+=1
            elif old and old['status']=='Planned' and old['updated_by']=='AMITH_AUTO':
                if old['notes']!=notes or old['date']!=day:db.execute('UPDATE plans SET date=?,notes=?,updated=? WHERE id=?',(day,notes,stamp,pid))
        elif old and old['status']=='Planned' and old['updated_by']=='AMITH_AUTO':
            db.execute('DELETE FROM plans WHERE id=?',(pid,))
        rows.append({'area':area,'amount':amount,'rank':rank,'priority':label,'customerCount':count,'salesmanNos':ids,'lastDispatch':cycle,'band':amount_band(amount)})
    # Dispatch opens a new cycle. Retire only untouched automatic pending plans.
    active={'amith-'+hashlib.sha256((r['area']+'|'+r['lastDispatch']).encode()).hexdigest()[:32] for r in rows}
    for p in db.execute("SELECT id FROM plans WHERE id LIKE 'amith-%' AND status='Planned' AND updated_by='AMITH_AUTO'").fetchall():
        if p['id'] not in active:db.execute("UPDATE plans SET status='Cancelled',updated=? WHERE id=?",(stamp,p['id']))
    return {'created':created,'rows':sorted(rows,key=lambda r:(r['rank'] or 5,-r['amount'],r['area'])),'rules':[{'minimum':m,'rank':r,'priority':l} for m,r,l in RULES]}

def seed_original(db,root,stamp):
    """One-time baseline for an empty installation; never mix with live records."""
    import json
    db.execute('CREATE TABLE IF NOT EXISTS planning_sources (source TEXT PRIMARY KEY, applied_at TEXT NOT NULL, details TEXT NOT NULL)')
    if db.execute("SELECT 1 FROM planning_sources WHERE source='AMITH_BASELINE'").fetchone():return
    source=root/'amith_sales_reference.json'
    if not source.exists():return
    if db.execute('SELECT COUNT(*) FROM sales_entries').fetchone()[0] or db.execute('SELECT COUNT(*) FROM plans').fetchone()[0]:
        db.execute('INSERT INTO planning_sources VALUES (?,?,?)',('AMITH_BASELINE',stamp,'Skipped: existing live sales/plans preserved'));return
    payload=json.loads(source.read_text());entries=payload['entries']
    for r in entries:
        master=db.execute('SELECT name,area FROM salesmen WHERE no=?',(r['salesmanNo'],)).fetchone()
        if not master or master['name']!=r['name'] or master['area']!=r['area']:raise ValueError('AMITH baseline salesman identity mismatch')
    for r in entries:
        sid='amith-sale-'+hashlib.sha256(f"{r['salesmanNo']}|{r['date']}".encode()).hexdigest()[:32]
        db.execute('INSERT INTO sales_entries VALUES (?,?,?,?,?,?,?,?,?)',(sid,r['date'],r['salesmanNo'],r['name'],r['area'],r['amount'],'Original AMITH E daily sales baseline',stamp,'AMITH_SOURCE'))
    db.execute('INSERT INTO planning_sources VALUES (?,?,?)',('AMITH_BASELINE',stamp,payload['sha256']))
