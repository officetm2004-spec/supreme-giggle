# Menu සහ අකුරු වර්ණ සංශෝධනය

Navy/blue sidebar, active menu highlight, එක් එක් අංශයට ගැළපෙන icon accent colours, consistent heading/body/secondary text colours සහ system Sinhala font fallbacks යොදා ඇත. Excel route amount colours වෙනස් කර නැත.

Desktop: පැති menu එක scroll කළ හැකියි. Phone/tablet: Menu button එකෙන් drawer එකක් විවෘත වේ. Close, backdrop සහ Escape මගින් වසාගත හැකියි. Expanded state, active page indication, visible keyboard focus සහ drawer keyboard focus handling එකතු කර ඇත. Permissions නිසා hidden menu items නැවත පෙන්වන්නේ නැත.

Headings, labels, forms, tables සහ action buttons සඳහා consistent readable colours ඇත. බාහිර font download අවශ්‍ය නොවේ. Reduced-motion preference සහ print layout රැක ඇත.

DOM menu behavior, chart selectors සහ පෙර app/offline checks සමත්. සැබෑ Windows/Android rendered visual acceptance තවම pending. Sri Lanka road routing memory blocker ද ඉතිරියි.
