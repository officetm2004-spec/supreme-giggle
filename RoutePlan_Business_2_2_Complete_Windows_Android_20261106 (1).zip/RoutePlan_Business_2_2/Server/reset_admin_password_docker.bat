@echo off
setlocal
cd /d "%~dp0"
docker compose exec routeplan python /app/reset_admin_password.py
if %errorlevel% neq 0 (
  echo Could not reset the password. Confirm Docker Desktop and RoutePlan are running.
  pause
  exit /b 1
)
pause
endlocal
