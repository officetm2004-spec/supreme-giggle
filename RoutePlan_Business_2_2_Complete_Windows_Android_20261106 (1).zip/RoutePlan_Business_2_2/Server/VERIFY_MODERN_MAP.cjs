// Offline behavior tests; no public tiles or browser GPU required.
const vm=require('vm'),fs=require('fs'),assert=require('assert');
const els={crMapStatus:{},crSalesman:{value:'1'},crScope:{value:'assigned'},crLat:{value:'6.8'},crLon:{value:'79.8'},crReturn:{checked:false}};
const ctx={console,window:{},$:id=>els[id],document:{createElement:()=>({}),head:{append:()=>{}}},crRender:()=>{},state:{shops:[{id:'a',latitude:6.9,longitude:79.9}]},crLinks:[{shop_id:'a',salesman_no:1,verified_lat:6.9,verified_lon:79.9,verified_at:'now'}],crSelected:new Set(['a']),rpGpsValid:()=>true,crVerified:()=>true};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/static/modern-map.js','utf8'),ctx);
vm.runInContext(`
if(crMapShops().length!==1)throw Error('Assignment filter failed');
$('crSalesman').value='2';if(crMapShops().length!==0)throw Error('Other salesman leaked');
$('crSalesman').value='1';
crMapRoute({stops:state.shops,geometry:{type:'LineString',coordinates:[[79.8,6.8],[79.9,6.9]]}});
if(!crMapGeometry||crMapOrdered.length!==1)throw Error('Route geometry lost');
crMapClearRoute();if(crMapGeometry!==null||crMapOrdered.length)throw Error('Stale route retained');
crMapRoute({stops:state.shops});if(crMapGeometry!==null)throw Error('Missing geometry was fabricated');
`,ctx);
console.log('PASS: salesman map filtering, route geometry, stale route clearing, no fabricated road line');
