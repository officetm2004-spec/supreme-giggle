@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PYTHON_EXE=py -3") else (set "PYTHON_EXE=python")
%PYTHON_EXE% VERIFY_RELEASE.py
if errorlevel 1 goto fail
%PYTHON_EXE% VERIFY_HTTP_ISOLATED.py
if errorlevel 1 goto fail
%PYTHON_EXE% VERIFY_CUSTOMER_ROUTING.py
if errorlevel 1 goto fail
%PYTHON_EXE% VERIFY_OPERATIONS.py
if errorlevel 1 goto fail
echo Isolated code/API checks passed on this Windows runtime.
echo Run RUN_WINDOWS_NETWORK_CHECK.bat next. This does not certify phone or UI behavior.
goto end
:fail
echo A check failed. Preserve this window output for diagnosis.
:end
pause
endlocal
