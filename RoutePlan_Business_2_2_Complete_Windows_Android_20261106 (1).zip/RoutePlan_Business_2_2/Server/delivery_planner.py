"""One vehicle trip constrained by declared capacity and same-day work window."""
import math
from road_routes import point,query

def finite(value,label,positive=False):
    if isinstance(value,bool):raise ValueError(label+' must be a number.')
    try:n=float(value)
    except (TypeError,ValueError):raise ValueError('Enter '+label+'.')
    if not math.isfinite(n) or n<0 or (positive and not n) or n>1e9:raise ValueError('Invalid '+label+'.')
    return n

def minutes(value):
    import re
    if not isinstance(value,str) or not re.fullmatch(r'\d{2}:\d{2}',value):raise ValueError('Enter work times as HH:MM.')
    h,m=map(int,value.split(':'))
    if h>23 or m>59:raise ValueError('Invalid work time.')
    return h*60+m

def plan(stops,data):
    capacity=finite(data.get('capacity'),'vehicle capacity',True);service=finite(data.get('serviceMinutes'),'service minutes');loading=finite(data.get('loadingMinutes'),'loading minutes')
    start,end=minutes(data.get('workStart')),minutes(data.get('workEnd'))
    if end<=start:raise ValueError('Work end must follow start on the same day.')
    if not stops:raise ValueError('No pending or partial deliveries match this driver/vehicle/date.')
    if len(stops)>50:raise ValueError('Plan at most 50 delivery stops per request.')
    depot=point(data.get('depot'));points=[depot]+[point(s) for s in stops]
    durations=query('table',points,'annotations=duration').get('durations');n=len(points)
    if not isinstance(durations,list) or len(durations)!=n or any(not isinstance(r,list) or len(r)!=n for r in durations):raise RuntimeError('Invalid road time matrix.')
    if any(v is None or not isinstance(v,(float,int)) or not math.isfinite(v) or v<0 for r in durations for v in r):raise RuntimeError('Some stops cannot be reached by road. Check verified GPS.')
    remaining=set(range(1,n));chosen=[];excluded=[];current=0;clock=start+loading;load=0
    while remaining:
        nxt=min(remaining,key=lambda j:(durations[current][j],j));remaining.remove(nxt);s=stops[nxt-1];qty=finite(s['remaining_qty'],'remaining quantity',True)
        arrival=clock+durations[current][nxt]/60;finish=arrival+service
        if load+qty>capacity:excluded.append({'id':s['id'],'customer':s['customer_name'],'reason':'Vehicle capacity exceeded'});continue
        if finish+durations[nxt][0]/60>end:excluded.append({'id':s['id'],'customer':s['customer_name'],'reason':'Work window exceeded including return to depot'});continue
        chosen.append({**s,'arrivalMinutes':arrival,'departureMinutes':finish,'loadQty':qty});load+=qty;clock=finish;current=nxt
    if not chosen:return {'stops':[],'excluded':excluded,'load':0,'capacity':capacity,'method':'No feasible stops within declared capacity/work window; no route estimated'}
    route=query('route',[depot]+[point(s) for s in chosen]+[depot],'overview=full&geometries=geojson&steps=false')['routes'][0]
    travel=finite(route['duration'],'road duration')/60;distance=finite(route['distance'],'road distance')/1000
    # Route response and matrix should agree; enforce shift again against actual route result.
    finish=start+loading+service*len(chosen)+travel
    if finish>end+0.01:raise RuntimeError('Routing times changed; selected trip exceeds work window. Replan with a shorter trip.')
    return {'stops':chosen,'excluded':excluded,'load':load,'capacity':capacity,'workStart':data['workStart'],'workEnd':data['workEnd'],'finishMinutes':finish,'travelMinutes':travel,'serviceMinutes':service,'loadingMinutes':loading,'distanceKm':distance,'geometry':route.get('geometry'),'depot':depot,'method':'OSRM road-time nearest feasible stop heuristic; one return-to-depot trip; no live traffic; not guaranteed optimal'}
