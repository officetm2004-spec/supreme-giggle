HISTORICAL NOTES — superseded by 00_START_HERE_SI.txt and DEVELOPMENT_CHECKS.txt.

RoutePlan Stage 4 — Excel + GPS route preview (Development/Test)

1. Extract ZIP to a NEW folder. Never extract over your existing working RoutePlan folder.
2. Double-click START_EXCEL_TEST.bat; it uses port 8081 and the NEW data_test folder.
3. Open http://localhost:8081, set up/login to the isolated test server.
4. Data & Backup > Excel Sales Planning: preview and import AMITH E .xlsx.
5. Shop Directory & Map: save shops with matching Area/Route name and BOTH GPS coordinates.
6. In Smart Delivery Route choose imported Excel route > Build route preview.
7. Review GPS-marked and unmarked counts, stop order and Google Maps links; export CSV if needed.

IMPORTANT LIMITATIONS:
- Excel route labels must match the saved Shop Area/Route labels (case-insensitive).
- Excel does not contain customer coordinates; real GPS data must be entered separately.
- Approximate distances are straight-line between shops, NOT actual road distance or drive time.
- Route order uses nearest-neighbor plus local 2-opt improvement, NOT guaranteed globally optimal.
- Google Maps calculates actual roads when opened; routes over 10 stops are split into batches.
- Android is supported through a responsive web browser on the same private Wi-Fi/LAN, NOT a native APK.
- Android physical-device and multi-device sync testing requires your devices and LAN; NOT certified here.
- Port 8081 may require firewall allowance for phone access. Do NOT forward ports to the Internet.
- DO NOT copy your live routeplan.db into data_test until you have a safe backup and explicitly choose to test a copy.
- No production database is included in this ZIP or modified by building this release.
