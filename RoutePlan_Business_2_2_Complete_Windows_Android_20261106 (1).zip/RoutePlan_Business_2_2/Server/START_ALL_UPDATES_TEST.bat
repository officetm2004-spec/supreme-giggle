@echo off
setlocal
cd /d "%~dp0"
set "ROUTEPLAN_PORT=8082"
if not defined ROUTEPLAN_OSRM_URL set "ROUTEPLAN_OSRM_URL=http://127.0.0.1:5000"
set "ROUTEPLAN_DATA_DIR=%~dp0data_release_candidate_test"
echo RoutePlan Development Build - http://localhost:8082
echo For mobile data or other Wi-Fi, deploy the public HTTPS configuration.
where py >nul 2>nul
if %errorlevel%==0 (py -3 server.py) else (python server.py)
pause
endlocal
