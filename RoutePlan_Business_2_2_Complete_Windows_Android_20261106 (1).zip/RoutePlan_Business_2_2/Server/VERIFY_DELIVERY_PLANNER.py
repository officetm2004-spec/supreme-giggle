"""Constraint tests use synthetic road times, not a live road-routing certification."""
import delivery_planner as p
stops=[{'id':str(i),'customer_name':'Synthetic '+str(i),'latitude':6.9+i*.001,'longitude':79.9,'remaining_qty':qty} for i,qty in enumerate([6,4,20],1)]
def fake(service,points,options):
 if service=='table':return {'durations':[[0 if i==j else 300 for j in range(len(points))] for i in range(len(points))]}
 return {'routes':[{'duration':300*(len(points)-1),'distance':1000*(len(points)-1),'geometry':{'type':'LineString','coordinates':[[x['longitude'],x['latitude']] for x in points]}}]}
p.query=fake
base={'capacity':10,'serviceMinutes':10,'loadingMinutes':0,'workStart':'08:00','workEnd':'09:00','depot':{'latitude':6.9,'longitude':79.9}}
r=p.plan(stops,base);assert len(r['stops'])==2 and r['load']==10 and len(r['excluded'])==1 and r['finishMinutes']==515
r=p.plan(stops,{**base,'capacity':100,'workEnd':'08:25'});assert len(r['stops'])==1 and len(r['excluded'])==2
try:p.plan(stops,{**base,'workEnd':'07:00'})
except ValueError:pass
else:raise AssertionError('Invalid work window accepted')
print('PASS: capacity boundaries, oversized stop exclusion, work window including depot return, service/loading time and invalid window checks (synthetic road matrix)')
