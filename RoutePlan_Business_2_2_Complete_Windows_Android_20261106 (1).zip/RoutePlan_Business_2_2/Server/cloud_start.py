"""Railway startup: initialize persistent mount ownership, then drop root privileges."""
import os,pwd,sys
from pathlib import Path
if os.name=='posix' and os.geteuid()==0:
    account=pwd.getpwnam('routeplan')
    data=Path(os.environ.get('ROUTEPLAN_DATA_DIR','/app/data')).resolve()
    # Only initialize this application's dedicated persistent mount.
    if str(data) not in ('/app/data','/data'):raise SystemExit('Unsupported cloud persistent data path.')
    data.mkdir(parents=True,exist_ok=True)
    for folder,dirs,files in os.walk(data,followlinks=False):
        for path in [Path(folder)]+[Path(folder)/name for name in files]:
            if not path.is_symlink():os.chown(path,account.pw_uid,account.pw_gid,follow_symlinks=False)
    os.initgroups(account.pw_name,account.pw_gid);os.setgid(account.pw_gid);os.setuid(account.pw_uid)
os.execv(sys.executable,[sys.executable,'/app/server.py'])
