"""Download Sri Lanka OSM data and preprocess with official OSRM Docker image."""
import os,subprocess,urllib.request,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
settings=ROOT.parent/'.env'
file_image=next((line.split('=',1)[1].strip().strip('\"').strip("'") for line in settings.read_text(encoding='utf-8').splitlines() if line.startswith('ROUTEPLAN_OSRM_IMAGE=')), '') if settings.exists() else ''
IMAGE=os.environ.get('ROUTEPLAN_OSRM_IMAGE') or file_image or 'ghcr.io/project-osrm/osrm-backend:latest'
PBF=DATA/'sri-lanka-latest.osm.pbf'
if not PBF.exists():
    url='https://download.geofabrik.de/asia/sri-lanka-latest.osm.pbf'
    print('Downloading Sri Lanka road data from Geofabrik…',flush=True)
    temporary=PBF.with_suffix('.partial');urllib.request.urlretrieve(url,temporary);os.replace(temporary,PBF)
subprocess.run(['docker','pull',IMAGE],check=True)
for args in [('osrm-extract','-p','/opt/car.lua','/data/sri-lanka-latest.osm.pbf'),('osrm-partition','/data/sri-lanka-latest.osrm'),('osrm-customize','/data/sri-lanka-latest.osrm')]:
    subprocess.run(['docker','run','--rm','-v',str(DATA.resolve())+':/data',IMAGE,*args],check=True)
result=subprocess.run(['docker','image','inspect',IMAGE,'--format','{{json .RepoDigests}}'],capture_output=True,text=True,check=True)
(DATA/'prepared.json').write_text(json.dumps({'preparedAt':datetime.now(timezone.utc).isoformat(),'image':IMAGE,'imageDigests':json.loads(result.stdout),'pbfSha256':hashlib.sha256(PBF.read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print('Sri Lanka routing data ready. Use the same image digest when running/updating OSRM.')
