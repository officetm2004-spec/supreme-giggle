#!/usr/bin/env python3
"""Create a consistent online SQLite backup of the RoutePlan database."""
from datetime import datetime
from pathlib import Path
import argparse
import os
import sqlite3

ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("ROUTEPLAN_DATA_DIR", ROOT / "data"))
DB_PATH = DATA_DIR / "routeplan.db"


def main():
    parser = argparse.ArgumentParser(description="Create a consistent RoutePlan database backup.")
    parser.add_argument("--output-dir", default=str(DATA_DIR / "backups"), help="Directory for the backup file")
    args = parser.parse_args()
    if not DB_PATH.exists():
        raise SystemExit(f"Database does not exist: {DB_PATH}. Start RoutePlan and create the administrator first.")
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = output_dir / f"routeplan-db-{stamp}.sqlite3"
    src = sqlite3.connect(f"file:{DB_PATH.resolve().as_posix()}?mode=ro", uri=True, timeout=30)
    dst = sqlite3.connect(target, timeout=30)
    try:
        src.backup(dst)
        result = dst.execute("PRAGMA integrity_check").fetchone()[0]
        if result != "ok":
            target.unlink(missing_ok=True)
            raise SystemExit(f"Backup integrity check failed: {result}")
    finally:
        dst.close()
        src.close()
    print(f"Backup created: {target}")
    print("Integrity check: ok")


if __name__ == "__main__":
    main()
