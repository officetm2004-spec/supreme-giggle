# RoutePlan 2.1 — Android Emulator QA Release

දිනය: 2026-11-06. **ඉල්ලූ workflows emulator පරීක්ෂණ සමත්.** සැබෑ phone/carrier acceptance තවම ඉතිරියි.

Android 11 / API 30, Android System WebView 83.0.4103.120, x86_64 emulator 37.3.7 තුළ ZIP එකේ පවතින APK එක ස්ථාපනය කර ක්‍රියාත්මක කළා. APK version 2.1-qa (versionCode 3). Source APK එක වෙනස් හෝ rebuild කර නැත; frontend වෙනස්කම් server එකෙන් load වේ.

| පරීක්ෂණය | ප්‍රතිඵලය | සාක්ෂිය |
|---|---|---|
| APK install හා app ආරම්භය | PASS | Android Package Manager installation success; activity launched |
| Login / Logout | PASS | වැරදි මුරපදය ප්‍රතික්ෂේප විය; Admin සහ Salesman login; confirmed logout |
| Database සම්බන්ධතාව | PASS | Android form එකෙන් රු.900,000 test sale එක save විය; SQLite තුළ එක record එකකි; integrity `ok` |
| Sales History | PASS | Saved sale, date/person filters සහ monthly history පරීක්ෂා කළා |
| Salesman අවසර | PASS | තම Salesman/customer/history පමණි; වෙනත් test sale සහ Admin panel නොපෙනේ |
| Automatic planning | PASS | Sale එකෙන් පවතින automatic delivery plan එක නැවත ගණනය විය; duplicate plan නැත |
| Native GPS | PASS — simulated | අවසර ප්‍රතික්ෂේපය සහ නැවත grant කිරීම; mock Colombo fix 6.9271, 79.8612 native callback හරහා form එකට ලැබුණා |
| Interactive Map | PASS — test transport | Basemap, customer pins 2, depot pin සහ road line Android තිරයේ දෘශ්‍යව තහවුරු කළා; tiles/style loaded; layers 112 |
| Road route | PASS | Android UI → test server → live OSRM; stops 2; UI distance 4.6 km; geometry points 208 |
| Frontend regression | PASS | jsdom checks නැවත සමත්; errors 0; map state tests සහ JavaScript syntax සමත් |

## නිවැරදි කළ දෝෂ

1. WebView 83 හි CSS `inset` නොමැති නිසා menu backdrop එක 28×38 px පමණක් වුණා. Explicit edges, width සහ height යොදා සම්පූර්ණ viewport එක ආවරණය කළා. Saved source එක නැවත load කර 480×672 px viewport එකට ගැළපෙන බව පරීක්ෂා කළා.
2. MapLibre 6 renderer එක මෙම WebView තුළ `Unexpected token '='` දෝෂයෙන් නතර වුණා. Modern renderer එක load නොවූ විට local MapLibre 4.7.1 renderer සහ CSS භාවිත කරන fallback එක එක් කළා. එය සැබෑ Android WebView තුළ map tiles සහ road line render කළා. Vendor license සහ source/SHA256 තොරතුරු `static/vendor/` හි ඇත. Modern browser path රඳවා තිබේ.

## පරීක්ෂණ සීමා

- මෙම emulator එකේ සෘජු outbound map-resource ප්‍රවේශය ක්‍රියා නොකළ නිසා public CDN/style/tile/font සත්‍ය response bytes host test transport එකෙන් ලබාදුන්නා. Map data, customer/route API හෝ geometry සඳහා fake responses යෙදුවේ නැහැ. මෙයින් Android සෘජු Internet/TLS සම්බන්ධතාව තහවුරු නොවේ.
- Road routing පරීක්ෂණය public OSRM demo service එකෙන් සිදු කළා. ZIP එකේ production routing configuration වෙනස් කර නැත; භාවිත කරන server එකට routing සේවාව configure කළ යුතුයි.
- GPS coordinates emulator එකෙන් ලබාදුන් simulated fix එකකි. සැබෑ satellite reception/accuracy, physical phone touch/drag, office Wi-Fi/mobile data/airplane-mode switching, public production HTTPS සහ සැබෑ Windows acceptance ඉතිරියි.
- මෙම run එක uploads/downloads, camera, print සහ සියලු Android versions සඳහා acceptance නොවේ. මුල් development APK signing එකම පවතී.
- මුල් production/customer database එක භාවිත හෝ වෙනස් කර නැත. Isolated test database එක සහ පරීක්ෂණ ගිණුම් release ZIP එකට ඇතුළත් කර නැත.
- පළමු software-emulator boot එකේ System UI ANR එකක් සහ browser tile-memory warnings තිබුණා. System UI wait කර animations අඩු කළ පසු පරීක්ෂණ ඉදිරියට ගියා. අවසන් AndroidRuntime log එකේ fatal app exception නොතිබුණා. මෙම software emulator එකෙන් performance benchmark එකක් ප්‍රකාශ නොකරයි.

## භාවිතය

අලුත් folder එකකට ZIP එක extract කර `00_START_HERE_SI.txt` හි server/Windows උපදෙස් අනුගමනය කරන්න. Android APK: `Android_APK/RoutePlan-2.1-qa.apk`. Phone එකට භාවිත කරන සැබෑ server origin එක ලබාදෙන්න; emulator test address එක phone configuration එකට යොදන්න එපා.

නැවත frontend පරීක්ෂණ:

```text
npm ci --prefix tests --ignore-scripts --no-audit --no-fund
python VERIFY_FRONTEND.py
node VERIFY_MODERN_MAP.cjs
```

Machine-readable current report: `ANDROID_EMULATOR_TEST_RESULTS.json`. තෝරාගත් raw JSON සාක්ෂි: `android_qa_evidence/`. පෙර වාර්තාවල Android not-run සටහන් මෙම වාර්තාවට පෙර තත්ත්වයයි; physical-device pending සීමා තවම අදාළ වේ.
