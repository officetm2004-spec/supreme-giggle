"""Consistent SQLite backups on server startup and periodically while running."""
import json, os, sqlite3, threading
from pathlib import Path
from datetime import datetime,timezone
_LOCK=threading.RLock()
def status(data_dir):
    path=Path(data_dir)/'backup_status.json'
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {'state':'No backup recorded yet'}
def _record(data_dir,value):
    p=Path(data_dir)/'backup_status.json';temp=p.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');os.replace(temp,p)
def create_backup(db_path,data_dir):
    with _LOCK:
        db_path=Path(db_path);data_dir=Path(data_dir)
        if not db_path.is_file():raise ValueError('Database not found.')
        dest=Path(os.environ.get('ROUTEPLAN_BACKUP_DIR',str(data_dir/'backups')));dest.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target=dest/f'routeplan-full-{stamp}.sqlite3';tmp=target.with_suffix('.partial')
        try:
            src=sqlite3.connect(db_path.resolve().as_uri()+'?mode=ro',uri=True,timeout=30)
            dst=sqlite3.connect(tmp,timeout=30)
            try:
                src.backup(dst)
                if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Backup integrity check failed.')
            finally:dst.close();src.close()
            os.replace(tmp,target)
            # Retain the newest configured count; never delete unrelated files.
            keep=max(2,int(os.environ.get('ROUTEPLAN_BACKUP_KEEP','30')))
            for old in sorted(dest.glob('routeplan-full-*.sqlite3'),reverse=True)[keep:]:old.unlink()
            result={'state':'ok','file':target.name,'createdAt':datetime.now(timezone.utc).isoformat(),'bytes':target.stat().st_size,'integrity':'ok','retentionCount':keep}
            _record(data_dir,result);return result
        except Exception as exc:
            tmp.unlink(missing_ok=True)
            _record(data_dir,{'state':'error','error':str(exc),'createdAt':datetime.now(timezone.utc).isoformat()})
            raise

def start(db_path,data_dir):
    stop=threading.Event();hours=max(.01,float(os.environ.get('ROUTEPLAN_BACKUP_HOURS','6')))
    def run():
        while not stop.is_set():
            try:create_backup(db_path,data_dir)
            except Exception as exc:print('[RoutePlan] Automatic backup failed:',exc)
            stop.wait(hours*3600)
    threading.Thread(target=run,name='routeplan-backup',daemon=True).start()
    return stop
