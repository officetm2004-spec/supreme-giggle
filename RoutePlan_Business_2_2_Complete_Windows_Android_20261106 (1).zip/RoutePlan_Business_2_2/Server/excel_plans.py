"""Read the user's cached Excel planning values using Python's standard library.
No formulas are evaluated, and no spreadsheet is ever modified.
"""
import io, zipfile, xml.etree.ElementTree as ET, re, posixpath
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
R='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'

def parse_xlsx(raw):
    if len(raw)>3_000_000: raise ValueError('Excel file exceeds 3 MB limit')
    try: z=zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile: raise ValueError('Invalid .xlsx file')
    if len(z.namelist())>2000 or sum(x.file_size for x in z.infolist())>35_000_000: raise ValueError('Excel file too large')
    shared=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        shared=[''.join(t.text or '' for t in si.iter(M+'t')) for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
    wb=ET.fromstring(z.read('xl/workbook.xml'))
    rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheets=[]
    for sheet in wb.find(M+'sheets'):
        target=rels[sheet.get(R+'id')].lstrip('/')
        if not target.startswith('xl/'): target=posixpath.normpath('xl/'+target)
        root=ET.fromstring(z.read(target)); rows=[]
        for row in root.findall('.//'+M+'sheetData/'+M+'row'):
            cells={}
            for c in row.findall(M+'c'):
                ref=c.get('r','');col=re.match(r'[A-Z]+',ref)
                if not col:continue
                v=c.find(M+'v'); inline=c.find(M+'is');value=v.text if v is not None else ''.join(inline.itertext()) if inline is not None else ''
                if c.get('t')=='s' and value:value=shared[int(value)]
                cells[col.group()]=value or ''
            rows.append(cells)
        sheets.append((sheet.get('name',''),rows))
    # The original workbook contains a canonical ROUTE sheet and a second ROUTE sheet.
    # DATA BASE has stable salesman numbers; DASHBOARD supplies ordered priorities.
    master={}; plan=[]; priority=[]; warnings=[]
    for name,rows in sheets:
        if name.strip().upper()=='DATA BASE':
            for row in rows[1:]:
                try:
                    number=int(float(row.get('B') or ''))
                    if 1<=number<=100000 and row.get('C') and row.get('D'):
                        master[number]={'no':number,'salesman':row['C'].strip(),'route':row['D'].strip()}
                except (ValueError,TypeError):pass
        if name.strip().upper()=='DASHBOARD':
            for row in rows[1:]:
                try:
                    number=int(float(row.get('A') or ''))
                    if number<1 or not row.get('B') or not row.get('D'):continue
                    priority.append({'no':number,'salesman':row['B'].strip(),'route':row['D'].strip(), 'salesmanTotal':float(row.get('E') or 0),'routeTotal':float(row.get('F') or 0),'status':row.get('G','').strip(),'rank':row.get('H','').strip()})
                except (ValueError,TypeError):pass
    for name,rows in sheets:
        if name.strip().upper()=='ROUTE':
            for row in rows[1:]:
                try:
                    number=int(float(row.get('A') or ''))
                    if number<1 or number>100000 or not row.get('B') or not row.get('C'):continue
                    plan.append({'no':number,'salesman':row['B'].strip(),'route':row['C'].strip(),'salesmanTotal':float(row.get('D') or 0),'routeTotal':float(row.get('E') or 0),'priority':row.get('F','').strip()})
                except (ValueError,TypeError):pass
            if plan:break
    if not plan:raise ValueError('No usable numbered entries in ROUTE sheet')
    matched=[]
    for row in plan:
        m=master.get(row['no']);row['matched']=bool(m and m['salesman'].casefold()==row['salesman'].casefold() and m['route'].casefold()==row['route'].casefold())
        matched.append(row['matched'])
    if not all(matched):warnings.append('Some ROUTE entries do not match DATA BASE by number, salesman and route. Review before using.')
    if not priority:warnings.append('DASHBOARD priorities not found')
    return {'entries':plan,'priorities':priority,'masterCount':len(master),'matchedCount':sum(matched),'warnings':warnings,'sheets':[name for name,_ in sheets]}
