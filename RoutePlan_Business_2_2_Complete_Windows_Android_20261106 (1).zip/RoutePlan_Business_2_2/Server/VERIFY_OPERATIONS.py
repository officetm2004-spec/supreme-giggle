"""Isolated development checks only. Does not certify real devices/Internet/maps."""
import os,tempfile,threading,json,urllib.request,urllib.error,http.cookiejar,sqlite3,uuid
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='routeplan_ops_') as tmp:
 os.environ['ROUTEPLAN_DATA_DIR']=tmp
 import server
 server.init_db();server.init_db()
 http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);threading.Thread(target=http.serve_forever,daemon=True).start()
 url=f'http://127.0.0.1:{http.server_port}/api/'
 def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(__import__('http.cookiejar',fromlist=['CookieJar']).CookieJar()))
 def call(c,path,data=None):
  req=urllib.request.Request(url+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
  try:
   with c.open(req,timeout=10) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def op():return uuid.uuid4().hex
 try:
  admin,sales,driver,other=client(),client(),client(),client()
  assert call(admin,'setup',{'username':'opsadmin','password':'test-only-password'})[0]==200
  _,master=call(admin,'data');no=master['salesmen'][0]['no'];area=master['areas'][0]
  for name,role in [('salestest','Salesman'),('drivertest','Driver'),('otherdriver','Driver')]:
   code,out=call(admin,'users',{'username':name,'password':'test-only-password','role':role,'salesmanNo':no if role=='Salesman' else None,'active':True});assert code==200,out
  for c,name in [(sales,'salestest'),(driver,'drivertest'),(other,'otherdriver')]:assert call(c,'login',{'username':name,'password':'test-only-password'})[0]==200
  _,customer=call(admin,'map-customer',{'name':'Development test shop','area':area,'address':'Test only','latitude':6.9,'longitude':79.9,'salesmanNo':no,'confirmLocation':True});sid=customer['shop']['id']
  body={'shopId':sid,'date':'2026-11-06','assignedTo':'drivertest','plannedQty':10,'vehicle':'WP TEST-01','loadUnit':'cartons','operationId':op()}
  code,out=call(admin,'deliveries',body);assert code==201,out;record=out['delivery']
  assert record['vehicle']=='WP TEST-01' and record['load_unit']=='cartons'
  assert call(admin,'deliveries',body)[1]['replayed']
  assert call(driver,'deliveries',body)[0]==403
  import delivery_planner
  def fake_query(service,points,options):
   if service=='table':return {'durations':[[0 if i==j else 300 for j in range(len(points))] for i in range(len(points))]}
   return {'routes':[{'duration':300*(len(points)-1),'distance':1000*(len(points)-1),'geometry':{'type':'LineString','coordinates':[[p['longitude'],p['latitude']] for p in points]}}]}
  delivery_planner.query=fake_query
  routebody={'date':'2026-11-06','driver':'drivertest','vehicle':'WP TEST-01','loadUnit':'cartons','capacity':10,'serviceMinutes':10,'loadingMinutes':5,'workStart':'08:00','workEnd':'09:00','depot':{'latitude':6.9,'longitude':79.9}}
  code,trip=call(admin,'delivery-route-plan',routebody);assert code==200,trip
  assert len(trip['stops'])==1 and trip['load']==10
  assert len(call(driver,'delivery-route-plans')[1]['plans'])==1
  assert len(call(other,'delivery-route-plans')[1]['plans'])==0
  assert call(driver,'delivery-route-plan',routebody)[0]==403
  assert call(admin,'customer-audit')[1]['total']==1
  assert call(driver,'customer-audit')[0]==403
  assert call(admin,'backup-verify',{})[1]['allRowsMatched']

  assert len(call(driver,'deliveries')[1]['deliveries'])==1
  assert len(call(other,'deliveries')[1]['deliveries'])==0
  assert len(call(other,'data')[1]['shops'])==0
  assert len(call(sales,'data')[1]['shops'])==1
  assert call(driver,'users')[0]==403
  assert call(driver,'backup')[0]==403
  assert call(driver,'excel-import',{'xlsxBase64':'AAAA'})[0]==403
  update={'id':record['id'],'status':'Partial','deliveredQty':4,'notes':'Customer requested remainder later','receiverName':'Test receiver','deliveredAt':'2026-11-06T10:30:00+05:30','proofPhoto':'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/a9sAAAAASUVORK5CYII=','expectedRevision':1,'operationId':op()}
  code,result=call(driver,'delivery-update',update);assert code==200,result
  assert result['delivery']['receiver_name']=='Test receiver' and result['delivery']['delivered_at']=='2026-11-06T05:00:00+00:00' and result['delivery']['proof_photo'].startswith('data:image/png')
  assert result['delivery']['confirmed_at']
  assert call(driver,'delivery-update',update)[1]['replayed']
  invalid={**update,'expectedRevision':2,'operationId':op(),'proofPhoto':'data:image/svg+xml;base64,PHN2Zz4='};assert call(driver,'delivery-update',invalid)[0]==400
  assert call(driver,'operations-status')[0]==200
  bad={**update,'operationId':op(),'expectedRevision':1};assert call(driver,'delivery-update',bad)[0]==409
  assert call(other,'delivery-update',{**update,'operationId':op()})[0]==403
  assert call(driver,'delivery-update',{**update,'status':'Delivered','expectedRevision':2,'operationId':op()})[0]==400
  assert call(driver,'delivery-update',{**update,'status':'Delivered','deliveredQty':10,'expectedRevision':2,'operationId':op()})[0]==200
  assert call(admin,'users',{'username':'opsadmin','role':'Driver','active':True})[0]==400
  assert call(admin,'restore',{'plans':[],'dispatch':{}})[0]==409
  from backup_service import create_backup
  from restore_full_backup import rehearse
  created=create_backup(server.DB_PATH,server.DATA_DIR)
  counts=rehearse(Path(tmp)/'backups'/created['file']);assert counts['deliveries']==1 and counts['users']==4
  # Start a separate application installation from the real test backup.
  import subprocess,sys
  restored=Path(tmp)/'restored-installation';restored.mkdir()
  with sqlite3.connect(Path(tmp)/'backups'/created['file']) as source,sqlite3.connect(restored/'routeplan.db') as target:source.backup(target)
  env=os.environ.copy();env['ROUTEPLAN_DATA_DIR']=str(restored)
  command="import server;server.init_db();h=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);print(h.server_port,flush=True);h.serve_forever()"
  child=subprocess.Popen([sys.executable,'-c',command],cwd=Path(__file__).parent,env=env,stdout=subprocess.PIPE,text=True)
  original_url=url
  try:
   port=int(child.stdout.readline().strip());url=f'http://127.0.0.1:{port}/api/';restored_driver=client()
   assert call(restored_driver,'login',{'username':'drivertest','password':'test-only-password'})[0]==200
   recovered=call(restored_driver,'deliveries')[1]['deliveries'];assert len(recovered)==1 and recovered[0]['status']=='Delivered' and recovered[0]['proof_photo'].startswith('data:image/png')
   assert len(call(restored_driver,'delivery-route-plans')[1]['plans'])==1
  finally:url=original_url;child.terminate();child.wait(timeout=5)

  from server_lock import ServerLock
  with ServerLock(Path(tmp)):
   try:ServerLock(Path(tmp)).acquire()
   except RuntimeError:pass
   else:raise AssertionError('Concurrent server/restore lock accepted')
  assert call(admin,'users',{'username':'drivertest','role':'Driver','active':False})[0]==200
  assert call(driver,'deliveries')[0]==401
  print('PASS: roles/scopes, atomic delivery writes, idempotency, conflict detection, quantity rules, account disable, full backup/rehearsal and restore lock')
 finally:http.shutdown();http.server_close()
