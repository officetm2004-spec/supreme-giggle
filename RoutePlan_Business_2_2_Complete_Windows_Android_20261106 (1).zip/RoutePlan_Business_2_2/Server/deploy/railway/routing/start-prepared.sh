#!/bin/sh
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates curl >/dev/null
rm -rf /var/lib/apt/lists/*
mkdir -p /routing-data
curl -fL --retry 4 --connect-timeout 15 --max-time 300 -H "Authorization: Bearer $ROUTEPLAN_ROUTING_ARTIFACT_TOKEN" "$ROUTEPLAN_ROUTING_ARTIFACT_URL" -o /routing-data/country.tar.gz
printf '%s  %s\n' "$ROUTEPLAN_ROUTING_SHA256" /routing-data/country.tar.gz | sha256sum -c -
tar -xzf /routing-data/country.tar.gz -C /routing-data
rm /routing-data/country.tar.gz
echo ROUTEPLAN_PREPARED_GRAPH_VERIFIED
exec osrm-routed --algorithm mld --mmap --threads 1 --ip :: --port 5000 /routing-data/sri-lanka.osrm
