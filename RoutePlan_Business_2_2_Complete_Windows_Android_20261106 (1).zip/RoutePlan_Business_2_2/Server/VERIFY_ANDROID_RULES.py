"""Tests the actual Android origin-rule Java source on a JVM, not an emulator."""
import os,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sources=[ROOT/'Android_App_Source/app/src/main/java/com/routeplan/mobile/ServerAddress.java',ROOT/'tests/java/ServerAddressCheck.java']
with tempfile.TemporaryDirectory(prefix='routeplan_java_') as tmp:
    ecj=os.environ.get('ROUTEPLAN_ECJ_JAR');sdk=os.environ.get('ANDROID_HOME',os.environ.get('ANDROID_SDK_ROOT',''))
    if shutil.which('javac'):
        command=['javac','-encoding','UTF-8','--release','8','-d',tmp,*map(str,sources)]
    elif ecj and sdk:
        command=['java','-jar',ecj,'-source','8','-target','8','-proc:none','-encoding','UTF-8','-bootclasspath',str(Path(sdk)/'platforms/android-35/android.jar'),'-d',tmp,*map(str,sources)]
    else:raise SystemExit('SKIP: JDK javac or configured ECJ + Android SDK is required.')
    subprocess.run(command,check=True)
    subprocess.run(['java','-cp',tmp,'ServerAddressCheck'],check=True)
