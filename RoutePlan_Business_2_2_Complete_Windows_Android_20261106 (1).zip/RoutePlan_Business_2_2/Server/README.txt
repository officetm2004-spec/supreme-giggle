ROUTEPLAN 2.1 — DEVELOPMENT PACKAGE — 2026-11-06

All requested update modules are included in this development build.
Read 00_START_HERE_SI.txt first.
Android: Android_APK/RoutePlan-2.1-qa.apk is included and signature-verified.
Windows: START_ALL_UPDATES_TEST.bat uses an isolated development database.
Public HTTPS: docker-compose.public.yml + INTERNET_DEPLOYMENT_SI.txt.
Sri Lanka routing: routing/prepare_sri_lanka.py; data download/processing required.
Delivery statuses, offline queue/conflicts, role permissions and full automatic
backup/restore are included. Public hosting/domain and live service deployment
are not provisioned by this ZIP. Configure your server/domain before mobile-data use.
Physical-device/carrier/network/GPS/map acceptance remains BLOCKED by unavailable device access; see QA_REPORT_SI.md.
This package is not production-certified. See FINAL_ACCEPTANCE_CHECKLIST_SI.txt.

2.1 QA update: timeout/reconnect recovery, shared Android origin policy and
Connection diagnostics. See QA_REPORT_SI.md and QA_TEST_RESULTS.json.
Windows actual-device reports: RUN_WINDOWS_CODE_CHECKS.bat and RUN_WINDOWS_NETWORK_CHECK.bat.
