@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo RoutePlan - Shared Sales & Delivery Planner
echo ============================================================
where py >nul 2>nul
if %errorlevel%==0 (
  start "" /b powershell -NoProfile -Command "Start-Sleep -Seconds 2; Start-Process http://localhost:8080"
  py -3 server.py
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" /b powershell -NoProfile -Command "Start-Sleep -Seconds 2; Start-Process http://localhost:8080"
  python server.py
  goto :end
)
echo Python 3 is not installed or is not on PATH.
echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
echo During installation, tick "Add python.exe to PATH", then run this file again.
pause
:end
endlocal
