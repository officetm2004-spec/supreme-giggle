#!/usr/bin/env python3
"""RoutePlan shared LAN application. Python standard library only."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote
import math
from road_routes import road_route
import sys
import hashlib, hmac, json, os, secrets, sqlite3, time, re, mimetypes, uuid, socket, base64
from excel_plans import parse_xlsx
from auto_planning import reconcile as reconcile_plans, current_amounts, seed_original
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / 'static'
DATA_DIR = Path(os.environ.get('ROUTEPLAN_DATA_DIR', ROOT / 'data'))
DB_PATH = DATA_DIR / 'routeplan.db'
HOST = os.environ.get('ROUTEPLAN_HOST', '0.0.0.0')
PORT = int(os.environ.get('PORT', os.environ.get('ROUTEPLAN_PORT', '8080')))
SESSION_TTL = 8 * 60 * 60
MAX_BODY = 4_300_000
SESSIONS = {}  # token -> {user, expires}; sessions clear on restart
LOGIN_FAILURES = {}  # ip -> [timestamps]


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA busy_timeout=20000')
    return conn


def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with get_db() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
          CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY COLLATE NOCASE,
            salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            created_at TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS areas (
            name TEXT PRIMARY KEY COLLATE NOCASE
          );
          CREATE TABLE IF NOT EXISTS salesmen (
            no INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            area TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS plans (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('Sales','Delivery')),
            area TEXT NOT NULL,
            person TEXT NOT NULL DEFAULT '',
            start TEXT NOT NULL DEFAULT '08:00',
            status TEXT NOT NULL CHECK(status IN ('Planned','In Progress','Completed','Cancelled')),
            notes TEXT NOT NULL DEFAULT '',
            updated TEXT NOT NULL,
            updated_by TEXT NOT NULL DEFAULT ''
          );
          CREATE INDEX IF NOT EXISTS idx_plans_date ON plans(date, start);
          CREATE TABLE IF NOT EXISTS dispatch (
            area TEXT PRIMARY KEY COLLATE NOCASE,
            last_date TEXT NOT NULL DEFAULT '',
            reset_at TEXT NOT NULL DEFAULT ''
          );
          CREATE TABLE IF NOT EXISTS sales_entries (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL,
            salesman_no INTEGER NOT NULL,
            salesman_name TEXT NOT NULL,
            area TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount >= 0),
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            created_by TEXT NOT NULL DEFAULT ''
          );
          CREATE TABLE IF NOT EXISTS shops (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            area TEXT NOT NULL,
            address TEXT NOT NULL,
            latitude REAL,
            longitude REAL,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            updated_by TEXT NOT NULL DEFAULT ''
          );
          CREATE INDEX IF NOT EXISTS idx_shops_area ON shops(area, name COLLATE NOCASE);
          CREATE INDEX IF NOT EXISTS idx_sales_entries_date ON sales_entries(date);
          CREATE INDEX IF NOT EXISTS idx_sales_entries_area ON sales_entries(area, created_at);
          CREATE TABLE IF NOT EXISTS excel_plan_rows (
            row_no INTEGER PRIMARY KEY, salesman TEXT NOT NULL, route TEXT NOT NULL,
            salesman_total REAL NOT NULL, route_total REAL NOT NULL,
            priority TEXT NOT NULL, matched INTEGER NOT NULL, imported_at TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS excel_plan_priorities (
            row_no INTEGER PRIMARY KEY, salesman TEXT NOT NULL, route TEXT NOT NULL,
            salesman_total REAL NOT NULL, route_total REAL NOT NULL,
            status TEXT NOT NULL, rank TEXT NOT NULL, display_order INTEGER NOT NULL
          );
          CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT NOT NULL,
            username TEXT NOT NULL DEFAULT '',
            detail TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
          );
        ''')
        db.executescript("""
          CREATE TABLE IF NOT EXISTS customer_links (
            shop_id TEXT PRIMARY KEY REFERENCES shops(id) ON DELETE CASCADE,
            salesman_no INTEGER REFERENCES salesmen(no),
            verified_lat REAL, verified_lon REAL, verified_at TEXT,
            updated_by TEXT NOT NULL DEFAULT ''
          );
        """)
        # Upgrade existing databases safely; existing plans and login records are preserved.
        dispatch_columns = {r['name'] for r in db.execute('PRAGMA table_info(dispatch)')}
        if 'reset_at' not in dispatch_columns:
            db.execute("ALTER TABLE dispatch ADD COLUMN reset_at TEXT NOT NULL DEFAULT ''")
        # Seed master lists from the workbook-derived file once, without overwriting edits.
        if db.execute('SELECT COUNT(*) FROM areas').fetchone()[0] == 0 or db.execute('SELECT COUNT(*) FROM salesmen').fetchone()[0] == 0:
            source = STATIC / 'workbook_data.json'
            payload = json.loads(source.read_text(encoding='utf-8')) if source.exists() else {'areas': [], 'salesmen': [], 'dispatch': {}}
            if db.execute('SELECT COUNT(*) FROM areas').fetchone()[0] == 0:
                db.executemany('INSERT OR IGNORE INTO areas(name) VALUES (?)', [(str(a).strip(),) for a in payload.get('areas', []) if str(a).strip()])
            if db.execute('SELECT COUNT(*) FROM salesmen').fetchone()[0] == 0:
                db.executemany('INSERT OR IGNORE INTO salesmen(no,name,area) VALUES (?,?,?)', [(int(s['no']), str(s['name']).strip(), str(s['area']).strip()) for s in payload.get('salesmen', [])])
            if db.execute('SELECT COUNT(*) FROM dispatch').fetchone()[0] == 0:
                db.executemany('INSERT OR IGNORE INTO dispatch(area,last_date) VALUES (?,?)', [(str(a).strip(), str(d or '')) for a,d in payload.get('dispatch', {}).items()])
        # Keep all master areas represented in dispatch.
        db.execute("INSERT OR IGNORE INTO dispatch(area,last_date) SELECT name,'' FROM areas")
        seed_original(db,ROOT,utcnow())
        reconcile_plans(db,utcnow())


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode('utf-8'), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return salt, digest


def is_date(s):
    if not isinstance(s, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', s):
        return False
    try:
        datetime.strptime(s, '%Y-%m-%d')
        return True
    except ValueError:
        return False


def clean_text(value, maxlen=3000):
    if value is None:
        return ''
    if not isinstance(value, (str, int, float)):
        raise ValueError('Text field must be a string.')
    value = str(value).strip()
    if len(value) > maxlen:
        raise ValueError(f'Text is too long (maximum {maxlen} characters).')
    return value


class Handler(BaseHTTPRequestHandler):
    server_version = 'RoutePlan/1.0'

    def log_message(self, fmt, *args):
        # Avoid verbose request logs containing request details.
        print('[RoutePlan] ' + (fmt % args))

    def send_bytes(self, status, data, content_type='application/json; charset=utf-8', headers=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob: https://tiles.openfreemap.org; style-src 'self' 'unsafe-inline' https://unpkg.com; script-src 'self' 'unsafe-inline' https://unpkg.com; connect-src 'self' https://tiles.openfreemap.org; worker-src 'self' blob:; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def json(self, status, payload, headers=None):
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        self.send_bytes(status, body, 'application/json; charset=utf-8', headers)

    def read_json(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise ValueError('Invalid content length.')
        if length < 0 or length > MAX_BODY:
            raise ValueError('Request is too large.')
        raw = self.rfile.read(length) if length else b'{}'
        try:
            result = json.loads(raw.decode('utf-8'))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError('Invalid JSON request.')
        if not isinstance(result, dict):
            raise ValueError('Expected a JSON object.')
        return result

    def cookie_token(self):
        for part in self.headers.get('Cookie', '').split(';'):
            k, sep, v = part.strip().partition('=')
            if sep and k == 'routeplan_session':
                return v
        return ''

    def current_user(self):
        token = self.cookie_token()
        session = SESSIONS.get(token)
        if not session:
            return None
        if session['expires'] <= time.time():
            SESSIONS.pop(token, None)
            return None
        return session['user']

    def require_user(self):
        user = self.current_user()
        if not user:
            self.json(401, {'error': 'Your session has expired. Please sign in again.'})
            return None
        return user

    def audit(self, event, user='', detail=''):
        try:
            with get_db() as db:
                db.execute('INSERT INTO audit_log(event,username,detail,created_at) VALUES (?,?,?,?)',
                           (event[:80], user[:120], detail[:300], utcnow()))
        except Exception as exc:
            print('[RoutePlan] Audit write warning:', exc)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == '/api/status':
            with get_db() as db:
                initialized = db.execute('SELECT COUNT(*) FROM users').fetchone()[0] > 0
                areas = db.execute('SELECT COUNT(*) FROM areas').fetchone()[0]
                sales = db.execute('SELECT COUNT(*) FROM salesmen').fetchone()[0]
            self.json(200, {'initialized': initialized, 'areas': areas, 'salesmen': sales, 'serverTime': utcnow()})
            return
        if path == '/api/me':
            user = self.current_user()
            if user:
                self.json(200, {'authenticated': True, 'username': user})
            else:
                self.json(401, {'authenticated': False})
            return
        if path == '/api/customer-links':
            if not self.require_user(): return
            with get_db() as db:
                links = [dict(r) for r in db.execute('SELECT * FROM customer_links')]
            self.json(200, {'links':links}); return
        if path == '/api/data':
            user = self.require_user()
            if not user: return
            with get_db() as db:
                auto_planning=reconcile_plans(db,utcnow())
                areas = [r['name'] for r in db.execute('SELECT name FROM areas ORDER BY name COLLATE NOCASE')]
                salesmen = [dict(r) for r in db.execute('SELECT no,name,area FROM salesmen ORDER BY no')]
                plans = [dict(r) for r in db.execute('SELECT id,date,type,area,person,start,status,notes,updated,updated_by FROM plans ORDER BY date,start')]
                dispatch = {r['area']: {'date':r['last_date'], 'resetAt':r['reset_at']} for r in db.execute('SELECT area,last_date,reset_at FROM dispatch')}
                sales_entries = [dict(r) for r in db.execute('SELECT id,date,salesman_no,salesman_name,area,amount,notes,created_at,created_by FROM sales_entries ORDER BY date DESC, created_at DESC')]
                route_amounts = current_amounts(db)
                shops = [dict(r) for r in db.execute('SELECT id,name,area,address,latitude,longitude,notes,created_at,updated_at,updated_by FROM shops ORDER BY area COLLATE NOCASE,name COLLATE NOCASE')]
            self.json(200, {'source':'AMITH E (1).xlsx', 'areas':areas, 'salesmen':salesmen, 'plans':plans, 'dispatch':dispatch, 'salesEntries':sales_entries, 'routeAmounts':route_amounts, 'autoPlanning':auto_planning, 'shops':shops, 'serverTime':utcnow(), 'username':user})
            return
        if path == '/api/excel-plan':
            user = self.require_user()
            if not user:return
            with get_db() as db:
                entries=[dict(r) for r in db.execute('SELECT row_no AS no,salesman,route,salesman_total AS salesmanTotal,route_total AS routeTotal,priority,matched FROM excel_plan_rows ORDER BY row_no')]
                priorities=[dict(r) for r in db.execute('SELECT row_no AS no,salesman,route,salesman_total AS salesmanTotal,route_total AS routeTotal,status,rank FROM excel_plan_priorities ORDER BY display_order')]
            self.json(200, {'entries':entries,'priorities':priorities,'count':len(entries)})
            return
        if path == '/api/backup':
            user = self.require_user()
            if not user: return
            with get_db() as db:
                plans = [dict(r) for r in db.execute('SELECT id,date,type,area,person,start,status,notes,updated,updated_by FROM plans ORDER BY date,start')]
                dispatch = {r['area']:{'date':r['last_date'],'resetAt':r['reset_at']} for r in db.execute('SELECT area,last_date,reset_at FROM dispatch')}
                sales_entries = [dict(r) for r in db.execute('SELECT id,date,salesman_no,salesman_name,area,amount,notes,created_at,created_by FROM sales_entries ORDER BY date,created_at')]
                shops = [dict(r) for r in db.execute('SELECT id,name,area,address,latitude,longitude,notes,created_at,updated_at,updated_by FROM shops ORDER BY area COLLATE NOCASE,name COLLATE NOCASE')]
            with get_db() as db:
                links = [dict(r) for r in db.execute('SELECT * FROM customer_links')]
            data = {'customerLinks':links,'app':'RoutePlan','version':4,'exported':utcnow(),'plans':plans,'dispatch':dispatch,'salesEntries':sales_entries,'shops':shops}
            self.json(200, data, {'Content-Disposition': 'attachment; filename="routeplan-backup.json"'})
            return
        if path.startswith('/api/'):
            self.json(404, {'error':'Unknown API endpoint.'})
            return
        self.serve_static(path)

    def serve_static(self, path):
        if path in ('/', ''): path = '/index.html'
        path = unquote(path)
        full = (STATIC / path.lstrip('/')).resolve()
        try:
            full.relative_to(STATIC.resolve())
        except ValueError:
            self.send_bytes(403, b'Forbidden', 'text/plain; charset=utf-8'); return
        if not full.is_file():
            self.send_bytes(404, b'Not found', 'text/plain; charset=utf-8'); return
        # Never serve server-side data or database files from the static directory.
        content_type = mimetypes.guess_type(str(full))[0] or 'application/octet-stream'
        if content_type.startswith('text/') or content_type in ('application/javascript','application/json'):
            content_type += '; charset=utf-8'
        self.send_bytes(200, full.read_bytes(), content_type, {'Cache-Control':'no-cache'})

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            data = self.read_json()
            if path in ('/api/excel-preview','/api/excel-import'):
                user=self.require_user()
                if not user:return
                encoded=data.get('xlsxBase64','')
                if not isinstance(encoded,str) or len(encoded)>4_100_000:
                    self.json(400,{'error':'Upload a valid .xlsx file under 3 MB'});return
                try:
                    raw=base64.b64decode(encoded,validate=True)
                    parsed=parse_xlsx(raw)
                except (ValueError,KeyError,IndexError,OverflowError) as exc:
                    self.json(400,{'error':str(exc)[:250]});return
                if path=='/api/excel-preview':
                    self.json(200,parsed);return
                with get_db() as db:
                    # This import updates ONLY dedicated Excel snapshot tables.
                    # Shops, plans, sales, users, dispatch and locations remain untouched.
                    db.execute('DELETE FROM excel_plan_rows')
                    db.execute('DELETE FROM excel_plan_priorities')
                    stamp=utcnow()
                    db.executemany('INSERT INTO excel_plan_rows VALUES (?,?,?,?,?,?,?,?)',[(r['no'],r['salesman'],r['route'],r['salesmanTotal'],r['routeTotal'],r['priority'],int(r['matched']),stamp) for r in parsed['entries']])
                    db.executemany('INSERT INTO excel_plan_priorities VALUES (?,?,?,?,?,?,?,?)',[(r['no'],r['salesman'],r['route'],r['salesmanTotal'],r['routeTotal'],r['status'],r['rank'],i) for i,r in enumerate(parsed['priorities'])])
                self.audit('excel_plan_import',user,f"{len(parsed['entries'])} route rows, {len(parsed['priorities'])} priorities")
                self.json(200,{'ok':True,'count':len(parsed['entries']),'matchedCount':parsed['matchedCount'],'warnings':parsed['warnings']});return
            if path == '/api/setup':
                username = clean_text(data.get('username'), 40)
                password = data.get('password')
                if not re.fullmatch(r'[A-Za-z0-9._-]{3,40}', username):
                    self.json(400, {'error':'Username must be 3–40 characters using letters, numbers, dot, underscore or hyphen.'}); return
                if not isinstance(password, str) or len(password) < 10 or len(password) > 1024:
                    self.json(400, {'error':'Choose a password with at least 10 characters.'}); return
                with get_db() as db:
                    db.execute('BEGIN IMMEDIATE')
                    if db.execute('SELECT COUNT(*) FROM users').fetchone()[0] > 0:
                        self.json(409, {'error':'Initial setup is already complete. Sign in instead.'}); return
                    salt, digest = password_hash(password)
                    db.execute('INSERT INTO users(username,salt,password_hash,created_at) VALUES (?,?,?,?)', (username,salt,digest,utcnow()))
                self.audit('setup', username, 'Initial administrator created')
                self.new_session(username)
                return
            if path == '/api/login':
                username = clean_text(data.get('username'), 40)
                password = data.get('password')
                if not isinstance(password, str) or len(password) > 1024:
                    self.json(400, {'error':'Enter username and password.'}); return
                ip = self.client_address[0]
                now = time.time()
                recent = [t for t in LOGIN_FAILURES.get(ip, []) if now - t < 300]
                if len(recent) >= 8:
                    self.json(429, {'error':'Too many sign-in attempts. Try again in five minutes.'}); return
                with get_db() as db:
                    row = db.execute('SELECT username,salt,password_hash FROM users WHERE username=? COLLATE NOCASE AND active=1', (username,)).fetchone()
                ok = False
                if row:
                    _, digest = password_hash(password, row['salt'])
                    ok = hmac.compare_digest(digest, row['password_hash'])
                if not ok:
                    recent.append(now); LOGIN_FAILURES[ip] = recent
                    self.audit('login_failed', username, 'Invalid sign-in attempt')
                    self.json(401, {'error':'Incorrect username or password.'}); return
                LOGIN_FAILURES.pop(ip, None)
                self.audit('login', row['username'], 'Signed in')
                self.new_session(row['username'])
                return
            if path == '/api/logout':
                token = self.cookie_token()
                user = self.current_user() or ''
                SESSIONS.pop(token, None)
                self.json(200, {'ok':True}, {'Set-Cookie':'routeplan_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'})
                self.audit('logout', user, 'Signed out')
                return
            user = self.require_user()
            if not user: return
            if path == '/api/map-customer':
                editing=bool(data.get('id'))
                shop=self.validate_shop(data,user,require_id=editing)
                no=data.get('salesmanNo')
                if shop['latitude'] is None or shop['longitude'] is None: raise ValueError('Mark the customer location on the map.')
                if data.get('confirmLocation') is not True: raise ValueError('Confirm the marked location before saving.')
                with get_db() as db:
                    if isinstance(no,bool) or not isinstance(no,int) or not db.execute('SELECT 1 FROM salesmen WHERE no=?',(no,)).fetchone(): raise ValueError('Choose the customer salesman.')
                    if editing:
                        current=db.execute('SELECT * FROM shops WHERE id=?',(shop['id'],)).fetchone()
                        if not current: raise ValueError('Customer not found.')
                        if data.get('expectedUpdatedAt')!=current['updated_at']: raise ValueError('Customer changed on another device. Refresh before remarking.')
                        db.execute('UPDATE shops SET name=?,area=?,address=?,latitude=?,longitude=?,notes=?,updated_at=?,updated_by=? WHERE id=?',(shop['name'],shop['area'],shop['address'],shop['latitude'],shop['longitude'],shop['notes'],shop['updated_at'],user,shop['id']))
                    else:
                        db.execute('INSERT INTO shops(id,name,area,address,latitude,longitude,notes,created_at,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)',(shop['id'],shop['name'],shop['area'],shop['address'],shop['latitude'],shop['longitude'],shop['notes'],shop['created_at'],shop['updated_at'],user))
                    db.execute('INSERT INTO customer_links VALUES (?,?,?,?,?,?) ON CONFLICT(shop_id) DO UPDATE SET salesman_no=excluded.salesman_no,verified_lat=excluded.verified_lat,verified_lon=excluded.verified_lon,verified_at=excluded.verified_at,updated_by=excluded.updated_by',(shop['id'],no,shop['latitude'],shop['longitude'],utcnow(),user))
                self.audit('customer_location_marked',user,shop['id'])
                self.json(200 if editing else 201,{'ok':True,'shop':shop});return
            if path == '/api/customer-link':
                sid = data.get('shopId')
                no = data.get('salesmanNo')
                with get_db() as db:
                    shop = db.execute('SELECT * FROM shops WHERE id=?',(sid,)).fetchone()
                    if not shop: raise ValueError('Customer not found.')
                    if no is not None:
                        if isinstance(no,bool) or not isinstance(no,int) or not db.execute('SELECT 1 FROM salesmen WHERE no=?',(no,)).fetchone():
                            raise ValueError('Choose a valid salesman.')
                    old = db.execute('SELECT * FROM customer_links WHERE shop_id=?',(sid,)).fetchone()
                    lat,lon,stamp = (old['verified_lat'],old['verified_lon'],old['verified_at']) if old else (None,None,None)
                    if data.get('verify') is True:
                        lat,lon=shop['latitude'],shop['longitude']
                        if lat is None or lon is None or not math.isfinite(lat) or not math.isfinite(lon) or not (-90<=lat<=90 and -180<=lon<=180):
                            raise ValueError('Save valid GPS coordinates before confirming.')
                        stamp=utcnow()
                    db.execute('INSERT INTO customer_links VALUES (?,?,?,?,?,?) ON CONFLICT(shop_id) DO UPDATE SET salesman_no=excluded.salesman_no,verified_lat=excluded.verified_lat,verified_lon=excluded.verified_lon,verified_at=excluded.verified_at,updated_by=excluded.updated_by',(sid,no,lat,lon,stamp,user))
                self.audit('customer_link_updated',user,str(sid))
                self.json(200,{'ok':True}); return
            if path == '/api/road-route':
                ids=data.get('shopIds')
                no=data.get('salesmanNo')
                if not isinstance(ids,list) or not 1<=len(ids)<=40 or any(not isinstance(x,str) for x in ids) or len(set(ids))!=len(ids):
                    raise ValueError('Select 1 to 40 different customers.')
                with get_db() as db:
                    stops=[]
                    for sid in ids:
                        row=db.execute('SELECT s.*,l.salesman_no,l.verified_lat,l.verified_lon,l.verified_at FROM shops s JOIN customer_links l ON l.shop_id=s.id WHERE s.id=?',(sid,)).fetchone()
                        if not row or row['salesman_no']!=no: raise ValueError('Customer is not assigned to the selected salesman.')
                        if not row['verified_at'] or row['latitude']!=row['verified_lat'] or row['longitude']!=row['verified_lon']:
                            raise ValueError('Confirm current GPS for every selected customer.')
                        stops.append(dict(row))
                try: result=road_route(stops,data.get('depot'),data.get('returnToDepot') is True)
                except RuntimeError as exc:
                    self.json(503,{'error':str(exc)}); return
                self.json(200,result); return
            if path == '/api/shops':
                shop = self.validate_shop(data, user)
                with get_db() as db:
                    db.execute('INSERT INTO shops(id,name,area,address,latitude,longitude,notes,created_at,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)',
                               (shop['id'],shop['name'],shop['area'],shop['address'],shop['latitude'],shop['longitude'],shop['notes'],shop['created_at'],shop['updated_at'],user))
                self.audit('shop_created', user, shop['name'] + ' @ ' + shop['area'])
                self.json(201, {'ok':True,'shop':shop}); return
            if path == '/api/password':
                old_password = data.get('oldPassword')
                new_password = data.get('newPassword')
                if not isinstance(old_password, str) or not isinstance(new_password, str):
                    self.json(400, {'error':'Enter your current and new passwords.'}); return
                if len(new_password) < 10 or len(new_password) > 1024:
                    self.json(400, {'error':'Choose a new password with at least 10 characters.'}); return
                with get_db() as db:
                    row = db.execute('SELECT salt,password_hash FROM users WHERE username=? COLLATE NOCASE', (user,)).fetchone()
                    if not row:
                        self.json(401, {'error':'Account not found.'}); return
                    _, old_digest = password_hash(old_password, row['salt'])
                    if not hmac.compare_digest(old_digest, row['password_hash']):
                        self.json(400, {'error':'Current password is incorrect.'}); return
                    salt, digest = password_hash(new_password)
                    db.execute('UPDATE users SET salt=?,password_hash=? WHERE username=? COLLATE NOCASE', (salt,digest,user))
                self.audit('password_changed', user, 'Administrator password changed')
                self.json(200, {'ok':True}); return
            if path == '/api/plans':
                self.save_plan(data, user, creating=True); return
            if path == '/api/sales':
                sale_date = data.get('date')
                salesman_no = data.get('salesmanNo')
                try: amount = round(float(data.get('amount')), 2)
                except (TypeError, ValueError): raise ValueError('Enter a valid sales amount.')
                notes = clean_text(data.get('notes'), 1000)
                if not is_date(sale_date): raise ValueError('Choose a valid sales date.')
                if isinstance(salesman_no, bool) or not str(salesman_no).isdigit(): raise ValueError('Choose a salesman.')
                if amount < 0 or amount > 999999999: raise ValueError('Amount must be zero or greater and within the supported limit.')
                with get_db() as db:
                    salesman = db.execute('SELECT no,name,area FROM salesmen WHERE no=?', (int(salesman_no),)).fetchone()
                    if not salesman: raise ValueError('Choose a salesman from the list.')
                    entry_id = str(uuid.uuid4()); created = utcnow()
                    db.execute('INSERT INTO sales_entries(id,date,salesman_no,salesman_name,area,amount,notes,created_at,created_by) VALUES (?,?,?,?,?,?,?,?,?)',
                               (entry_id,sale_date,salesman['no'],salesman['name'],salesman['area'],amount,notes,created,user))
                    result=reconcile_plans(db,created)
                    auto_plan=result['created']>0
                self.audit('sales_entry_created', user, f"{sale_date} {salesman['name']} {amount:.2f}; auto plan={'yes' if auto_plan else 'existing'}")
                self.json(201, {'ok':True,'entry':{'id':entry_id,'date':sale_date,'salesman_no':salesman['no'],'salesman_name':salesman['name'],'area':salesman['area'],'amount':amount,'notes':notes,'created_at':created,'created_by':user},'autoPlanCreated':bool(auto_plan)})
                return
            if path == '/api/dispatch':
                area = clean_text(data.get('area'), 160)
                date = data.get('date', '') or ''
                if not area: self.json(400, {'error':'Area is required.'}); return
                if not date or not is_date(date): self.json(400, {'error':'Enter the route dispatch date. Saving it resets this route total to zero.'}); return
                reset_at = utcnow()
                with get_db() as db:
                    if not db.execute('SELECT 1 FROM areas WHERE name=? COLLATE NOCASE', (area,)).fetchone():
                        self.json(400, {'error':'Choose an area from the imported area list.'}); return
                    db.execute('INSERT INTO dispatch(area,last_date,reset_at) VALUES (?,?,?) ON CONFLICT(area) DO UPDATE SET last_date=excluded.last_date, reset_at=excluded.reset_at', (area,date,reset_at))
                    reconcile_plans(db,reset_at)
                self.audit('dispatch_updated', user, area + ':' + date + '; route amount reset')
                self.json(200, {'ok':True,'area':area,'date':date,'resetAt':reset_at,'amountReset':True}); return
            if path == '/api/restore':
                plans = data.get('plans')
                dispatch = data.get('dispatch')
                sales_entries = data.get('salesEntries', [])
                shops_data = data.get('shops')
                if not isinstance(plans, list) or not isinstance(dispatch, dict) or not isinstance(sales_entries, list) or (shops_data is not None and not isinstance(shops_data, list)):
                    self.json(400, {'error':'Backup file must contain valid plans and dispatch records.'}); return
                if len(plans) > 10000 or len(dispatch) > 200 or len(sales_entries) > 100000 or (shops_data is not None and len(shops_data) > 50000):
                    self.json(400, {'error':'Backup contains too many records.'}); return
                cleaned = [self.validate_plan(p, user, require_id=True) for p in plans]
                with get_db() as db:
                    known = {r['name'].lower() for r in db.execute('SELECT name FROM areas')}
                    if any(p['area'].lower() not in known for p in cleaned):
                        self.json(400, {'error':'Backup contains an unknown area. No data was changed.'}); return
                    clean_dispatch = []
                    for a,value in dispatch.items():
                        a = clean_text(a,160)
                        if isinstance(value, dict):
                            d = value.get('date') or ''; reset_at = value.get('resetAt') or ''
                        else:
                            d = value or ''; reset_at = ''
                        if a.lower() not in known or (d and not is_date(d)):
                            self.json(400, {'error':'Backup contains an invalid dispatch entry. No data was changed.'}); return
                        clean_dispatch.append((a,d,reset_at))
                    clean_shops = []
                    if shops_data is not None:
                        for item in shops_data:
                            try:
                                shop = self.validate_shop(item, user, require_id=True)
                            except ValueError as exc:
                                self.json(400, {'error':'Backup contains invalid shop data: ' + str(exc) + ' No data was changed.'}); return
                            clean_shops.append((shop['id'],shop['name'],shop['area'],shop['address'],shop['latitude'],shop['longitude'],shop['notes'],shop['created_at'],shop['updated_at'],shop['updated_by']))
                    clean_sales = []
                    for entry in sales_entries:
                        if not isinstance(entry, dict) or not is_date(entry.get('date')):
                            self.json(400, {'error':'Backup contains an invalid sales entry. No data was changed.'}); return
                        try: amount = round(float(entry.get('amount')), 2)
                        except (TypeError, ValueError): self.json(400, {'error':'Backup contains an invalid sales amount. No data was changed.'}); return
                        area = clean_text(entry.get('area'),160); name = clean_text(entry.get('salesman_name'),160)
                        no = int(entry.get('salesman_no') or 0)
                        if area.lower() not in known or amount < 0 or not name or not no:
                            self.json(400, {'error':'Backup contains invalid sales data. No data was changed.'}); return
                        clean_sales.append((clean_text(entry.get('id'),80) or str(uuid.uuid4()),entry['date'],no,name,area,amount,clean_text(entry.get('notes'),1000),clean_text(entry.get('created_at'),60) or utcnow(),clean_text(entry.get('created_by'),120)))
                    links_data=data.get('customerLinks')
                    if links_data is not None:
                        if not isinstance(links_data,list) or len(links_data)>50000: raise ValueError('Invalid customer links backup.')
                        valid_ids={x[0] for x in clean_shops} if shops_data is not None else {x['id'] for x in db.execute('SELECT id FROM shops')}
                        valid_nos={x['no'] for x in db.execute('SELECT no FROM salesmen')}
                        seen=set()
                        for link in links_data:
                            if not isinstance(link,dict) or link.get('shop_id') not in valid_ids or link.get('shop_id') in seen or (link.get('salesman_no') is not None and link.get('salesman_no') not in valid_nos): raise ValueError('Invalid customer assignment backup.')
                            seen.add(link['shop_id'])
                    db.execute('BEGIN IMMEDIATE')
                    db.execute('DELETE FROM plans')
                    db.executemany('INSERT INTO plans(id,date,type,area,person,start,status,notes,updated,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)',
                        [(p['id'],p['date'],p['type'],p['area'],p['person'],p['start'],p['status'],p['notes'],p['updated'],user) for p in cleaned])
                    db.execute("UPDATE dispatch SET last_date='', reset_at='' ")
                    db.executemany('INSERT INTO dispatch(area,last_date,reset_at) VALUES (?,?,?) ON CONFLICT(area) DO UPDATE SET last_date=excluded.last_date,reset_at=excluded.reset_at', clean_dispatch)
                    db.execute('DELETE FROM sales_entries')
                    db.executemany('INSERT INTO sales_entries(id,date,salesman_no,salesman_name,area,amount,notes,created_at,created_by) VALUES (?,?,?,?,?,?,?,?,?)', clean_sales)
                    if shops_data is not None:
                        db.execute('DELETE FROM shops')
                        db.executemany('INSERT INTO shops(id,name,area,address,latitude,longitude,notes,created_at,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)', clean_shops)
                    if links_data is not None:
                        db.execute('DELETE FROM customer_links')
                        # GPS confirmations require a fresh review after JSON restore.
                        db.executemany("INSERT INTO customer_links(shop_id,salesman_no,updated_by) VALUES (?,?,?)",[(x['shop_id'],x.get('salesman_no'),user) for x in links_data])
                self.audit('backup_restored' , user, f'{len(cleaned)} plans, {len(clean_sales)} sales entries and shops restore=' + ('included' if shops_data is not None else 'preserved'))
                self.json(200, {'ok':True,'plans':len(cleaned),'salesEntries':len(clean_sales),'shops':len(clean_shops) if shops_data is not None else None}); return
            self.json(404, {'error':'Unknown API endpoint.'})
        except ValueError as exc:
            self.json(400, {'error':str(exc)})
        except sqlite3.IntegrityError as exc:
            self.json(409, {'error':'This change conflicts with another saved record. Refresh the data and retry.'})
        except Exception as exc:
            print('[RoutePlan] Internal error:', repr(exc))
            self.json(500, {'error':'An unexpected server error occurred. Your data may not have been saved.'})

    def do_PUT(self):
        path = urlparse(self.path).path
        try:
            user = self.require_user()
            if not user: return
            data = self.read_json()
            if path == '/api/plans':
                self.save_plan(data, user, creating=False); return
            if path == '/api/shops':
                shop = self.validate_shop(data, user, require_id=True)
                with get_db() as db:
                    cur = db.execute('UPDATE shops SET name=?,area=?,address=?,latitude=?,longitude=?,notes=?,updated_at=?,updated_by=? WHERE id=?',
                                     (shop['name'],shop['area'],shop['address'],shop['latitude'],shop['longitude'],shop['notes'],shop['updated_at'],user,shop['id']))
                    if cur.rowcount == 0: self.json(404, {'error':'Shop not found. Refresh and try again.'}); return
                self.audit('shop_updated', user, shop['name'] + ' @ ' + shop['area'])
                self.json(200, {'ok':True,'shop':shop}); return
            self.json(404, {'error':'Unknown API endpoint.'})
        except ValueError as exc:
            self.json(400, {'error':str(exc)})
        except sqlite3.IntegrityError:
            self.json(409, {'error':'This change conflicts with another saved record. Refresh and retry.'})
        except Exception as exc:
            print('[RoutePlan] Internal error:', repr(exc))
            self.json(500, {'error':'Unexpected server error.'})

    def validate_shop(self, data, user, require_id=False):
        if not isinstance(data, dict): raise ValueError('Shop must be a JSON object.')
        sid = clean_text(data.get('id'), 80) or str(uuid.uuid4())
        name = clean_text(data.get('name'), 180)
        area = clean_text(data.get('area'), 160)
        address = clean_text(data.get('address'), 500)
        notes = clean_text(data.get('notes'), 1000)
        if require_id and not data.get('id'): raise ValueError('Shop ID is required for editing.')
        if not name: raise ValueError('Enter the shop name.')
        if not area: raise ValueError('Choose an area / route.')
        if not address: raise ValueError('Enter the shop address or map location.')
        with get_db() as db:
            if not db.execute('SELECT 1 FROM areas WHERE name=? COLLATE NOCASE', (area,)).fetchone():
                raise ValueError('Choose an area from the imported area list.')
        def coordinate(value, label, low, high):
            if value is None or str(value).strip() == '': return None
            try: number = float(value)
            except (TypeError, ValueError): raise ValueError('Enter a valid ' + label + '.')
            if not math.isfinite(number) or number < low or number > high: raise ValueError('The ' + label + ' is outside the valid range.')
            return number
        lat = coordinate(data.get('latitude'), 'latitude', -90, 90)
        lon = coordinate(data.get('longitude'), 'longitude', -180, 180)
        if (lat is None) != (lon is None): raise ValueError('Enter both latitude and longitude, or leave both blank.')
        now = utcnow()
        return {'id':sid,'name':name,'area':area,'address':address,'latitude':lat,'longitude':lon,'notes':notes,'created_at':clean_text(data.get('created_at'),60) or now,'updated_at':now,'updated_by':user}

    def validate_plan(self, data, user, require_id=False):
        if not isinstance(data, dict): raise ValueError('Plan must be a JSON object.')
        pid = clean_text(data.get('id'), 80) or str(uuid.uuid4())
        date = data.get('date')
        typ = clean_text(data.get('type'), 20)
        area = clean_text(data.get('area'), 160)
        person = clean_text(data.get('person'), 160)
        start = clean_text(data.get('start') or '08:00', 5)
        status = clean_text(data.get('status') or 'Planned', 30)
        notes = clean_text(data.get('notes'), 3000)
        if require_id and not data.get('id'): raise ValueError('Every restored plan must have an ID.')
        if not is_date(date): raise ValueError('Select a valid plan date.')
        if typ not in ('Sales','Delivery'): raise ValueError('Plan type must be Sales or Delivery.')
        if not area: raise ValueError('Select an area.')
        if start and not re.fullmatch(r'\d{2}:\d{2}', start): raise ValueError('Enter a valid start time.')
        if start and (int(start[:2]) > 23 or int(start[3:]) > 59): raise ValueError('Enter a valid start time.')
        if status not in ('Planned','In Progress','Completed','Cancelled'): raise ValueError('Choose a valid status.')
        with get_db() as db:
            if not db.execute('SELECT 1 FROM areas WHERE name=? COLLATE NOCASE', (area,)).fetchone():
                raise ValueError('Choose an area from the imported area list.')
            if person and not db.execute('SELECT 1 FROM salesmen WHERE name=? COLLATE NOCASE', (person,)).fetchone():
                raise ValueError('Choose a responsible person from the imported list, or choose Not assigned.')
        return {'id':pid,'date':date,'type':typ,'area':area,'person':person,'start':start,'status':status,'notes':notes,'updated':utcnow(),'updated_by':user}

    def save_plan(self, data, user, creating):
        plan = self.validate_plan(data, user)
        with get_db() as db:
            existing = db.execute('SELECT id FROM plans WHERE id=?', (plan['id'],)).fetchone()
            if creating and existing:
                plan['id'] = str(uuid.uuid4())
            elif not creating and not existing:
                self.json(404, {'error':'Plan not found. Refresh the plan list and try again.'}); return
            db.execute('''INSERT INTO plans(id,date,type,area,person,start,status,notes,updated,updated_by)
                VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,type=excluded.type,
                area=excluded.area,person=excluded.person,start=excluded.start,status=excluded.status,notes=excluded.notes,
                updated=excluded.updated,updated_by=excluded.updated_by''',
                (plan['id'],plan['date'],plan['type'],plan['area'],plan['person'],plan['start'],plan['status'],plan['notes'],plan['updated'],plan['updated_by']))
        self.audit('plan_created' if creating else 'plan_updated', user, f"{plan['date']} {plan['type']} {plan['area']}")
        self.json(201 if creating else 200, {'ok':True,'plan':plan})

    def new_session(self, username):
        token = secrets.token_urlsafe(32)
        # Opportunistically expire old sessions.
        now = time.time()
        for key in list(SESSIONS):
            if SESSIONS[key]['expires'] <= now: SESSIONS.pop(key, None)
        SESSIONS[token] = {'user':username,'expires':now + SESSION_TTL}
        self.json(200, {'ok':True,'username':username}, {'Set-Cookie':f'routeplan_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}' + ('; Secure' if os.environ.get('ROUTEPLAN_SECURE_COOKIES')=='1' else '')})

    def do_DELETE(self):
        path = urlparse(self.path).path
        try:
            user = self.require_user()
            if not user: return
            if path.startswith('/api/shops/'):
                sid = unquote(path.rsplit('/',1)[-1])
                if not sid or len(sid) > 80: self.json(400, {'error':'Invalid shop ID.'}); return
                with get_db() as db:
                    cur = db.execute('DELETE FROM shops WHERE id=?', (sid,))
                    if cur.rowcount == 0: self.json(404, {'error':'Shop not found.'}); return
                self.audit('shop_deleted', user, sid)
                self.json(200, {'ok':True}); return
            if path.startswith('/api/sales/'):
                sid = unquote(path.rsplit('/',1)[-1])
                if not sid or len(sid) > 80: self.json(400, {'error':'Invalid sales entry ID.'}); return
                with get_db() as db:
                    cur = db.execute('DELETE FROM sales_entries WHERE id=?', (sid,))
                    if cur.rowcount == 0: self.json(404, {'error':'Sales entry not found.'}); return
                    reconcile_plans(db,utcnow())
                self.audit('sales_entry_deleted', user, sid)
                self.json(200, {'ok':True}); return
            if path.startswith('/api/plans/'):
                pid = unquote(path.rsplit('/',1)[-1])
                if not pid or len(pid) > 80: self.json(400, {'error':'Invalid plan ID.'}); return
                with get_db() as db:
                    cur = db.execute('DELETE FROM plans WHERE id=?', (pid,))
                    if cur.rowcount == 0: self.json(404, {'error':'Plan not found.'}); return
                self.audit('plan_deleted', user, pid)
                self.json(200, {'ok':True}); return
            self.json(404, {'error':'Unknown API endpoint.'})
        except Exception as exc:
            print('[RoutePlan] Internal error:', repr(exc))
            self.json(500, {'error':'Unexpected server error.'})


def main():
    from backup_service import start as start_backups
    from server_lock import ServerLock
    lock = ServerLock(DATA_DIR)
    lock.acquire()
    init_db()
    if os.environ.get('ROUTEPLAN_VERIFY_RESTORE_ON_START')=='1':
        from backup_service import create_backup
        from restore_full_backup import compare_restored
        try:
            saved=create_backup(DB_PATH,DATA_DIR)
            source=Path(os.environ.get('ROUTEPLAN_BACKUP_DIR',str(DATA_DIR/'backups')))/saved['file']
            verified=compare_restored(source);verified['checkedAt']=utcnow()
        except Exception as exc:verified={'result':'FAIL','checkedAt':utcnow(),'error':str(exc)}
        (DATA_DIR/'backup_restore_verification.json').write_text(json.dumps(verified))
        print('[RoutePlan] RESTORE_VERIFICATION '+json.dumps(verified),flush=True)
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    stop_backups = start_backups(DB_PATH, DATA_DIR)
    print('=' * 60)
    print('RoutePlan Sales & Delivery is running')
    print(f'Host bind: {HOST}:{PORT}')
    print(f'Shared SQLite database: {DB_PATH}')
    print('Windows PC: http://localhost:%s' % PORT)
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(('192.0.2.1', 80))  # determines the active LAN interface; sends no data
        lan_ip = probe.getsockname()[0]
        probe.close()
        print('Phone / other PC (same Wi-Fi): http://%s:%s' % (lan_ip, PORT))
    except OSError:
        print('Phone / other PC: use this PC IPv4 address from ipconfig, port %s.' % PORT)
    print('First visit: create the administrator account. Keep this server running.')
    print('Press Ctrl+C to stop the server.')
    print('=' * 60)
    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print('\nRoutePlan server stopping...')
    finally:
        stop_backups.set()
        httpd.server_close()
        lock.release()

from operations import install as install_operations
install_operations(sys.modules[__name__])

if __name__ == '__main__':
    main()
