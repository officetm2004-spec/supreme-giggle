ROUTEPLAN 2.1 — සම්පූර්ණ UPDATE DEVELOPMENT PACKAGE
දිනය: 2026-11-06

මෙම package එකේ ඉල්ලූ updates එකතු කර තිබේ. සැබෑ Windows/Android,
customer GPS, map rendering සහ වෙන වෙනම Internet connections යටතේ
සම්පූර්ණ acceptance පරීක්ෂාවට මෙහි සෘජු Windows/Android ප්‍රවේශය නොලැබුණි.
QA_REPORT_SI.md හි කළ පරීක්ෂණ හා BLOCKED device පරීක්ෂණ වෙන්කර තිබේ.
මෙය Production-certified release එකක් නොවේ.

ඇතුළත් දේ
1. Salesman → Customer සෘජු assignments සහ saved GPS.
2. MapLibre 6.16 vector map, custom shop/delivery/depot/draft icons.
3. Map click/drag මගින් customer location අලුතින් සලකුණු කිරීම සහ remark කිරීම.
4. OSRM road distance/time/road-line සම්බන්ධතාව සහ Sri Lanka data preparation.
5. Android_APK/RoutePlan-2.1-qa.apk — install කළ හැකි signed development APK.
6. Phone GPS permission/fresh fix, uploads, document downloads, HTTPS server setup.
7. Pending / Delivered / Failed / Partial deliveries, quantities සහ event history.
8. Offline delivery notes, same-account sync, retry idempotency, conflict review.
9. Admin / Salesman / Driver accounts සහ server-side data permissions.
10. Startup/periodic full SQLite backup සහ locked restore/rehearsal tool.
11. LAN HTTPS සහ public Internet HTTPS deployment ගොනු.

WINDOWS LOCAL DEVELOPMENT
- අලුත් folder එකකට extract කරන්න. මුල් installation/data overwrite නොකරන්න.
- Python 3.10+ අවශ්‍යයි.
- START_ALL_UPDATES_TEST.bat run කරන්න → http://localhost:8082.
- පළමු Admin account එක සාදන්න.
- Data & Backup → Users & Permissions තුළ Salesman සහ Driver accounts සාදන්න.
- Admin හට සියල්ල; Salesman හට තම customer/sales/delivery දත්ත;
  Driver හට තමන්ට assign කළ deliveries සහ අදාළ customers පමණක්.
- Local road routing අවශ්‍ය නම් මුලින් python routing/prepare_sri_lanka.py
  ක්‍රියාත්මක කර START_SRI_LANKA_ROUTING.bat වෙනම window එකක run කරන්න.
  Local test launcher එක default http://127.0.0.1:5000 භාවිත කරයි.
- මෙහි test DB: data_release_candidate_test/routeplan.db.
- HTTP local mode එක native GPS menu හැර browser GPS/offline restart සඳහා ප්‍රමාණවත් නොවේ.

CUSTOMERS / MAPS
- Shop Directory → Open map → Mark new customer.
- නම, salesman, area, ලිපිනය ඇතුළත් කර map එකේ නිවැරදි ස්ථානය click කරන්න.
- Pink draft pin එක drag කර refine කරන්න; confirm කර save කරන්න.
- පරණ customer dropdown එකෙන් Re-mark selected customer භාවිත කළ හැකියි.
- පරණ coordinates ස්වයංක්‍රීයව confirmed බවට පත් නොකරයි.
- CUSTOMER_LOCATION_MAP_SI.txt සහ MODERN_MAPS_SI.txt බලන්න.

DELIVERIES
- Admin/Salesman: Delivery Workspace → Create delivery.
- Assigned customer, active Driver, date සහ planned quantity තෝරන්න.
- Driver: තම account එකෙන් sign in → Update.
- Delivered: සම්පූර්ණ quantity; Partial: 0 සහ planned අතර quantity + හේතුව;
  Failed: quantity 0 + හේතුව; Pending: quantity 0.
- Account හෝ delivery වෙනස්කම් server එකෙන්ම අවසර පරීක්ෂා කරයි.

OFFLINE
- HTTPS භාවිත කර Delivery Workspace එක online දී අවම වරක් විවෘත කරන්න.
- එවිට එම account එකේ deliveries මෙම device එකේ සුරැකේ.
- Network නැති විට Offline workspace විවෘත කර දැනට ලැබුණු deliveries වල
  status/quantity/notes save කළ හැකියි. DEVICE ONLY ලෙස පෙන්වයි.
- Network ලැබුණු විට එම account එකටම sync කරයි; session expired නම් login කරන්න.
- එකම record එක වෙනත් device එකකින් වෙනස් වී ඇත්නම් server record සහ
  device note පෙන්වයි. Keep server හෝ Review and reapply තෝරන්න.
- Unsynced notes export කළ හැකියි. Device/browser storage clear කිරීමෙන්
  unsynced notes නැති වේ. Online create/import/user administration offline නැහැ.
- Offline mode cached delivery සටහන් සඳහායි; maps/navigation offline නොවේ.
- Browser sign out පසු cached workspace වෙත නැවත පිවිසීමට online sign in අවශ්‍යයි.

ANDROID / වෙනත් Wi-Fi / MOBILE DATA
- Android_APK/RoutePlan-2.1-qa.apk install කරන්න (Android 8+).
- Office LAN address එකකට වෙනත් Internet connection එකකින් පිවිසිය නොහැකියි.
- INTERNET_DEPLOYMENT_SI.txt අනුව public HTTPS server එක සකසා,
  app එකට https://ඔබගේ-domain එක ඇතුළත් කරන්න.
- App එක එම domain එක office Wi-Fi, වෙනත් Wi-Fi හෝ mobile data යටතේ භාවිත කරයි.
- Network නැවත ලැබෙන විට sync උත්සාහ කරයි. Background continuous tracking නැහැ.
- Phone GPS: customer marking mode → Use phone GPS හෝ Android menu → Phone GPS.
- GPS accuracy බලලා location confirm කරන්න. අනුමාන customer coordinates ඇතුළත් නොවේ.

BACKUP
- Server startup එකේ සහ පැය 6කට වරක් full backup; අලුත්ම 30 රඳවා තබයි.
- ROUTEPLAN_BACKUP_HOURS / ROUTEPLAN_BACKUP_KEEP / ROUTEPLAN_BACKUP_DIR මගින් සකසන්න.
- Data & Backup → Full Backup & System: download / backup now / status.
- Full SQLite backup එක users, GPS, assignments, deliveries, event history රකී.
- පරණ JSON backup එක සම්පූර්ණ backup එකක් නොවේ. Deliveries තිබේ නම් JSON restore අවහිරයි.
- Restore පෙර server නවත්වන්න. RESTORE_FULL_BACKUP.bat හෝ
  python restore_full_backup.py backup.sqlite3 --data-dir DATA_FOLDER
  මගින් rehearsal කරන්න; සැබෑ restore සඳහා --restore එක් කරන්න.
- Existing DB එක restore කරන විට pre-restore backup එකක්ද ගනී.

අවසාන actual-device පරීක්ෂණ: FINAL_ACCEPTANCE_CHECKLIST_SI.txt.
සංවර්ධන පරීක්ෂණ තත්ත්ව: DEVELOPMENT_CHECKS.txt.

2.1 QA update: timeout/reconnect recovery, shared Android origin policy and
Connection diagnostics. See QA_REPORT_SI.md and QA_TEST_RESULTS.json.
Windows actual-device reports: RUN_WINDOWS_CODE_CHECKS.bat and RUN_WINDOWS_NETWORK_CHECK.bat.
