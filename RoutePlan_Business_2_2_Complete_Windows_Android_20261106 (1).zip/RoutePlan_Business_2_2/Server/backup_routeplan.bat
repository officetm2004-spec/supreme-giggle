@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 backup_database.py
  goto :done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python backup_database.py
  goto :done
)
echo Python 3 is not installed or is not on PATH.
echo Use the same Python installation used to start RoutePlan.
pause
exit /b 1
:done
pause
endlocal
