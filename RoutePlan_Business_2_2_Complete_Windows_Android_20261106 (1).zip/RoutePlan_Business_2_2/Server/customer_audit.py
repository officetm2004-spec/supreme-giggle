"""Read-only checks; possible duplicates always require human review."""
import math,re

def audit(db):
 rows=[dict(r) for r in db.execute('SELECT s.*,l.salesman_no,l.verified_lat,l.verified_lon,l.verified_at FROM shops s LEFT JOIN customer_links l ON l.shop_id=s.id')];issues=[];groups={}
 for r in rows:
  reasons=[];lat,lon=r['latitude'],r['longitude']
  if r['salesman_no'] is None:reasons.append('Salesman assignment missing')
  if lat is None or lon is None:reasons.append('GPS missing')
  elif not all(isinstance(x,(int,float)) and math.isfinite(x) for x in (lat,lon)) or not -90<=lat<=90 or not -180<=lon<=180:reasons.append('GPS invalid')
  elif not (5.7<=lat<=10 and 79.4<=lon<=82.1):reasons.append('GPS outside Sri Lanka review bounds')
  elif not r['verified_at'] or lat!=r['verified_lat'] or lon!=r['verified_lon']:reasons.append('GPS confirmation missing or changed')
  key=re.sub(r'\W+','',r['name'].casefold())
  groups.setdefault(key,[]).append(r['id'])
  if reasons:issues.append({'id':r['id'],'name':r['name'],'reasons':reasons})
 dup=[ids for name,ids in groups.items() if name and len(ids)>1]
 return {'total':len(rows),'issues':issues,'possibleDuplicateGroups':dup,'note':'Read-only review. Name similarity is not proof of duplication; GPS bounds do not verify a physical shop.'}
