"""Validate/rehearse or restore a full SQLite backup while RoutePlan is stopped."""
import argparse,os,sqlite3,tempfile
from pathlib import Path
from server_lock import ServerLock
from backup_service import create_backup
ROOT=Path(__file__).resolve().parent
REQUIRED={'users','shops','salesmen','plans','customer_links','deliveries','delivery_events'}
def validate(path):
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Database integrity check failed.')
        names={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED<=names:raise ValueError('Full backup is missing required application tables.')
        return {name:db.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in sorted(REQUIRED)}
def rehearse(source):
    validate(source)
    with tempfile.TemporaryDirectory(prefix='routeplan_restore_') as tmp:
        dest=Path(tmp)/'rehearsal.sqlite3'
        with sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(dest) as dst:src.backup(dst)
        return validate(dest)
def compare_restored(source):
    """Restore a consistent full backup into an isolated installation and compare every table."""
    import hashlib,json
    def digest(path):
        result={}
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
            schema=db.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()
            result['schema']=hashlib.sha256(repr(schema).encode()).hexdigest()
            for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
                safe='"'+name.replace('"','""')+'"';rows=sorted(repr(tuple(r)) for r in db.execute('SELECT * FROM '+safe))
                result[name]={'rows':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
        return result
    validate(source)
    with tempfile.TemporaryDirectory(prefix='routeplan_new_installation_') as tmp:
        target=Path(tmp)/'data';target.mkdir();dest=target/'routeplan.db'
        with sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(dest) as dst:src.backup(dst)
        validate(dest);before=digest(source);after=digest(dest)
        if before!=after:raise ValueError('Restored database does not match the backup snapshot.')
        return {'result':'PASS','tablesCompared':len(before)-1,'tables':{k:v['rows'] for k,v in before.items() if k!='schema'},'schemaMatched':True,'allRowsMatched':True,'scope':'Isolated new data directory restored from a consistent full backup; application/device acceptance is separate'}

def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--restore',action='store_true');p.add_argument('--data-dir',type=Path,default=Path(os.environ.get('ROUTEPLAN_DATA_DIR',ROOT/'data')));args=p.parse_args()
    result=rehearse(args.source)
    print('Backup validation and isolated restore rehearsal: OK',result)
    if not args.restore:
        print('Live database unchanged. Add --restore only after stopping RoutePlan.');return
    data=args.data_dir.resolve();target=data/'routeplan.db'
    with ServerLock(data):
        if args.source.resolve()==target:raise ValueError('Source must be a separate backup file.')
        if target.exists():print('Pre-restore backup:',create_backup(target,data)['file'])
        # Backup API safely replaces database contents; no WAL sidecar file copying.
        with sqlite3.connect(args.source.resolve().as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(target,timeout=30) as dst:src.backup(dst)
        print('Restored:',validate(target))
if __name__=='__main__':main()
