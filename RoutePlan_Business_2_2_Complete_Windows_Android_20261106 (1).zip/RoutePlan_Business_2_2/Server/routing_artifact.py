"""Restricted transfer of one public OSM routing archive between owned services.
No customer records, filesystem paths or executable source are accepted.
"""
import base64,hashlib,hmac,os,shutil,threading
_LOCK=threading.Lock()

def handle(handler,verb,app,path):
    token=os.environ.get('ROUTEPLAN_ROUTING_ARTIFACT_TOKEN','')
    supplied=handler.headers.get('Authorization','')
    if not token or not hmac.compare_digest(supplied.encode(),('Bearer '+token).encode()):
        handler.json(403,{'error':'Routing artifact authorization required.'});return
    folder=app.DATA_DIR/'routing';folder.mkdir(exist_ok=True);target=folder/'country.tar.gz';part=folder/'country.partial'
    if verb=='GET' and path.endswith('-status'):
        result={'offset':part.stat().st_size if part.exists() else 0,'ready':target.exists()}
        preset=handler.headers.get('X-Routing-Test')
        cases={'colombo':[(79.8428,6.9344),(79.8612,6.9271)],'kandy':[(79.8612,6.9271),(80.6337,7.2906)],'country':[(80.0255,9.6615),(80.217,6.0535)]}
        if preset in cases:
            from road_routes import query
            points=[{'longitude':lon,'latitude':lat} for lon,lat in cases[preset]]
            try:
                route=query('route',points,'overview=full&geometries=geojson&steps=false')['routes'][0]
                result['probe']={'case':preset,'result':'PASS','distanceKm':route['distance']/1000,'minutes':route['duration']/60,'geometryPoints':len(route['geometry']['coordinates'])}
            except Exception as exc:result['probe']={'case':preset,'result':'FAIL','error':str(exc)}
        handler.json(200,result);return
    if verb=='GET':
        if not target.exists():handler.json(404,{'error':'Routing artifact not uploaded.'});return
        handler.send_response(200);handler.send_header('Content-Type','application/gzip');handler.send_header('Content-Length',str(target.stat().st_size));handler.send_header('Cache-Control','no-store');handler.end_headers()
        with target.open('rb') as source:shutil.copyfileobj(source,handler.wfile,128*1024)
        return
    if verb!='POST' or os.environ.get('ROUTEPLAN_ROUTING_UPLOAD') not in ('1','binary'):handler.json(403,{'error':'Artifact upload disabled.'});return
    try:
        binary=handler.headers.get('Content-Type','')=='application/octet-stream'
        if os.environ.get('ROUTEPLAN_ROUTING_UPLOAD')=='binary' and not binary:
            handler.json(403,{'error':'Use binary artifact transport.'});return
        if binary:
            length=int(handler.headers.get('Content-Length','0'))
            if not 0<length<=16000000:raise ValueError('Invalid binary chunk size.')
            offset=int(handler.headers.get('X-Routing-Offset','-1'));total=int(handler.headers.get('X-Routing-Total','-1'));chunk=handler.rfile.read(length)
            if len(chunk)!=length:raise ValueError('Incomplete binary chunk.')
        else:
            data=handler.read_json();offset=data.get('offset');total=data.get('total');chunk=base64.b64decode(data.get('chunk',''),validate=True)
        if type(offset)!=int or type(total)!=int or not 0<=offset<=total<=240000000:raise ValueError('Invalid artifact size or offset.')
        if len(chunk)>16000000 or offset+len(chunk)>total:raise ValueError('Invalid chunk length.')
        with _LOCK:
            actual=part.stat().st_size if part.exists() else 0
            if offset!=actual:handler.json(409,{'error':'Offset mismatch','offset':actual});return
            with part.open('ab') as out:out.write(chunk)
            ready=offset+len(chunk)==total
            if ready:
                digest=hashlib.file_digest(part.open('rb'),'sha256').hexdigest()
                expected=os.environ.get('ROUTEPLAN_ROUTING_SHA256','')
                if not expected or digest!=expected:raise ValueError('Routing archive checksum does not match configured checksum.')
                part.replace(target)
        handler.json(200,{'offset':offset+len(chunk),'ready':ready})
    except (ValueError,TypeError) as exc:handler.json(400,{'error':str(exc)})
