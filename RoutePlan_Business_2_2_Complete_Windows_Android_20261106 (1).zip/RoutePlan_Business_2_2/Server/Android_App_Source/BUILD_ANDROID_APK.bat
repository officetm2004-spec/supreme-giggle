@echo off
setlocal
cd /d "%~dp0"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
echo Requires JDK 17+ plus Android SDK platform 35 and build-tools 35.0.0.
python build_apk.py
pause
endlocal
