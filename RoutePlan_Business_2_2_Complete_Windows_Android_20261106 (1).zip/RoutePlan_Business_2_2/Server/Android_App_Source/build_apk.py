"""Build the non-debuggable RoutePlan Business APK with the owner's private release key."""
import os,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sdk=Path(os.environ.get('ANDROID_HOME',os.environ.get('ANDROID_SDK_ROOT','')))
tools=sdk/'build-tools/35.0.0';platform=sdk/'platforms/android-35/android.jar'
if not platform.is_file() or not tools.is_dir():raise SystemExit('Install SDK platform android-35 and build-tools 35.0.0; set ANDROID_HOME.')
key=Path(os.environ.get('ROUTEPLAN_RELEASE_KEYSTORE',''))
if not key.is_file() or not os.environ.get('ROUTEPLAN_RELEASE_STORE_PASSWORD') or not os.environ.get('ROUTEPLAN_RELEASE_KEY_PASSWORD'):raise SystemExit('Set ROUTEPLAN_RELEASE_KEYSTORE, ROUTEPLAN_RELEASE_STORE_PASSWORD and ROUTEPLAN_RELEASE_KEY_PASSWORD. Never use a development key.')
build=ROOT/'build/manual';build.mkdir(parents=True,exist_ok=True)
classes=build/'classes';dex=build/'dex';classes.mkdir(exist_ok=True);dex.mkdir(exist_ok=True)
res=ROOT/'app/src/main/res';manifest=build/'AndroidManifest.xml'
manifest.write_text((ROOT/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest ', '<manifest package="com.routeplan.business" ',1))
def run(*args):subprocess.run([str(x) for x in args],check=True)
def tool(name):return tools/(name+('.exe' if os.name=='nt' else ''))
run(tool('aapt2'),'compile','--dir',res,'-o',build/'resources.zip')
run(tool('aapt2'),'link','-o',build/'base.apk','-I',platform,'--manifest',manifest,'--min-sdk-version','26','--target-sdk-version','35','--version-code','4','--version-name','2.2-business',build/'resources.zip')
sources=list((ROOT/'app/src/main/java').rglob('*.java'));ecj=os.environ.get('ROUTEPLAN_ECJ_JAR')
if ecj:run('java','-jar',ecj,'-source','8','-target','8','-proc:none','-encoding','UTF-8','-bootclasspath',str(platform)+os.pathsep+str(tools/'core-lambda-stubs.jar'),'-d',classes,*sources)
else:run('javac','-encoding','UTF-8','--release','17','-classpath',platform,'-d',classes,*sources)
with zipfile.ZipFile(build/'classes.jar','w',zipfile.ZIP_DEFLATED) as jar:
 for path in classes.rglob('*.class'):jar.write(path,path.relative_to(classes))
run('java','-cp',tools/'lib/d8.jar','com.android.tools.r8.D8','--lib',platform,'--min-api','26','--output',dex,build/'classes.jar')
with zipfile.ZipFile(build/'base.apk','a',zipfile.ZIP_DEFLATED) as apk:
 for path in dex.glob('*.dex'):apk.write(path,path.name)
run(tool('zipalign'),'-f','4',build/'base.apk',build/'aligned.apk')
output=Path(os.environ.get('ROUTEPLAN_APK_OUTPUT',str(ROOT.parent/'Android_APK/RoutePlan-Business-2.2.apk')));output.parent.mkdir(parents=True,exist_ok=True)
run('java','-jar',tools/'lib/apksigner.jar','sign','--ks',key,'--ks-key-alias','routeplan-business','--ks-pass','env:ROUTEPLAN_RELEASE_STORE_PASSWORD','--key-pass','env:ROUTEPLAN_RELEASE_KEY_PASSWORD','--out',output,build/'aligned.apk')
run('java','-jar',tools/'lib/apksigner.jar','verify','--verbose','--print-certs',output)
print('Business release APK:',output)
