RoutePlan Android 2.1 Development APK

Installable APK: ../Android_APK/RoutePlan-2.1-qa.apk (Android 8+).
HTTPS public origin supports office Wi-Fi, other Wi-Fi and mobile data when the
server is Internet reachable. Enter an origin such as https://your-domain.
Network reconnect triggers delivery sync; failed requests retain device notes.
Phone GPS menu requests a fresh fix and runtime permission; manual marking remains.
Excel chooser and authenticated downloads use Android's document picker.
Office local HTTPS supports a user-installed office CA; SSL errors are not ignored.
A visible action-bar menu provides Phone GPS / Offline deliveries / Refresh /
Change server address. Browser WebGL and online map access are still required.
Development key is included only for repeatable development builds. Use a private
release signing key for a production distribution. Real phone QA is BLOCKED: no connected Android device. See QA_REPORT_SI.md.

Build: Android Studio/Gradle with JDK 17 + platform35, or BUILD_ANDROID_APK.bat
and build_apk.py with ANDROID_HOME pointing to an installed SDK.
This APK was built using Android SDK aapt2/d8/zipalign/apksigner plus Eclipse ECJ.

2.1 QA update: timeout/reconnect recovery, shared Android origin policy and
Connection diagnostics. See QA_REPORT_SI.md and QA_TEST_RESULTS.json.
Windows actual-device reports: RUN_WINDOWS_CODE_CHECKS.bat and RUN_WINDOWS_NETWORK_CHECK.bat.
