package com.routeplan.mobile;
import java.net.URI;
import java.util.Locale;
/** Pure Java origin rules, shared by setup, downloads and the GPS callback. */
public final class ServerAddress {
 private ServerAddress(){}
 public static boolean valid(String value){try{
  URI u=new URI(value.trim());String scheme=u.getScheme();
  if(scheme==null||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null||!(u.getPath().isEmpty()||u.getPath().equals("/")))return false;
  if(u.getPort()!=-1&&(u.getPort()<1||u.getPort()>65535))return false;
  if("https".equalsIgnoreCase(scheme))return true;
  if(!"http".equalsIgnoreCase(scheme))return false;
  String[] parts=u.getHost().split("\\.");if(parts.length!=4)return false;int[] n=new int[4];
  for(int i=0;i<4;i++){if(!parts[i].matches("[0-9]{1,3}")||(parts[i].length()>1&&parts[i].startsWith("0")))return false;n[i]=Integer.parseInt(parts[i]);if(n[i]>255)return false;}
  return n[0]==10||(n[0]==172&&n[1]>=16&&n[1]<=31)||(n[0]==192&&n[1]==168);
 }catch(Exception e){return false;}}
 public static String normalize(String value){if(!valid(value))throw new IllegalArgumentException("Invalid server address");try{URI u=new URI(value.trim());return new URI(u.getScheme().toLowerCase(Locale.ROOT),null,u.getHost().toLowerCase(Locale.ROOT),u.getPort(),null,null,null).toString();}catch(Exception e){throw new IllegalArgumentException(e);}}
 private static int port(URI value){return value.getPort()<0?("https".equalsIgnoreCase(value.getScheme())?443:80):value.getPort();}
 public static boolean sameOrigin(String value,String base){try{URI u=new URI(value),v=new URI(base);return u.getUserInfo()==null&&v.getUserInfo()==null&&("https".equalsIgnoreCase(u.getScheme())||"http".equalsIgnoreCase(u.getScheme()))&&u.getScheme().equalsIgnoreCase(v.getScheme())&&u.getHost()!=null&&v.getHost()!=null&&u.getHost().equalsIgnoreCase(v.getHost())&&port(u)==port(v);}catch(Exception e){return false;}}
}
