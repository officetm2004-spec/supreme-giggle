package com.routeplan.mobile;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.location.*;
import android.webkit.*;
import android.widget.*;
import android.view.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
 private ConnectivityManager connectivity; private ConnectivityManager.NetworkCallback networkCallback;
 private WebView web; private ValueCallback<Uri[]> chooser;
 private static final int PICK=22, SAVE=23, LOCATION=24;
 private long lastGpsFixAt=0; private float lastGpsAccuracy=0;
 private boolean pageFailed=false;
 private String base="", pendingText, pendingUrl, pendingCookie;
 private GeolocationPermissions.Callback geoCallback;private String geoOrigin;
 private LocationManager manager; private LocationListener listener;
 private final Handler timer=new Handler(Looper.getMainLooper());
 @Override public void onCreate(Bundle b){super.onCreate(b);base=getPreferences(0).getString("server","https://routeplan-web-production.up.railway.app");if(!base.isEmpty()){try{base=ServerAddress.normalize(base);}catch(Exception e){base="";}}if(base.isEmpty())showSetup();else startWeb();connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);networkCallback=new ConnectivityManager.NetworkCallback(){@Override public void onAvailable(Network network){runOnUiThread(()->{if(web!=null&&sameOrigin(web.getUrl()))web.evaluateJavascript("window.dispatchEvent(new Event('online'));",null);});}};connectivity.registerDefaultNetworkCallback(networkCallback);}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 private boolean sameOrigin(String value){return ServerAddress.sameOrigin(value,base);}
 private boolean validAddress(String value){return ServerAddress.valid(value)&&value.trim().toLowerCase(java.util.Locale.ROOT).startsWith("https://");}
 private void showSetup(){EditText input=new EditText(this);input.setSingleLine(true);input.setHint("https://192.168.1.6");input.setText(base);new AlertDialog.Builder(this).setTitle("RoutePlan server").setMessage("Use your trusted HTTPS server. This Business build uses HTTPS for shared data, offline workspace and GPS. Install the office CA certificate first for local HTTPS.").setView(input).setCancelable(false).setPositiveButton("Connect",(d,w)->{String v=input.getText().toString().trim();if(!validAddress(v)){toast("Enter a trusted HTTPS server origin.");showSetup();return;}base=ServerAddress.normalize(v);getPreferences(0).edit().putString("server",base).apply();startWeb();}).show();}
 private void startWeb(){if(web!=null){web.removeJavascriptInterface("AndroidDownloads");web.removeJavascriptInterface("RoutePlanDevice");web.destroy();}web=new WebView(this);setContentView(web);if(Build.VERSION.SDK_INT>=30)web.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setGeolocationEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  if(base.startsWith("https://")){web.addJavascriptInterface(new Downloads(),"AndroidDownloads");web.addJavascriptInterface(new DeviceTools(),"RoutePlanDevice");}
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){if(chooser!=null)chooser.onReceiveValue(null);chooser=callback;try{startActivityForResult(params.createIntent(),PICK);return true;}catch(Exception e){chooser=null;return false;}}
   @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){if(!sameOrigin(origin)||!base.startsWith("https://")){callback.invoke(origin,false,false);return;}geoOrigin=origin;geoCallback=callback;if(hasLocation()){callback.invoke(origin,true,false);geoCallback=null;}else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION);}
  });
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){pageFailed=false;}
   @Override public void onPageFinished(WebView view,String url){if(!pageFailed&&sameOrigin(url)&&getActionBar()!=null)web.evaluateJavascript("Boolean(document.body && document.body.classList.contains(\"rp-business\"))",value->{if("true".equals(value))getActionBar().hide();else getActionBar().show();});}
   @Override public void onReceivedHttpError(WebView view,WebResourceRequest req,WebResourceResponse response){if(req.isForMainFrame()){pageFailed=true;if(getActionBar()!=null)getActionBar().show();}}

   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){String url=req.getUrl().toString();if(sameOrigin(url))return false;if(req.isForMainFrame()){try{Uri u=Uri.parse(url);if("https".equals(u.getScheme())||"http".equals(u.getScheme())||"geo".equals(u.getScheme()))startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){toast("No app available to open this link.");}}return true;}
   @Override public void onReceivedSslError(WebView view,android.webkit.SslErrorHandler handler,android.net.http.SslError error){pageFailed=true;if(getActionBar()!=null)getActionBar().show();handler.cancel();toast("Certificate not trusted. Install the office CA certificate; SSL checks are never bypassed.");}
   @Override public void onReceivedError(WebView view,WebResourceRequest req,WebResourceError err){if(req.isForMainFrame()){pageFailed=true;if(getActionBar()!=null)getActionBar().show();toast("Server unavailable. Offline delivery notes work after the HTTPS workspace has been opened once.");}}
  });
  web.setDownloadListener((url,ua,disp,mime,len)->{if(!sameOrigin(url)){toast("Use the browser to download external files.");return;}pendingText=null;pendingUrl=url;pendingCookie=CookieManager.getInstance().getCookie(base);chooseSave(URLUtil.guessFileName(url,disp,mime),mime==null?"application/octet-stream":mime);});web.loadUrl(base+"/");
 }
 private void chooseSave(String name,String mime){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^A-Za-z0-9._-]","_"));try{startActivityForResult(i,SAVE);}catch(Exception e){toast("No document provider available.");}}
 public class DeviceTools {
  @JavascriptInterface public void openMenu(){runOnUiThread(()->{if(web==null||!sameOrigin(web.getUrl()))return;String[] items={"Phone GPS","Connection diagnostics","Offline deliveries","Refresh","Change server address"};new AlertDialog.Builder(MainActivity.this).setTitle("Phone tools").setItems(items,(dialog,which)->{if(which==0)MainActivity.this.phoneGPS();else if(which==1)connectionDiagnostics();else if(which==2)web.loadUrl(base+"/offline.html");else if(which==3)web.reload();else showSetup();}).setNegativeButton("Close",null).show();});}
  @JavascriptInterface public void setTheme(boolean dark){runOnUiThread(()->{if(web==null||!sameOrigin(web.getUrl()))return;if(getActionBar()!=null)getActionBar().hide();int color=android.graphics.Color.parseColor(dark?"#111e31":"#ffffff");getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);View decor=getWindow().getDecorView();int flags=decor.getSystemUiVisibility();int light=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;decor.setSystemUiVisibility(dark?(flags&~light):(flags|light));});}
 }
 public class Downloads {
  @JavascriptInterface public void saveText(String name,String content){if(content==null||content.length()>8000000)return;runOnUiThread(()->{if(web==null||!sameOrigin(web.getUrl()))return;pendingText=content;pendingUrl=null;chooseSave(name,"text/plain");});}
 }
 private boolean hasLocation(){return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
 private void phoneGPS(){if(!hasLocation()){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION);return;}manager=(LocationManager)getSystemService(LOCATION_SERVICE);String provider=manager.isProviderEnabled(LocationManager.GPS_PROVIDER)?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;if(!manager.isProviderEnabled(provider)){toast("Enable phone location/GPS first.");return;}stopGPS();listener=new LocationListener(){@Override public void onLocationChanged(Location loc){lastGpsFixAt=System.currentTimeMillis();lastGpsAccuracy=loc.getAccuracy();stopGPS();try{JSONObject p=new JSONObject();p.put("latitude",loc.getLatitude());p.put("longitude",loc.getLongitude());p.put("accuracy",loc.getAccuracy());if(web!=null&&sameOrigin(web.getUrl()))web.evaluateJavascript("window.routeplanPhoneLocation && window.routeplanPhoneLocation("+p.toString()+");",null);}catch(Exception e){toast("Unable to read GPS.");}}@Override public void onStatusChanged(String p,int s,Bundle b){}@Override public void onProviderEnabled(String p){}@Override public void onProviderDisabled(String p){}};try{manager.requestLocationUpdates(provider,1000,0,listener);toast("Getting a fresh GPS position…");timer.postDelayed(()->{if(listener!=null){stopGPS();toast("GPS timed out. Move outside and retry.");}},30000);}catch(SecurityException e){toast("Location permission denied.");}}
 private void stopGPS(){if(manager!=null&&listener!=null)manager.removeUpdates(listener);listener=null;timer.removeCallbacksAndMessages(null);}
 @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results){super.onRequestPermissionsResult(req,permissions,results);if(req==LOCATION){if(geoCallback!=null){geoCallback.invoke(geoOrigin,hasLocation(),false);geoCallback=null;}else if(hasLocation())phoneGPS();else toast("Location permission denied. Mark the location manually on the map.");}}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==PICK&&chooser!=null){chooser.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);chooser=null;}if(req==SAVE&&result==RESULT_OK&&data!=null){Uri dest=data.getData();final String text=pendingText,url=pendingUrl,cookie=pendingCookie;pendingText=null;pendingUrl=null;new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(dest)){if(text!=null)out.write(text.getBytes(StandardCharsets.UTF_8));else if(url!=null){HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(60000);if(cookie!=null)c.setRequestProperty("Cookie",cookie);try{if(c.getResponseCode()!=200)throw new IOException("Download status "+c.getResponseCode());try(InputStream in=c.getInputStream()){byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}finally{c.disconnect();}}runOnUiThread(()->toast("File saved."));}catch(Exception e){runOnUiThread(()->toast("Download failed. Sign in and retry."));}},"routeplan-download").start();}}
 private void connectionDiagnostics(){
  final String origin=base;
  final boolean gpsAllowed=hasLocation(); final LocationManager location=(LocationManager)getSystemService(LOCATION_SERVICE); final boolean gpsEnabled=location.isProviderEnabled(LocationManager.GPS_PROVIDER); final long fixAt=lastGpsFixAt; final float fixAccuracy=lastGpsAccuracy;
  final android.net.NetworkCapabilities caps=connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());
  final String transport=caps==null?"Offline":caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)?"Wi-Fi":caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)?"Mobile data":caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)?"Ethernet":"Other/VPN";
  final android.content.pm.PackageInfo info=WebView.getCurrentWebViewPackage();
  new Thread(()->{String state;try{HttpURLConnection c=(HttpURLConnection)new URL(origin+"/api/status").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);try{int code=c.getResponseCode();state="Server HTTP status: "+code+(code==200?" (reachable)":" (check server)");}finally{c.disconnect();}}catch(Exception e){state="Server check failed: "+e.getClass().getSimpleName()+" — "+e.getMessage();}
   final String report="RoutePlan Business 2.2 device diagnostics\nAndroid API: "+Build.VERSION.SDK_INT+"\nDevice: "+Build.MANUFACTURER+" "+Build.MODEL+"\nWebView: "+(info==null?"Unknown":info.versionName)+"\nGPS permission: "+(gpsAllowed?"granted":"not granted")+"\nGPS enabled: "+gpsEnabled+"\nLast GPS fix: "+(fixAt>0?"obtained in this app session":"not obtained in this app session")+(fixAt>0?"\nGPS accuracy (reported metres): "+fixAccuracy+"\nGPS fix time (UTC milliseconds): "+fixAt:"")+"\nNetwork: "+transport+"\nServer: "+origin+"\nHTTPS configured: "+origin.startsWith("https://")+"\n"+state+"\nCheck time (UTC milliseconds): "+System.currentTimeMillis()+"\nThis does not certify GPS, offline sync or other network connections.";
   runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Connection diagnostics").setMessage(report).setPositiveButton("Close",null).setNeutralButton("Copy report",(d,w)->{android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboard.setPrimaryClip(ClipData.newPlainText("RoutePlan diagnostics",report));toast("Report copied. Nothing was sent automatically.");}).show());
  },"routeplan-diagnostics").start();
 }
 @Override public boolean onCreateOptionsMenu(Menu m){m.add("Connection diagnostics");m.add("Phone GPS");m.add("Offline deliveries");m.add("Refresh");m.add("Change server address");return true;}
 @Override public boolean onOptionsItemSelected(MenuItem i){String title=i.getTitle().toString();if(title.equals("Connection diagnostics"))connectionDiagnostics();else if(title.equals("Phone GPS"))phoneGPS();else if(title.equals("Offline deliveries"))web.loadUrl(base+"/offline.html");else if(title.equals("Change server address"))showSetup();else if(web!=null)web.reload();return true;}
 @Override protected void onResume(){super.onResume();if(web!=null&&sameOrigin(web.getUrl()))web.evaluateJavascript("window.dispatchEvent(new Event('online'));",null);}
 @Override protected void onPause(){android.webkit.CookieManager.getInstance().flush();super.onPause();}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(connectivity!=null&&networkCallback!=null)connectivity.unregisterNetworkCallback(networkCallback);stopGPS();if(chooser!=null)chooser.onReceiveValue(null);if(web!=null)web.destroy();super.onDestroy();}
}
