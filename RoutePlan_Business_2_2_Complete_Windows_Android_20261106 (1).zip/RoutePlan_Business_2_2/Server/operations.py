"""Delivery operations, per-account authorization and revision-aware offline writes."""
import hashlib, json, math, os, re, secrets, sqlite3, tempfile, time, uuid, base64
from datetime import datetime,timezone
from urllib.request import urlopen
from pathlib import Path
from urllib.parse import urlparse

ROLES=('Admin','Salesman','Driver')
STATES=('Pending','Delivered','Failed','Partial')

def install(app):
    original_init=app.init_db
    def init():
        original_init()
        with app.get_db() as db:
            columns={r['name'] for r in db.execute('PRAGMA table_info(users)')}
            for name,definition in [('role',"TEXT NOT NULL DEFAULT 'Admin'"),('salesman_no','INTEGER'),('active','INTEGER NOT NULL DEFAULT 1')]:
                if name not in columns: db.execute(f'ALTER TABLE users ADD COLUMN {name} {definition}')
            db.executescript('''
              CREATE TABLE IF NOT EXISTS deliveries (
                id TEXT PRIMARY KEY, date TEXT NOT NULL, shop_id TEXT NOT NULL,
                customer_name TEXT NOT NULL, address TEXT NOT NULL, salesman_no INTEGER,
                assigned_to TEXT NOT NULL, planned_qty REAL NOT NULL,
                delivered_qty REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Pending',
                notes TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 1,
                updated_at TEXT NOT NULL, updated_by TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS dispatch_route_plans (
                id TEXT PRIMARY KEY,date TEXT NOT NULL,driver TEXT NOT NULL,vehicle TEXT NOT NULL,
                created_by TEXT NOT NULL,payload TEXT NOT NULL,updated_at TEXT NOT NULL);
              CREATE INDEX IF NOT EXISTS delivery_driver_date ON deliveries(assigned_to,date);
              CREATE TABLE IF NOT EXISTS delivery_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, delivery_id TEXT NOT NULL,
                actor TEXT NOT NULL, operation_id TEXT NOT NULL,
                payload TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL,
                UNIQUE(actor,operation_id));
            ''')
            columns={r['name'] for r in db.execute('PRAGMA table_info(deliveries)')}
            for name in ('vehicle','load_unit','receiver_name','delivered_at','proof_photo','confirmed_at'):
                if name not in columns:db.execute(f"ALTER TABLE deliveries ADD COLUMN {name} TEXT NOT NULL DEFAULT ''")
    app.init_db=init
    H=app.Handler
    old_current=H.current_user
    def current(self):
        name=old_current(self)
        if not name:return None
        with app.get_db() as db:
            row=db.execute('SELECT active FROM users WHERE username=? COLLATE NOCASE',(name,)).fetchone()
        return name if row and row['active'] else None
    H.current_user=current
    def account(self):
        name=self.current_user()
        if not name:return None
        with app.get_db() as db:
            row=db.execute('SELECT username,role,salesman_no,active FROM users WHERE username=? COLLATE NOCASE',(name,)).fetchone()
        return dict(row) if row else None
    H.account=account
    def visible(row,a):
        return a['role']=='Admin' or (a['role']=='Salesman' and row['salesman_no']==a['salesman_no']) or (a['role']=='Driver' and row['assigned_to'].casefold()==a['username'].casefold())
    def scoped_data(data,a):
        if a['role']=='Admin':return data
        no=a['salesman_no']
        with app.get_db() as db:
            if a['role']=='Salesman': ids={r['shop_id'] for r in db.execute('SELECT shop_id FROM customer_links WHERE salesman_no=?',(no,))}
            else: ids={r['shop_id'] for r in db.execute('SELECT shop_id FROM deliveries WHERE assigned_to=? COLLATE NOCASE',(a['username'],))}
        data['shops']=[x for x in data['shops'] if x['id'] in ids]
        data['salesmen']=[x for x in data['salesmen'] if a['role']=='Salesman' and x['no']==no]
        data['salesEntries']=[x for x in data['salesEntries'] if a['role']=='Salesman' and x['salesman_no']==no]
        allowed_names={x['name'] for x in data['salesmen']}
        data['plans']=[x for x in data['plans'] if x['person'] in allowed_names] if a['role']=='Salesman' else []
        allowed_areas={x['area'] for x in data['shops']}|{x['area'] for x in data['salesmen']}
        data['areas']=[x for x in data['areas'] if x in allowed_areas]
        data['dispatch']={};data['routeAmounts']={};data.pop('autoPlanning',None)
        return data
    old_json=H.json
    def json_response(self,status,payload,headers=None):
        a=getattr(self,'_account',None);path=urlparse(self.path).path
        if status==200 and path=='/api/status':payload={**payload,'appVersion':'2.2-business','deliverySync':True,'rolePermissions':True,'setupProtected':bool(os.environ.get('ROUTEPLAN_SETUP_TOKEN'))}
        if status==200 and a:
            if path=='/api/data': payload=scoped_data(payload,a)
            if path=='/api/customer-links' and a['role']!='Admin':
                with app.get_db() as db:
                    ids={r['shop_id'] for r in db.execute('SELECT shop_id FROM deliveries WHERE assigned_to=? COLLATE NOCASE',(a['username'],))} if a['role']=='Driver' else {r['shop_id'] for r in db.execute('SELECT shop_id FROM customer_links WHERE salesman_no=?',(a['salesman_no'],))}
                payload={'links':[x for x in payload['links'] if x['shop_id'] in ids]}
        if status==200 and path=='/api/password' and a:
            keep=self.cookie_token()
            for key,session in list(app.SESSIONS.items()):
                if key!=keep and session['user'].casefold()==a['username'].casefold():app.SESSIONS.pop(key,None)
        return old_json(self,status,payload,headers)
    H.json=json_response
    def deny(self,message='Your account does not have permission for this action.'):
        self.json(403,{'error':message})
    def number(value,label,positive=False):
        if isinstance(value,bool):raise ValueError(label+' must be a number.')
        try:n=float(value)
        except (TypeError,ValueError):raise ValueError(label+' must be a number.')
        if not math.isfinite(n) or n<0 or n>1e9 or (positive and n==0):raise ValueError('Invalid '+label+'.')
        return n
    def operation_id(data):
        op=data.get('operationId','')
        if not isinstance(op,str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,100}',op):raise ValueError('A valid operation ID is required.')
        return op
    def delivery_write(self,data,a,create=False):
        op=operation_id(data);stamp=app.utcnow();actor=a['username']
        payload=json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False)
        with app.get_db() as db:
            db.execute('BEGIN IMMEDIATE')
            prior=db.execute('SELECT payload,result FROM delivery_events WHERE actor=? COLLATE NOCASE AND operation_id=?',(actor,op)).fetchone()
            if prior:
                if prior['payload']!=payload:raise ValueError('Operation ID was already used for different data.')
                old=json.loads(prior['result'])
                live=db.execute('SELECT * FROM deliveries WHERE id=?',(old['id'],)).fetchone()
                if not live or not visible(live,a):return deny(self)
                self.json(200,{'ok':True,'delivery':old,'replayed':True});return
            if create:
                if a['role']=='Driver':return deny(self)
                shop=db.execute('SELECT s.*,l.salesman_no FROM shops s JOIN customer_links l ON l.shop_id=s.id WHERE s.id=?',(data.get('shopId'),)).fetchone()
                if not shop or shop['salesman_no'] is None:raise ValueError('Choose a customer assigned to a salesman.')
                if a['role']=='Salesman' and shop['salesman_no']!=a['salesman_no']:return deny(self)
                driver=db.execute("SELECT username FROM users WHERE username=? COLLATE NOCASE AND role='Driver' AND active=1",(data.get('assignedTo'),)).fetchone()
                if not driver:raise ValueError('Choose an active driver.')
                date=data.get('date');qty=number(data.get('plannedQty'),'planned quantity',True)
                if not app.is_date(date):raise ValueError('Choose a delivery date.')
                row={'id':str(uuid.uuid4()),'date':date,'shop_id':shop['id'],'customer_name':shop['name'],'address':shop['address'],'salesman_no':shop['salesman_no'],'assigned_to':driver['username'],'planned_qty':qty,'delivered_qty':0,'status':'Pending','notes':app.clean_text(data.get('notes'),2000),'revision':1,'updated_at':stamp,'updated_by':actor}
                row.update(vehicle=app.clean_text(data.get('vehicle'),80),load_unit=app.clean_text(data.get('loadUnit') or 'units',30),receiver_name='',delivered_at='',proof_photo='',confirmed_at='')
                db.execute('INSERT INTO deliveries ('+','.join(row)+') VALUES ('+','.join('?' for _ in row)+')',tuple(row.values()))
            else:
                live=db.execute('SELECT * FROM deliveries WHERE id=?',(data.get('id'),)).fetchone()
                if not live: self.json(404,{'error':'Delivery not found.'});return
                if not visible(live,a):return deny(self)
                revision=data.get('expectedRevision')
                if isinstance(revision,bool) or not isinstance(revision,int):raise ValueError('Expected revision is required.')
                if revision!=live['revision']:
                    self.json(409,{'error':'This delivery changed on another device. Review the server record before reapplying.','current':dict(live)});return
                status=data.get('status');qty=number(data.get('deliveredQty'),'delivered quantity')
                notes=app.clean_text(data.get('notes'),2000)
                if status not in STATES:raise ValueError('Choose Pending, Delivered, Failed or Partial.')
                planned=live['planned_qty']
                if qty>planned:raise ValueError('Delivered quantity exceeds planned quantity.')
                if status in ('Pending','Failed') and qty!=0:raise ValueError('Pending/Failed requires delivered quantity 0.')
                if status=='Delivered' and qty!=planned:raise ValueError('Delivered requires the full planned quantity.')
                if status=='Partial' and not 0<qty<planned:raise ValueError('Partial requires a quantity between 0 and planned quantity.')
                if status in ('Failed','Partial') and not notes:raise ValueError('Enter a reason for a failed or partial delivery.')
                receiver=app.clean_text(data.get('receiverName',live['receiver_name'] if status in ('Delivered','Partial') else ''),120)
                delivered_at=data.get('deliveredAt',live['delivered_at'] if status in ('Delivered','Partial') else '') or ''
                if not isinstance(delivered_at,str):raise ValueError('Invalid delivery time.')
                if delivered_at:
                    try:
                        parsed=datetime.fromisoformat(delivered_at.replace('Z','+00:00'))
                        if parsed.tzinfo is None:raise ValueError()
                        delivered_at=parsed.astimezone(timezone.utc).isoformat()
                    except ValueError:raise ValueError('Delivery time must include a timezone.')
                photo=data.get('proofPhoto',live['proof_photo'] if status in ('Delivered','Partial') else '') or ''
                if not isinstance(photo,str) or len(photo)>250000:raise ValueError('Photo exceeds the 180 KB image limit.')
                if photo:
                    try:
                        prefix,encoded=photo.split(',',1);raw=base64.b64decode(encoded,validate=True)
                        if len(raw)>180000 or not ((prefix=='data:image/jpeg;base64' and raw.startswith(b'\xff\xd8\xff')) or (prefix=='data:image/png;base64' and raw.startswith(b'\x89PNG\r\n\x1a\n'))):raise ValueError()
                    except ValueError:raise ValueError('Use a JPEG or PNG photo under 180 KB.')
                if status in ('Pending','Failed') and (receiver or delivered_at or photo):
                    raise ValueError('Delivery proof is only available for Delivered or Partial status. Clear proof fields first.')
                if status in ('Delivered','Partial') and not delivered_at:delivered_at=stamp
                row=dict(live);row.update(status=status,delivered_qty=qty,notes=notes,revision=revision+1,updated_at=stamp,updated_by=actor,receiver_name=receiver,delivered_at=delivered_at,proof_photo=photo,confirmed_at=stamp if status in ('Delivered','Partial') else '')
                db.execute('UPDATE deliveries SET '+','.join(k+'=?' for k in row if k!='id')+' WHERE id=?',tuple(row[k] for k in row if k!='id')+(row['id'],))
            result=json.dumps(row)
            db.execute('INSERT INTO delivery_events(delivery_id,actor,operation_id,payload,result,created_at) VALUES (?,?,?,?,?,?)',(row['id'],actor,op,payload,result,stamp))
        self.audit('delivery_created' if create else 'delivery_updated',actor,row['id']+' '+row['status'])
        self.json(201 if create else 200,{'ok':True,'delivery':row})
    def users_write(self,data,a):
        if a['role']!='Admin':return deny(self)
        username=app.clean_text(data.get('username'),40);role=data.get('role');active=data.get('active',True);no=data.get('salesmanNo')
        if not re.fullmatch(r'[A-Za-z0-9._-]{3,40}',username) or role not in ROLES or not isinstance(active,bool):raise ValueError('Enter a valid username, role and active status.')
        password=data.get('password','')
        if not isinstance(password,str) or (password and not 10<=len(password)<=1024):raise ValueError('Password must contain at least 10 characters.')
        with app.get_db() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM users WHERE username=? COLLATE NOCASE',(username,)).fetchone()
            if role=='Salesman':
                if isinstance(no,bool) or not isinstance(no,int) or not db.execute('SELECT 1 FROM salesmen WHERE no=?',(no,)).fetchone():raise ValueError('Link the account to a valid salesman.')
            else:no=None
            if old and old['role']=='Admin' and old['active'] and (not active or role!='Admin'):
                if db.execute("SELECT COUNT(*) FROM users WHERE role='Admin' AND active=1").fetchone()[0]<=1:raise ValueError('At least one active administrator is required.')
            if not old and not password:raise ValueError('Enter the initial password.')
            if old:
                db.execute('UPDATE users SET role=?,salesman_no=?,active=? WHERE username=? COLLATE NOCASE',(role,no,int(active),username))
                if password:
                    salt,digest=app.password_hash(password);db.execute('UPDATE users SET salt=?,password_hash=? WHERE username=? COLLATE NOCASE',(salt,digest,username))
            else:
                salt,digest=app.password_hash(password);db.execute('INSERT INTO users(username,salt,password_hash,created_at,role,salesman_no,active) VALUES (?,?,?,?,?,?,?)',(username,salt,digest,app.utcnow(),role,no,int(active)))
        for key,session in list(app.SESSIONS.items()):
            if session['user'].casefold()==username.casefold():app.SESSIONS.pop(key,None)
        self.audit('account_updated',a['username'],username+' '+role)
        self.json(200,{'ok':True})
    def full_backup(self,a):
        if a['role']!='Admin':return deny(self)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'routeplan.sqlite3'
            with app.get_db() as src,sqlite3.connect(path) as dst:
                src.backup(dst)
                if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Backup integrity failed.')
            self.send_bytes(200,path.read_bytes(),'application/vnd.sqlite3',{'Content-Disposition':'attachment; filename="routeplan-full-backup.sqlite3"'})
    def handle(self,verb,original):
        path=urlparse(self.path).path
        if not path.startswith('/api/'):return original(self)
        if verb!='GET' and self.headers.get('Origin'):
            origin=urlparse(self.headers['Origin'])
            if origin.netloc.casefold()!=self.headers.get('Host','').casefold():
                self.json(403,{'error':'Cross-origin changes are not allowed.'});return
        if path in ('/api/routing-artifact','/api/routing-artifact-status'):
            from routing_artifact import handle as artifact_handle
            return artifact_handle(self,verb,app,path)
        # Public login/status endpoints do not expose business records.
        if verb=='POST' and path=='/api/setup' and os.environ.get('ROUTEPLAN_DISABLE_WEB_SETUP')=='1':
            self.json(403,{'error':'Create the first admin from the server terminal with create_admin_local.py.'});return
        if verb=='POST' and path=='/api/setup' and os.environ.get('ROUTEPLAN_SETUP_TOKEN'):
            import hmac
            try: setup=self.read_json()
            except ValueError as exc:
                self.json(400,{'error':str(exc)});return
            supplied=setup.get('setupToken','')
            if not isinstance(supplied,str) or not hmac.compare_digest(supplied.encode('utf-8'),os.environ['ROUTEPLAN_SETUP_TOKEN'].encode('utf-8')):
                self.json(403,{'error':'Use the private activation link to create the first administrator.'});return
            read=self.read_json;self.read_json=lambda:setup
            try:return original(self)
            finally:self.read_json=read
        if (verb=='GET' and path=='/api/status') or (verb=='POST' and path in ('/api/setup','/api/login','/api/logout')):return original(self)
        a=self.account();self._account=a
        if not a:self.json(401,{'error':'Sign in to continue.'});return
        if verb=='GET' and path=='/api/me':self.json(200,{'authenticated':True,**a});return
        try:
            if verb=='GET':
                if path=='/api/deliveries':
                    with app.get_db() as db:rows=[dict(r) for r in db.execute('SELECT d.*,s.latitude,s.longitude FROM deliveries d LEFT JOIN shops s ON s.id=d.shop_id ORDER BY d.date DESC,d.customer_name') if visible(r,a)]
                    self.json(200,{'deliveries':rows,'serverTime':app.utcnow()});return
                if path=='/api/drivers':
                    if a['role']=='Driver':return deny(self)
                    with app.get_db() as db:rows=[r['username'] for r in db.execute("SELECT username FROM users WHERE role='Driver' AND active=1 ORDER BY username")]
                    self.json(200,{'drivers':rows});return
                if path=='/api/users':
                    if a['role']!='Admin':return deny(self)
                    with app.get_db() as db:rows=[dict(r) for r in db.execute('SELECT username,role,salesman_no,active,created_at FROM users ORDER BY username')]
                    self.json(200,{'users':rows});return
                if path=='/api/delivery-route-plans':
                    with app.get_db() as db:
                        result=[json.loads(r['payload']) for r in db.execute('SELECT * FROM dispatch_route_plans ORDER BY updated_at DESC LIMIT 100') if a['role']=='Admin' or (a['role']=='Driver' and r['driver'].casefold()==a['username'].casefold()) or (a['role']=='Salesman' and r['created_by'].casefold()==a['username'].casefold())]
                    self.json(200,{'plans':result});return
                if path=='/api/customer-audit':
                    if a['role']!='Admin':return deny(self)
                    from customer_audit import audit
                    with app.get_db() as db:result=audit(db)
                    self.json(200,result);return
                if path=='/api/operations-status':
                    from backup_service import status as backup_status
                    configured=bool(os.environ.get('ROUTEPLAN_OSRM_URL'));now=time.time()
                    cached=getattr(app,'_routing_probe',None)
                    if not cached or now-cached['checked']>30:
                        reachable=False
                        if configured:
                            try:
                                u=os.environ['ROUTEPLAN_OSRM_URL'].rstrip('/')+'/route/v1/driving/79.8428,6.9344;79.8612,6.9271?overview=false'
                                with urlopen(u,timeout=3) as response:reachable=json.loads(response.read(100000)).get('code')=='Ok'
                            except Exception:pass
                        cached={'checked':now,'reachable':reachable};app._routing_probe=cached
                    backup=backup_status(app.DATA_DIR);files=list(Path(os.environ.get('ROUTEPLAN_BACKUP_DIR',str(app.DATA_DIR/'backups'))).glob('routeplan-full-*.sqlite3'))
                    latest=max((x.stat().st_mtime for x in files),default=None)
                    self.json(200,{'routingConfigured':configured,'routingReachable':cached['reachable'],'routingCheckedAt':datetime.fromtimestamp(cached['checked'],timezone.utc).isoformat(),'backupState':backup.get('state','unknown'),'lastBackupAt':datetime.fromtimestamp(latest,timezone.utc).isoformat() if latest else None,'serverTime':app.utcnow()});return
                if path=='/api/system':
                    if a['role']!='Admin':return deny(self)
                    from backup_service import status as backup_status
                    self.json(200,{'routingConfigured':bool(os.environ.get('ROUTEPLAN_OSRM_URL')),'secureCookies':os.environ.get('ROUTEPLAN_SECURE_COOKIES')=='1','backups':backup_status(app.DATA_DIR)});return
                if path=='/api/full-backup':return full_backup(self,a)
                if path=='/api/excel-plan' and a['role']!='Admin':self.json(200,{'entries':[],'priorities':[],'count':0});return
                if a['role']!='Admin' and path not in ('/api/data','/api/customer-links'):return deny(self)
                return original(self)
            if verb=='POST':
                data=self.read_json()
                if path=='/api/delivery-route-plan':
                    if a['role']=='Driver':return deny(self)
                    from delivery_planner import plan
                    date=data.get('date');driver=data.get('driver');vehicle=app.clean_text(data.get('vehicle'),80);unit=app.clean_text(data.get('loadUnit'),30)
                    if not app.is_date(date) or not driver or not vehicle or not unit:raise ValueError('Enter date, driver, vehicle and load unit.')
                    with app.get_db() as db:
                        selected=[dict(r) for r in db.execute("SELECT d.*,s.latitude,s.longitude,l.verified_lat,l.verified_lon,l.verified_at FROM deliveries d JOIN shops s ON s.id=d.shop_id LEFT JOIN customer_links l ON l.shop_id=s.id WHERE d.date=? AND d.assigned_to=? COLLATE NOCASE AND d.vehicle=? AND d.status IN ('Pending','Partial')",(date,driver,vehicle)) if visible(r,a)]
                    if any(r['load_unit'].casefold()!=unit.casefold() for r in selected):raise ValueError('Selected deliveries use different load units. Separate them before planning.')
                    if any(r['latitude'] is None or r['longitude'] is None or not r['verified_at'] or r['latitude']!=r['verified_lat'] or r['longitude']!=r['verified_lon'] for r in selected):raise ValueError('Confirm GPS for every selected customer before road planning.')
                    for r in selected:r['remaining_qty']=r['planned_qty']-r['delivered_qty'];r.pop('proof_photo',None)
                    result=plan(selected,data);result.update(date=date,driver=driver,vehicle=vehicle,loadUnit=unit,createdAt=app.utcnow())
                    result['id']=hashlib.sha256((date+'|'+driver.casefold()+'|'+vehicle).encode()).hexdigest()[:32]
                    if result['stops']:
                        with app.get_db() as db:db.execute('INSERT INTO dispatch_route_plans VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET created_by=excluded.created_by,payload=excluded.payload,updated_at=excluded.updated_at',(result['id'],date,driver,vehicle,a['username'],json.dumps(result),app.utcnow()))
                    self.json(200,result);return
                if path=='/api/backup-verify':
                    if a['role']!='Admin':return deny(self)
                    from backup_service import create_backup
                    from restore_full_backup import compare_restored
                    saved=create_backup(app.DB_PATH,app.DATA_DIR);source=Path(os.environ.get('ROUTEPLAN_BACKUP_DIR',str(app.DATA_DIR/'backups')))/saved['file']
                    self.json(200,compare_restored(source));return
                if path=='/api/users':return users_write(self,data,a)
                if path=='/api/deliveries':return delivery_write(self,data,a,True)
                if path=='/api/delivery-update':return delivery_write(self,data,a)
                if path=='/api/backup-now':
                    if a['role']!='Admin':return deny(self)
                    from backup_service import create_backup
                    result=create_backup(app.DB_PATH,app.DATA_DIR)
                    self.json(200,{'ok':True,'backup':result});return
                if a['role']!='Admin':
                    if path=='/api/sales' and a['role']=='Salesman':
                        if data.get('salesmanNo')!=a['salesman_no']:return deny(self)
                    elif path in ('/api/map-customer','/api/customer-link','/api/road-route') and a['role']=='Salesman':
                        if data.get('salesmanNo')!=a['salesman_no']:return deny(self)
                        sid=data.get('id') if path=='/api/map-customer' else data.get('shopId')
                        if sid:
                            with app.get_db() as db:
                                link=db.execute('SELECT salesman_no FROM customer_links WHERE shop_id=?',(sid,)).fetchone()
                            if not link or link['salesman_no']!=a['salesman_no']:return deny(self)
                    elif path!='/api/password':return deny(self)
                if path=='/api/restore':
                    with app.get_db() as db:
                        if db.execute('SELECT COUNT(*) FROM deliveries').fetchone()[0]:
                            self.json(409,{'error':'Use the full SQLite restore tool once deliveries exist. JSON restore does not contain accounts/delivery history.'});return
                read=self.read_json;self.read_json=lambda:data
                try:return original(self)
                finally:self.read_json=read
            if a['role']!='Admin':return deny(self)
            return original(self)
        except (ValueError,TypeError) as exc:self.json(400,{'error':str(exc)})
        except sqlite3.IntegrityError:self.json(409,{'error':'Record conflicts with saved data. Refresh and retry.'})
        except Exception as exc:
            print('[RoutePlan] Operations error:',repr(exc));self.json(500,{'error':'Operation failed. Retry with the same operation ID.'})
    for verb in ('GET','POST','PUT','DELETE'):
        old=getattr(H,'do_'+verb)
        def wrapper(self,_verb=verb,_old=old):return handle(self,_verb,_old)
        setattr(H,'do_'+verb,wrapper)
