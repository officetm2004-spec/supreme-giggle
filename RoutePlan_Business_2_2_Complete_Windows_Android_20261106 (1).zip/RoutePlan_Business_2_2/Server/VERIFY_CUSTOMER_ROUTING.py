"""Isolated API and OSRM-contract tests; no customer coordinates leave this machine."""
import os,tempfile,threading,json,urllib.request,urllib.error,unittest
from unittest.mock import patch
with tempfile.TemporaryDirectory() as tmp:
 os.environ['ROUTEPLAN_DATA_DIR']=tmp
 import server,road_routes
 server.init_db();server.init_db()
 with server.get_db() as db:
  salt,digest=server.password_hash('isolated-tests-only')
  db.execute('INSERT INTO users(username,salt,password_hash,created_at) VALUES (?,?,?,?)',('reviewer',salt,digest,server.utcnow()))
 server.SESSIONS['test']={'user':'reviewer','expires':9999999999}
 http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
 threading.Thread(target=http.serve_forever,daemon=True).start()
 def request(path,payload=None):
  req=urllib.request.Request(f'http://127.0.0.1:{http.server_port}/api/'+path,data=json.dumps(payload).encode() if payload is not None else None,headers={'Cookie':'routeplan_session=test','Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req) as res:return res.status,json.load(res)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 try:
  _,data=request('data');no=data['salesmen'][0]['no'];area=data['areas'][0]
  shop={'name':'Test customer','area':area,'address':'Test address','latitude':6.9,'longitude':79.9}
  status,out=request('shops',shop);assert status==201,out
  sid=out['shop']['id']
  assert request('customer-link',{'shopId':sid,'salesmanNo':999999})[0]==400
  assert request('customer-link',{'shopId':sid,'salesmanNo':no,'verify':True})[0]==200
  body={'salesmanNo':no,'shopIds':[sid],'depot':{'latitude':6.8,'longitude':79.8}}
  with patch.dict(os.environ,{'ROUTEPLAN_OSRM_URL':''}):assert request('road-route',body)[0]==503
  with patch('road_routes.query',side_effect=[{'durations':[[0,600],[600,0]]},{'routes':[{'distance':15000,'duration':600,'geometry':{'type':'LineString','coordinates':[[79.8,6.8],[79.9,6.9]]},'legs':[{'distance':15000,'duration':600}]}]}]):
   status,out=request('road-route',body);assert status==200 and out['distanceKm']==15 and out['minutes']==10 and out['geometry']['type']=='LineString',out
  body['salesmanNo']=999999;assert request('road-route',body)[0]==400
  _,backup=request('backup');assert backup['customerLinks'][0]['shop_id']==sid
  assert request('restore',backup)[0]==200
  _,links=request('customer-links');assert links['links'][0]['salesman_no']==no and not links['links'][0]['verified_at']
  assert request('shops',{**shop,'latitude':float('nan')})[0]==400
  with patch('road_routes.query',return_value={'durations':[[0,None],[None,0]]}):
   try:road_routes.road_route([shop],{'latitude':6.8,'longitude':79.8})
   except RuntimeError:pass
   else:raise AssertionError('Unreachable customer accepted')
  # Directed matrix must determine order, rather than geographical proximity.
  stops=[{**shop,'id':'a'},{**shop,'id':'b'}]
  matrix={'durations':[[0,100,10],[100,0,10],[10,10,0]]}
  route={'routes':[{'distance':2000,'duration':20,'legs':[{'distance':1000,'duration':10}]*2}]}
  with patch('road_routes.query',side_effect=[matrix,route]):
   result=road_routes.road_route(stops,{'latitude':6.8,'longitude':79.8});assert result['stops'][0]['id']=='b'
  mark={**shop,'name':'Map-created customer','salesmanNo':no,'confirmLocation':True}
  assert request('map-customer',{**mark,'confirmLocation':False})[0]==400
  assert request('map-customer',{**mark,'salesmanNo':999999})[0]==400
  status,created=request('map-customer',mark);assert status==201,created
  mapped=created['shop'];mid=mapped['id']
  _,savedlinks=request('customer-links');assert any(x['shop_id']==mid and x['salesman_no']==no and x['verified_at'] for x in savedlinks['links'])
  edit={**mark,'id':mid,'expectedUpdatedAt':mapped['updated_at'],'latitude':7.0}
  status,updated=request('map-customer',edit);assert status==200,updated
  assert request('map-customer',edit)[0]==400 # stale concurrent update rejected
  _,current=request('data');assert next(x for x in current['shops'] if x['id']==mid)['latitude']==7.0
  print('PASS: assignment, manual GPS confirmation, missing provider, road units/order, unreachable roads, invalid GPS, backup/restore')
 finally:http.shutdown();http.server_close()
