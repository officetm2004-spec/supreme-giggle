# AMITH E අනුව ස්වයංක්‍රීය සැලසුම්

මුල් AMITH E (1).xlsx ගොනුවේ DATA BASE, DASHBOARD සහ conditional formatting වර්ණ සටහන පරීක්ෂා කර ඇත.

- DATA BASE AL: අවසන් dispatch දිනයට වඩා පසු sales dates පමණක් current value එකට ගනී. Dispatch දින sales ඇතුළත් නොවේ.
- DASHBOARD H2:H13: HIGH >=900000; MEDIUM >=500000; SMALL >=300000; LOW >=100000; ඊට අඩු අගයට rank නැත.
- වර්ණ සටහන: නිල් <1000000; කොළ 1000000–<1500000; කහ 1500000–<2000000; තැඹිලි 2000000–3000000; රතු >3000000.
- සටහනේ සීමා එකිනෙක හමුවන 1.5m/2m අගයන් ඊළඟ වර්ණයට යොදා ඇත; 3m සඳහා සටහනේ “ට වැඩි” අනුව රතු >3m වේ.
- වර්ණ සටහන සහ DASHBOARD planning rank වෙන වෙනම පෙන්වයි. Workbook ROUTE F හි legacy High/Medium සීමා DASHBOARD rank වෙනුවට භාවිත කර නැත.

Sales/dispatch update සහ sync විට automatic Delivery plans නැවත ගණනය වේ. එකම area/dispatch cycle එකට stable ID එකක් ඇති නිසා duplicates නොසෑදේ. Untouched pending automatic plans පමණක් නැවත ගණනය වේ. Manual edits, in-progress සහ completed records රැකේ. Dispatch පසු පැරණි pending automatic cycle cancelled වේ. Customers salesman IDs හරහා ගණන් කරයි.

හිස් installation එකක මුල් Excel හි සැබෑ daily sales records 150 එක් වරක් ඇතුළත් කරයි; දැනට live sales/plans තිබේ නම් ඒවා වෙනුවට baseline එක දමන්නේ නැත. මෙය 2026 February historical source එකකි; වත්මන් sales ලෙස අනුමාන කර නැත. අලුත් sales ඇතුළත් කළ පසු ඒවාද ගණනයට එකතු වේ. Original workbook වෙනස් කර නැත.

Route cards: මුදල, පාට/නම, planning rank, ඊළඟ වර්ණ සීමාව, අවශ්‍ය මුදල සහ assigned customer count. Responsive layout සහ accessible progress labels ඇත.

මෙය eligibility/priority planning එකයි. සැබෑ මාර්ග stop sequence සඳහා verified GPS සහ ක්‍රියාත්මක OSRM අවශ්‍ය වේ. Hosted Sri Lanka OSRM memory limitation තවම විසඳී නැත. සැබෑ Windows/Android device acceptance පරීක්ෂණ ඉතිරියි.
