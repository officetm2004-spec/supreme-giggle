@echo off
start "" "https://routeplan-web-production.up.railway.app"
exit /b
