@echo off
setlocal
cd /d "%~dp0"
echo RoutePlan - actual Windows PC and server connection check
where py >nul 2>nul
if %errorlevel%==0 (py -3 CHECK_DEVICE_CONNECTION.py) else (python CHECK_DEVICE_CONNECTION.py)
pause
endlocal
