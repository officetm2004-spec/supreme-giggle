"""Run on the actual Windows PC to record runtime and server reachability evidence."""
import argparse,json,platform,socket,ssl,sys,time,urllib.request,urllib.error
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlparse
p=argparse.ArgumentParser();p.add_argument('--url');p.add_argument('--output',default='WINDOWS_NETWORK_REPORT.json');args=p.parse_args()
base=(args.url or input('RoutePlan server URL [http://localhost:8082]: ').strip() or 'http://localhost:8082').strip().rstrip('/')
u=urlparse(base)
if u.scheme not in ('http','https') or not u.hostname or u.username or u.password or u.query or u.fragment or u.path:
 raise SystemExit('Use the server origin only, for example https://route.your-domain.com')
report={'checkedAt':datetime.now(timezone.utc).isoformat(),'platform':platform.platform(),'python':platform.python_version(),'windowsDevice':platform.system()=='Windows','server':base,'checks':[],'scope':'Device runtime, DNS, TLS and unauthenticated server reachability only. Not a full workflow/GPS/cellular certification.'}
def record(name,status,detail):report['checks'].append({'name':name,'status':status,'detail':detail});print(name+': '+status+' — '+str(detail))
record('Windows runtime','PASS' if report['windowsDevice'] else 'NOT_WINDOWS',report['platform'])
try:
 addresses=sorted({x[4][0] for x in socket.getaddrinfo(u.hostname,u.port or (443 if u.scheme=='https' else 80),type=socket.SOCK_STREAM)})
 record('DNS','PASS',addresses)
except OSError as e:record('DNS','FAIL',str(e))
ctx=ssl.create_default_context()
for path,expected in [('/api/status',200),('/',200),('/api/data',401)]:
 start=time.monotonic()
 try:
  req=urllib.request.Request(base+path,headers={'User-Agent':'RoutePlan-Device-Check/2.2'})
  try:
   with urllib.request.urlopen(req,context=ctx,timeout=15) as r:code=r.status;body=r.read(2_000_000);content=r.headers.get('Content-Type','')
  except urllib.error.HTTPError as e:code=e.code;body=e.read();content=e.headers.get('Content-Type','')
  if path=='/api/status' and code==200:
   data=json.loads(body);ok='initialized' in data and 'salesmen' in data
   record('RoutePlan status',('PASS' if data.get('appVersion')=='2.2-business' else 'OLDER_BUILD') if ok else 'FAIL',{'http':code,'appVersion':data.get('appVersion','older build'),'elapsedMs':round((time.monotonic()-start)*1000)})
  else:record(path,'PASS' if code==expected else 'FAIL',{'http':code,'expected':expected,'elapsedMs':round((time.monotonic()-start)*1000)})
 except Exception as e:record(path,'FAIL',type(e).__name__+': '+str(e))
record('HTTPS','PASS' if u.scheme=='https' and not any(x['status']=='FAIL' for x in report['checks']) else 'NOT_VERIFIED','System certificate checks remain enabled. HTTP local test mode does not verify HTTPS.')
report['allRecordedChecksPassed']=report['windowsDevice'] and all(x['status']=='PASS' for x in report['checks'])
Path(args.output).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print('Report saved:',Path(args.output).resolve())
print('Overall recorded check status:', 'PASS' if report['allRecordedChecksPassed'] else 'INCOMPLETE_OR_FAILED')
print('App workflows, GPS, real Wi-Fi/mobile-data switching and offline restart must be checked separately.')
if any(x['status']=='FAIL' for x in report['checks']):sys.exit(2)
