@echo off
setlocal
cd /d "%~dp0"
set /p "backupfile=Full SQLite backup file path: "
set /p "datadir=Data folder path (e.g. data_release_candidate_test): "
echo Validating backup and rehearsing restore into a temporary database...
python restore_full_backup.py "%backupfile%" --data-dir "%datadir%"
if errorlevel 1 goto end
choice /m "Stop RoutePlan first. Restore this full backup now"
if errorlevel 2 goto end
python restore_full_backup.py "%backupfile%" --data-dir "%datadir%" --restore
:end
pause
endlocal
