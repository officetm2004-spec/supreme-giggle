"""Real loopback TLS/HTTP tests, synthetic records. Not a Wi-Fi/cellular test."""
import os,tempfile,subprocess,shutil,ssl,threading,json,urllib.request,urllib.error,http.cookiejar,http.client,socket,uuid
from pathlib import Path
if not shutil.which('openssl'):raise SystemExit('SKIP: OpenSSL is required for isolated TLS certificate generation.')
with tempfile.TemporaryDirectory(prefix='routeplan_tls_') as tmp:
 root=Path(tmp);cert=root/'cert.pem';key=root/'key.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1','-keyout',str(key),'-out',str(cert)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 os.environ['ROUTEPLAN_DATA_DIR']=tmp;os.environ['ROUTEPLAN_SECURE_COOKIES']='1';os.environ.pop('ROUTEPLAN_DISABLE_WEB_SETUP',None)
 import server
 server.init_db()
 listener=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_2;ctx.load_cert_chain(cert,key)
 listener.socket=ctx.wrap_socket(listener.socket,server_side=True)
 threading.Thread(target=listener.serve_forever,daemon=True).start()
 base=f'https://localhost:{listener.server_port}';trust=ssl.create_default_context(cafile=str(cert))
 jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar),urllib.request.HTTPSHandler(context=trust))
 def request(path,data=None,headers=None):
  req=urllib.request.Request(base+'/api/'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json',**(headers or {})})
  try:
   with opener.open(req,timeout=5) as r:return r.status,json.load(r),r.headers
  except urllib.error.HTTPError as e:return e.code,json.load(e),e.headers
 def op():return uuid.uuid4().hex
 checks=[]
 try:
  try:urllib.request.urlopen(base+'/api/status',timeout=5)
  except urllib.error.URLError as e:assert isinstance(e.reason,ssl.SSLCertVerificationError)
  else:raise AssertionError('Untrusted TLS certificate accepted')
  checks.append('untrusted TLS certificate rejected')
  try:
   with socket.create_connection(('127.0.0.1',listener.server_port),timeout=5) as conn:
    with trust.wrap_socket(conn,server_hostname='wrong-routeplan.test'):pass
  except ssl.SSLCertVerificationError:pass
  else:raise AssertionError('TLS hostname mismatch accepted')
  checks.append('TLS hostname mismatch rejected')
  assert request('status')[0]==200;assert request('data')[0]==401
  code,payload,headers=request('setup',{'username':'tlsadmin','password':'ephemeral-tls-password'});assert code==200,payload
  assert 'Secure' in headers['Set-Cookie'] and 'HttpOnly' in headers['Set-Cookie'] and 'SameSite=Strict' in headers['Set-Cookie']
  plain=urllib.request.Request(f'http://localhost:{listener.server_port}/api/data');jar.add_cookie_header(plain);assert not plain.has_header('Cookie')
  checks.append('secure session cookie not sent on HTTP')
  assert request('password',{'oldPassword':'x','newPassword':'irrelevant-password'},{'Origin':'https://evil.example'})[0]==403
  checks.append('cross-origin write rejected')
  data=request('data')[1];no=data['salesmen'][0]['no'];area=data['areas'][0]
  assert request('users',{'username':'tlsdriver','password':'ephemeral-driver-password','role':'Driver','active':True})[0]==200
  shop=request('map-customer',{'name':'TLS test customer','area':area,'address':'Synthetic address','latitude':6.9,'longitude':79.9,'salesmanNo':no,'confirmLocation':True})[1]['shop']
  record=request('deliveries',{'shopId':shop['id'],'date':'2026-11-06','assignedTo':'tlsdriver','plannedQty':10,'operationId':op()})[1]['delivery']
  update={'id':record['id'],'status':'Delivered','deliveredQty':10,'notes':'Synthetic TLS lost reply test','expectedRevision':1,'operationId':op()}
  req=urllib.request.Request(base+'/api/delivery-update');jar.add_cookie_header(req)
  conn=http.client.HTTPSConnection('localhost',listener.server_port,context=trust,timeout=5)
  conn.request('POST','/api/delivery-update',body=json.dumps(update),headers={'Content-Type':'application/json','Cookie':req.get_header('Cookie')})
  response=conn.getresponse();assert response.status==200;response.close();conn.close() # intentionally discard body
  code,retry,_=request('delivery-update',update);assert code==200 and retry['replayed'] and retry['delivery']['revision']==2,retry
  checks.append('lost response retry does not duplicate update')
  pending={**update,'status':'Partial','deliveredQty':4,'notes':'Pending note after session loss','expectedRevision':2,'operationId':op()}
  server.SESSIONS.clear();assert request('delivery-update',pending)[0]==401
  assert request('login',{'username':'tlsadmin','password':'ephemeral-tls-password'})[0]==200
  assert request('delivery-update',pending)[1]['delivery']['revision']==3
  checks.append('same-account reauthentication resumes retained update')
  assert request('delivery-update',{**pending,'operationId':op()})[0]==409
  checks.append('stale revision returns conflict')
  print(json.dumps({'status':'PASS','environment':'loopback TLS on '+os.name,'checks':checks,'physicalWindowsAndroidCellular':False},indent=2))
 finally:listener.shutdown();listener.server_close()
