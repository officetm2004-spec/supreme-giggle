"""Low-volume online smoke checks. Public synthetic coordinates, no customer data."""
import json,os,urllib.request
from road_routes import road_route
checks=[]
def read(url,limit=4_000_000):
 req=urllib.request.Request(url,headers={'User-Agent':'RoutePlan-QA/2.1'})
 with urllib.request.urlopen(req,timeout=20) as response:return response.status,response.read(limit)
for name,url in [('MapLibre module','https://unpkg.com/maplibre-gl@6.16.0/dist/maplibre-gl.mjs'),('MapLibre CSS','https://unpkg.com/maplibre-gl@6.16.0/dist/maplibre-gl.css')]:
 code,body=read(url,256);assert code==200 and body,(name,code);checks.append(name+' reachable')
code,raw=read('https://tiles.openfreemap.org/styles/liberty');style=json.loads(raw);assert style.get('version')==8 and style.get('layers') and style.get('sources');checks.append('OpenFreeMap Liberty style reachable')
os.environ['ROUTEPLAN_OSRM_URL']='https://router.project-osrm.org'
# Synthetic public Colombo-area points, not actual customer locations.
stops=[{'id':'public-smoke-point','name':'Synthetic public test stop','latitude':6.9271,'longitude':79.8612}]
result=road_route(stops,{'latitude':6.9344,'longitude':79.8428})
assert result['distanceKm']>0 and result['minutes']>0 and result.get('geometry',{}).get('type')=='LineString'
checks.append('Live OSRM demo road distance/time/geometry adapter')
print(json.dumps({'status':'PASS','checks':checks,'distanceKm':result['distanceKm'],'minutes':result['minutes'],'scope':'Public service connectivity from this Linux environment only. Not own deployment, customer accuracy, Windows, phone or carrier testing.'},indent=2))
