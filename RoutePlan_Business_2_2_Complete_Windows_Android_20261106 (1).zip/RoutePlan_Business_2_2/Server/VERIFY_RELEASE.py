"""Offline release verification; never touches a production database."""
import ast, json, sqlite3, tempfile, subprocess, shutil, os, sys
from pathlib import Path
root=Path(__file__).resolve().parent
ast.parse((root/'server.py').read_text(encoding='utf-8'))
ast.parse((root/'excel_plans.py').read_text(encoding='utf-8'))
assert (root/'static/index.html').is_file()
assert (root/'static/excel_plan_reference.json').is_file()
with tempfile.TemporaryDirectory(prefix='routeplan_verify_') as tmp:
    env=os.environ.copy();env['ROUTEPLAN_DATA_DIR']=tmp
    env['ROUTEPLAN_PORT']='0'
    sys.path.insert(0,str(root))
    import server
    original=server.DB_PATH
    server.DB_PATH=Path(tmp)/'routeplan.db';server.DATA_DIR=Path(tmp)
    try:
        server.init_db()
        with sqlite3.connect(server.DB_PATH) as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            assert {'shops','excel_plan_rows','excel_plan_priorities','sales_entries','plans'}.issubset(names)
    finally:server.DB_PATH=original
node=shutil.which('node')
if node:
    import re
    html=(root/'static/index.html').read_text(encoding='utf-8')
    scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S|re.I)
    with tempfile.TemporaryDirectory() as tmp:
        for i,script in enumerate(scripts):
            f=Path(tmp)/f'inline{i}.js';f.write_text(script,encoding='utf-8')
            subprocess.run([node,'--check',str(f)],check=True,capture_output=True)
    print('JavaScript syntax: PASS')
else:print('JavaScript syntax: NOT CHECKED (Node.js not installed)')
print('Python syntax, isolated SQLite schema and integrity: PASS')
print('Real Android, LAN and customer GPS tests: REQUIRE ACTUAL DEVICES AND DATA')
