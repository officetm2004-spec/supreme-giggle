# වත්මන් Android/Frontend QA — 2026-11-06

Android emulator workflows PASS. Menu සහ map compatibility fixes ඇතුළත්. වත්මන් සම්පූර්ණ වාර්තාව: ANDROID_EMULATOR_QA_SI.md සහ ANDROID_EMULATOR_TEST_RESULTS.json. Physical acceptance ඉතිරියි.

## පෙර release සටහන් — පහත hosted තත්ත්වයන් මෙවර නැවත පරීක්ෂා නොකළා

# වත්මන් පරීක්ෂණ තත්ත්වය — 2026-11-06

ශ්‍රී ලංකා routing memory blocker විසඳා ඇත. Hosted private-network road routing පරීක්ෂණ 3 PASS. සම්පූර්ණ පරීක්ෂණ සහ සීමා OPERATIONS_RELEASE_GUIDE_SI.md සහ QA_TEST_RESULTS.json හි ඇත.

- Dispatch Board, Plan vs Actual CSV, delivery proof, system status: එකතු කර API/DOM/permissions tests PASS.
- Capacity/work/service-time/depot trip planner: constraint tests + real local OSRM matrix integration PASS.
- Production backup isolated restore: tables 16 schema/all rows matched.
- Separate test app restored startup, driver login/photo/saved route recovery: PASS.
- Offline restart with saved customer and route details: simulated DOM/IndexedDB PASS.
- Desktop rendered fixture screens 9 and initial 390px menu/delivery layout: reviewed.
- Physical Windows/Android/GPS/camera/mobile network/print: PENDING.
- Real customer cleanup/route acceptance: PENDING; hosted customer records currently 0.
- Full offline basemap tiles and global fleet optimization: not implemented.
