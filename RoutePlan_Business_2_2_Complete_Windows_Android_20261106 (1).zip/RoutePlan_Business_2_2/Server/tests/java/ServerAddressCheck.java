import com.routeplan.mobile.ServerAddress;
public class ServerAddressCheck {
 private static void check(boolean yes,String label){if(!yes)throw new AssertionError(label);}
 public static void main(String[] args){
  String[] good={"https://route.example.com","https://route.example.com:8443/","HTTPS://Route.Example.com/","http://192.168.1.6:8082","http://10.0.0.2:80","http://172.16.0.1:8080","http://172.31.255.255:8080"};
  for(String s:good)check(ServerAddress.valid(s),"Valid address rejected: "+s);
  String[] bad={"http://route.example.com","http://8.8.8.8","http://172.32.0.1","http://192.168.300.1","http://010.0.0.1","https://user:pass@route.example.com","https://route.example.com/path","https://route.example.com?x=1","https://route.example.com#x","file:///tmp/test","https://route.example.com:0","https://route.example.com:65536"};
  for(String s:bad)check(!ServerAddress.valid(s),"Unsafe address accepted: "+s);
  check("https://route.example.com".equals(ServerAddress.normalize("HTTPS://Route.Example.com/")),"Scheme/host normalization");
  check(ServerAddress.sameOrigin("https://route.example.com:443/api/status","https://route.example.com"),"Equivalent HTTPS origin");
  check(!ServerAddress.sameOrigin("https://route.example.com.evil.test/","https://route.example.com"),"Host prefix attack");
  check(!ServerAddress.sameOrigin("https://user@route.example.com/","https://route.example.com"),"Credentials in URL");
  check(!ServerAddress.sameOrigin("http://route.example.com/","https://route.example.com"),"HTTPS downgrade");
  check(!ServerAddress.sameOrigin("https://route.example.com:8443/","https://route.example.com"),"Port mismatch");
  System.out.println("PASS: Android shared origin/address rules (pure Java JVM; not Android runtime)");
 }
}
