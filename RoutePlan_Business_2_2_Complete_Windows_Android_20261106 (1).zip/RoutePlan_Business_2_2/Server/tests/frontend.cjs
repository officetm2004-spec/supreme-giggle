const {JSDOM,CookieJar,VirtualConsole}=require('jsdom');const {indexedDB}=require('fake-indexeddb');
const assert=require('node:assert');const url='http://127.0.0.1:8101';const jar=new CookieJar();
let offline=false,dropReply=false,hangUpdate=false,errors=[],previewRoute=null;
async function fetchCookie(path,opts={}){const u=new URL(path,url).href;if(offline&&u.includes('/api/'))throw new TypeError('Synthetic network interruption');if(u.endsWith('/api/delivery-route-plans')&&previewRoute)return new Response(JSON.stringify({plans:[previewRoute]}),{headers:{'Content-Type':'application/json'}});if(hangUpdate&&u.endsWith('/api/delivery-update'))return new Promise((resolve,reject)=>{opts.signal.addEventListener('abort',()=>reject(new DOMException('Synthetic blackhole abort','AbortError')),{once:true})});const cookie=jar.getCookieStringSync(u);const r=await fetch(u,{...opts,headers:{...(opts.headers||{}),Cookie:cookie}});for(const s of r.headers.getSetCookie())jar.setCookieSync(s,u);if(dropReply&&u.endsWith('/api/delivery-update')){dropReply=false;await r.text();throw new TypeError('Synthetic dropped server reply')}return r}
async function api(path,body){const r=await fetchCookie('/api/'+path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const p=await r.json();assert(r.ok,JSON.stringify(p));return p}
const wait=async(fn,label)=>{for(let i=0;i<150;i++){if(await fn())return;await new Promise(r=>setTimeout(r,40))}throw Error('Timed out: '+label)};
(async()=>{let status=await api('status');if(!status.initialized)await api('setup',{username:'uiadmin',password:'ui-test-password'});else await api('login',{username:'uiadmin',password:'ui-test-password'});
await api('users',{username:'uidriver',password:'ui-test-password',role:'Driver',active:true});let master=await api('data');let no=master.salesmen[0].no;
let s=await api('map-customer',{name:'UI test customer',area:master.areas[0],address:'Synthetic address',latitude:6.9,longitude:79.9,salesmanNo:no,confirmLocation:true});
let created=await api('deliveries',{shopId:s.shop.id,date:'2026-11-06',assignedTo:'uidriver',plannedQty:10,operationId:crypto.randomUUID().replaceAll('-','')});
previewRoute={id:'synthetic-trip',date:'2026-11-06',vehicle:'QA vehicle',driver:'uidriver',loadUnit:'units',load:10,capacity:10,distanceKm:1,travelMinutes:3,finishMinutes:500,createdAt:'2026-11-06T03:00:00Z',method:'Synthetic matrix fixture',excluded:[],geometry:{type:'LineString',coordinates:[[79.8,6.9],[79.9,6.91]]},stops:[{...created.delivery,latitude:6.9,longitude:79.9,arrivalMinutes:490,departureMinutes:500,loadQty:10}]};
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));vc.on('error',(...args)=>errors.push(args.join(' ')));
const dom=await JSDOM.fromURL(url,{resources:'usable',runScripts:'dangerously',cookieJar:jar,virtualConsole:vc,pretendToBeVisual:true,beforeParse(w){w.fetch=fetchCookie;w.AbortController=AbortController;w.indexedDB=indexedDB;w.structuredClone=structuredClone;w.scrollTo=()=>{};w.confirm=()=>true;w.alert=()=>{};w.ResizeObserver=class{observe(){}disconnect(){}};w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});}});
const w=dom.window,d=w.document;await wait(()=>d.querySelector('#dlRows table'),'delivery workspace boot');
await wait(()=>d.querySelector('#opsUserRows table'),'admin management boot');assert(d.querySelector('#opsAdmin'));assert(d.querySelector('#crNewLocation'));assert(d.querySelector('#crVectorMap'));
// Exercise the real sales form and verify persisted history after a data refresh.
w.showView('sales');
d.querySelector('#saleDate').value='2026-11-06';
d.querySelector('#salePerson').value=String(no);
d.querySelector('#salePerson').dispatchEvent(new w.Event('change'));
assert(d.querySelector('#saleAreaPreview').value,'salesman area preview');
d.querySelector('#saleAmount').value='1234.50';
d.querySelector('#saleNotes').value='UI sales history roundtrip';
d.querySelector('#salesForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
await wait(()=>d.querySelector('#salesTable').textContent.includes('UI sales history roundtrip'),'sales form saved history');
const savedSale=(await api('data')).salesEntries.find(x=>x.notes==='UI sales history roundtrip');
assert(savedSale);assert.equal(savedSale.amount,1234.5);assert.equal(String(savedSale.salesman_no),String(no));
d.querySelector('#salesFilterDate').value='2026-11-05';d.querySelector('#salesFilterDate').dispatchEvent(new w.Event('change'));
assert(!d.querySelector('#salesTable').textContent.includes('UI sales history roundtrip'),'history date filter');
d.querySelector('#salesFilterDate').value='';d.querySelector('#salesFilterDate').dispatchEvent(new w.Event('change'));
assert(d.querySelector('#salesTable').textContent.includes('UI sales history roundtrip'));
w.showView('dashboard');
d.querySelector('#menuToggle').click();assert.equal(d.querySelector('#menuToggle').getAttribute('aria-expanded'),'true');d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));assert.equal(d.querySelector('#menuToggle').getAttribute('aria-expanded'),'false');d.querySelector('#menuToggle').click();d.querySelector('#menuClose').click();assert(!d.body.classList.contains('menu-open'));
assert(d.querySelector('#visualAnalytics .va-line svg'),'saved sales trend');assert(d.querySelector('.va-donut'),'plan status chart');assert.equal(d.querySelectorAll('.va-column-track').length,5,'five original colour bands');d.querySelector('#analyticsDays').value='7';d.querySelector('#analyticsDays').dispatchEvent(new w.Event('change'));assert(d.querySelector('.va-line svg').getAttribute('aria-label').includes('7 days'),'trend period selection');
assert.equal(d.querySelectorAll('.amith-route-card').length,12,'all baseline routes represented');assert(d.querySelector('.amith-route-card .amith-meter[role=progressbar]'),'accessible amount meter');
w.eval(`state.routeAmounts={'Synthetic A':1250,'Synthetic B':750};state.shops=[{area:'Synthetic A',latitude:6.9,longitude:79.9},{area:'Synthetic A',latitude:null,longitude:null}];state.plans=[{area:'Synthetic A',status:'Completed'},{area:'Synthetic A',status:'Pending'}];renderRouteInsights()`);
assert(d.querySelector('#routeInsights').textContent.includes('2,000'),'sales total');
const area=d.querySelector('#insightArea');area.value='Synthetic A';area.dispatchEvent(new w.Event('change'));
assert(d.querySelector('#routeInsights').textContent.includes('1,250'),'filtered sales total');
assert(d.querySelector('.di-ring').getAttribute('aria-label').includes('1 of 2'),'valid GPS count');
assert.equal(d.querySelectorAll('.di-bar').length,1,'area filter');
w.eval(`state.routeAmounts={};renderRouteInsights()`);assert(d.querySelector('#routeInsights').textContent.includes('No positive sales amounts'),'empty state');
d.querySelector('#dlBoardDate').value='2026-11-06';d.querySelector('#dlBoardDate').dispatchEvent(new w.Event('change'));await wait(()=>d.querySelector('#dlBoard').textContent.includes('UI test customer'),'dispatch board customers');assert(d.querySelector('#dlActual').textContent.includes('Planned: 1'));assert(d.querySelector('#dlSystem').textContent.includes('Routing:'));assert(d.querySelector('#dlSavedRoutes').textContent.includes('Synthetic matrix fixture'));
w.showView('deliveries');let b=[...d.querySelectorAll('[data-dl-edit]')].find(x=>x.dataset.dlEdit===created.delivery.id);b.click();d.querySelector('#dlEditStatus').value='Delivered';d.querySelector('#dlEditStatus').dispatchEvent(new w.Event('change'));d.querySelector('#dlEditForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
await wait(async()=>{const p=await api('deliveries');return p.deliveries.find(x=>x.id===created.delivery.id)?.revision===2},'online delivery update');await wait(()=>d.querySelector('#dlMessage')?.textContent.includes('0 unsynced'),'queue cleared');
const edit=()=>[...d.querySelectorAll('[data-dl-edit]')].find(x=>x.dataset.dlEdit===created.delivery.id).click();edit();d.querySelector('#dlEditStatus').value='Partial';d.querySelector('#dlEditQty').value='4';d.querySelector('#dlEditNote').value='Offline test note';offline=true;d.querySelector('#dlEditForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
await wait(()=>d.querySelector('#dlRows').textContent.includes('DEVICE ONLY'),'offline note persisted');
offline=false;await api('delivery-update',{id:created.delivery.id,status:'Failed',deliveredQty:0,notes:'Other device synthetic update',expectedRevision:2,operationId:crypto.randomUUID().replaceAll('-','')});
await w.RouteDelivery.flush();await wait(()=>d.querySelector('[data-dl-server]'),'conflict review');d.querySelector('[data-dl-server]').click();await wait(()=>d.querySelector('#dlMessage').textContent.includes('0 unsynced'),'conflict resolved');
// The server commits, but the client loses the reply. Retry must replay once.
edit();d.querySelector('#dlEditStatus').value='Delivered';d.querySelector('#dlEditQty').value='10';d.querySelector('#dlEditNote').value='Lost reply test';dropReply=true;
d.querySelector('#dlEditForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
await wait(()=>d.querySelector('#dlRows').textContent.includes('DEVICE ONLY'),'lost reply retained');
await wait(async()=>{const p=await api('deliveries');return p.deliveries.find(x=>x.id===created.delivery.id).revision===4},'lost reply committed');
await w.RouteDelivery.flush();await wait(()=>d.querySelector('#dlMessage').textContent.includes('0 unsynced'),'lost reply replayed');
assert.equal((await api('deliveries')).deliveries.find(x=>x.id===created.delivery.id).revision,4);
// Blackholed delivery request must time out, retain its note, then recover.
edit();d.querySelector('#dlEditStatus').value='Partial';d.querySelector('#dlEditQty').value='3';d.querySelector('#dlEditNote').value='Timeout recovery test';hangUpdate=true;
d.querySelector('#dlEditForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
let timedOut=false;for(let i=0;i<500;i++){if(d.querySelector('#dlMessage').textContent.includes('timed out')){timedOut=true;break}await new Promise(r=>setTimeout(r,40))}
assert(timedOut,'Blackholed request did not time out');assert(d.querySelector('#dlRows').textContent.includes('DEVICE ONLY'));
hangUpdate=false;await w.RouteDelivery.flush();await wait(()=>d.querySelector('#dlMessage').textContent.includes('0 unsynced'),'timeout reconnect sync');
assert.equal((await api('deliveries')).deliveries.find(x=>x.id===created.delivery.id).revision,5);
offline=true;
const restart=await JSDOM.fromURL(url+'/offline.html',{resources:'usable',runScripts:'dangerously',cookieJar:jar,virtualConsole:vc,beforeParse(v){v.fetch=fetchCookie;v.AbortController=AbortController;v.indexedDB=indexedDB;v.structuredClone=structuredClone;v.localStorage.setItem('routeplan-active-owner','uiadmin');Object.defineProperty(v.navigator,'onLine',{value:false});v.confirm=()=>true;}});
await wait(()=>restart.window.document.querySelector('#dlSavedRoutes')?.textContent.includes('Synthetic matrix fixture'),'offline restart saved trip');assert(restart.window.document.querySelector('#dlSavedRoutes').textContent.includes('UI test customer'));restart.window.close();offline=false;
console.log(JSON.stringify({result:'PASS',checks:['sales form, salesman area, persisted database history and date filter','full app script boot','dashboard totals, filters, GPS validity and empty state','trend period, status donut and five colour columns','menu open, close and Escape keyboard behavior','dispatch board, plan actual and system status','offline restart retains saved customer/route details','admin users panel','custom customer map controls','online delivery update','persistent offline queue','409 conflict review','server record resolution','lost response retry without duplicate write','blackholed request timeout','retained note sync after recovery'],errors}));dom.window.close();if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
