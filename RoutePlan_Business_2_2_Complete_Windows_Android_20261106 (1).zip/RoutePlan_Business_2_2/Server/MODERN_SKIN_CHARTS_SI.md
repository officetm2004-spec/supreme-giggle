# නව පෙනුම සහ ප්‍රස්ථාර

Blue Glass sidebar, active navigation, readable translucent panels, responsive cards, keyboard focus outlines සහ print layout එකතු කර ඇත.

- Daily sales area/line chart: දින 7/14/30 තේරීම. අවසන් saved sale දිනයෙන් පරාසය අවසන් වේ; එය අද දින ලෙස හෝ forecast එකක් ලෙස නොපෙන්වයි. එක් එක් දින අගයන් table එකකින්ද බැලිය හැකියි.
- Plan status donut: Planned / In Progress / Completed / Cancelled සැබෑ ගණන්.
- Route band column chart: මුල් Excel වර්ණ සීමා අනුව routes ගණන.
- Salesman lollipop comparison: තෝරාගත් area එකේ සියලු saved dates හි වැඩිම විකුණුම් ඇති salesmen හය. Line chart date range එකට වෙනස් scope එක පැහැදිලිව label කර ඇත.
- පෙර තිබූ GPS completeness ring සහ automatic route colour cards රැක ඇත.

Area filter ප්‍රස්ථාරවලට යෙදේ. Empty states සහ data unavailable states වෙනම පෙන්වයි. Charts labels, colour legends, tooltip titles සහ exact-value table ඇත. දත්ත නොමැති විට අනුමාන සංඛ්‍යා දමන්නේ නැත.

JavaScript/Python/schema පරීක්ෂණ සහ DOM chart selector/count පරීක්ෂණ සමත්. සැබෑ Windows/Android rendered visual acceptance තවම සිදු කර නැත. Road-routing memory blocker වෙනම ඉතිරිව ඇත.
