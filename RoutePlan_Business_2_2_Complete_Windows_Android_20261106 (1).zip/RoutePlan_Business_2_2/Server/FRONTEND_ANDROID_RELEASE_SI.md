# යාවත්කාලීන පරීක්ෂණ වාර්තාව

Frontend සහ Android emulator පරීක්ෂණ සමත්. Menu backdrop සහ පැරණි WebView map compatibility නිවැරදි කර තිබේ.

විස්තර සහ සීමා: [ANDROID_EMULATOR_QA_SI.md](ANDROID_EMULATOR_QA_SI.md). Physical phone/carrier acceptance තවම ඉතිරියි.
