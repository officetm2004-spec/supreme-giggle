"""Create the first admin from the server terminal; no credentials in shell history."""
import getpass,re
import server
server.init_db()
with server.get_db() as db:
    db.execute('BEGIN IMMEDIATE')
    if db.execute('SELECT COUNT(*) FROM users').fetchone()[0]:raise SystemExit('Accounts already exist. Use Admin Users or reset_admin_password.py.')
    name=input('Admin username: ').strip()
    if not re.fullmatch(r'[A-Za-z0-9._-]{3,40}',name):raise SystemExit('Invalid username.')
    password=getpass.getpass('Admin password (at least 10 characters): ')
    if not 10<=len(password)<=1024 or password!=getpass.getpass('Confirm password: '):raise SystemExit('Password validation failed.')
    salt,digest=server.password_hash(password)
    db.execute("INSERT INTO users(username,salt,password_hash,created_at,role,active) VALUES (?,?,?,?,'Admin',1)",(name,salt,digest,server.utcnow()))
print('Administrator created. Sign in over HTTPS.')
