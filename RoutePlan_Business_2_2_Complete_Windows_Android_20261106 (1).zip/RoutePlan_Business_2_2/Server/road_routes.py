"""OSRM road travel times; endpoint set by the operator, never by API clients."""
import json, math, os
from urllib.request import urlopen

def point(value):
    if not isinstance(value,dict): raise ValueError('Enter depot latitude and longitude.')
    try:
        lat,lon=float(value['latitude']),float(value['longitude'])
    except (ValueError,TypeError,KeyError): raise ValueError('Enter valid depot coordinates.')
    if not math.isfinite(lat) or not math.isfinite(lon) or not -90<=lat<=90 or not -180<=lon<=180:
        raise ValueError('Depot coordinates are outside the valid range.')
    return {'latitude':lat,'longitude':lon}

def query(service,points,options):
    base=os.environ.get('ROUTEPLAN_OSRM_URL','').rstrip('/')
    if not base: raise RuntimeError('Road routing is not configured. Set ROUTEPLAN_OSRM_URL to an OSRM server covering Sri Lanka. No road distance was calculated.')
    coords=';'.join(f"{p['longitude']},{p['latitude']}" for p in points)
    try:
        with urlopen(f'{base}/{service}/v1/driving/{coords}?{options}',timeout=25) as response:
            raw=response.read(4_000_001)
        if len(raw)>4_000_000: raise ValueError('Response too large')
        data=json.loads(raw)
        if data.get('code')!='Ok': raise ValueError('No route available')
        return data
    except Exception as exc: raise RuntimeError('Road routing service unavailable or no drivable route. Check the service and customer GPS; no straight-line substitute was used.') from exc

def road_route(stops,depot,return_to_depot=False):
    depot=point(depot)
    points=[depot]+[point(s) for s in stops]
    matrix=query('table',points,'annotations=duration').get('durations')
    n=len(points)
    if not isinstance(matrix,list) or len(matrix)!=n or any(not isinstance(row,list) or len(row)!=n for row in matrix):
        raise RuntimeError('Invalid routing duration matrix.')
    if any(v is None or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for row in matrix for v in row):
        raise RuntimeError('Some customers cannot be reached by road. Review GPS coordinates.')
    remaining=set(range(1,n));order=[0]
    while remaining:
        nxt=min(remaining,key=lambda j:(matrix[order[-1]][j],j));order.append(nxt);remaining.remove(nxt)
    def cost(seq):
        return sum(matrix[a][b] for a,b in zip(seq,seq[1:]))+(matrix[seq[-1]][0] if return_to_depot else 0)
    for _ in range(4):
        changed=False
        for i in range(1,n-1):
            for j in range(i+1,n):
                alt=order[:i]+order[i:j+1][::-1]+order[j+1:]
                if cost(alt)+.01<cost(order): order=alt;changed=True
        if not changed: break
    ordered=[stops[i-1] for i in order[1:]]
    route_points=[points[i] for i in order]+([depot] if return_to_depot else [])
    data=query('route',route_points,'overview=full&geometries=geojson&steps=false')
    try:
        route=data['routes'][0];distance=route['distance'];duration=route['duration']
        if any(not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in (distance,duration)): raise ValueError()
        legs=[{'distanceKm':x['distance']/1000,'minutes':x['duration']/60} for x in route['legs']]
    except (KeyError,IndexError,TypeError,ValueError): raise RuntimeError('Invalid road route response.')
    return {'geometry':route.get('geometry'),'stops':ordered,'distanceKm':distance/1000,'minutes':duration/60,'legs':legs,'depot':depot,'returnToDepot':return_to_depot,'method':'OSRM road-time heuristic; not guaranteed optimal; no live traffic or service time'}
