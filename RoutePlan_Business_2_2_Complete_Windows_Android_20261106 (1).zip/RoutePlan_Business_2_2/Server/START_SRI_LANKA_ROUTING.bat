@echo off
setlocal
cd /d "%~dp0"
if not exist "routing\data\prepared.json" (
  echo First run: python routing\prepare_sri_lanka.py
  pause
  exit /b 1
)
if not defined ROUTEPLAN_OSRM_IMAGE set "ROUTEPLAN_OSRM_IMAGE=ghcr.io/project-osrm/osrm-backend:latest"
echo Starting Sri Lanka routing on http://127.0.0.1:5000
Docker run --rm -p 127.0.0.1:5000:5000 -v "%~dp0routing\data:/data:ro" "%ROUTEPLAN_OSRM_IMAGE%" osrm-routed --algorithm mld --max-table-size 100 /data/sri-lanka-latest.osrm
pause
endlocal
