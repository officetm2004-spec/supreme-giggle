ROUTEPLAN EXCEL INTEGRATION — STAGE 3

1. මෙම ZIP එක වෙනම folder එකකට Extract කරන්න. දැනට පවතින RoutePlan folder එකට overwrite නොකරන්න.
2. වෙනම TEST Database copy එකක් භාවිත කරන්න. Production database එකට connect නොකරන්න.
3. Server එක port 8081 භාවිත කර ආරම්භ කරන්න (START_EXCEL_TEST.bat).
4. Data & Backup -> Excel Sales Planning යන්න. AMITH E (1)(1).xlsx තෝරා Preview Excel ඔබන්න.
5. Match count සහ warnings පරීක්ෂා කර Import verified plan ඔබන්න.
6. Excel ROUTE සහ DASHBOARD අගයන් වෙනම tables වලට පමණක් import වේ. Existing Sales, Shops, GPS, Plans, Dispatch වෙනස් නොවේ.
7. Excel totals historical workbook snapshot values පමණි; live database sales නොවේ.
8. මෙම workbook එකේ Customer names/coordinates නැති නිසා GPS customer-specific route optimization Excel එකෙන් පමණක් කළ නොහැක.
9. Python standard library only. Excel formulas evaluate නොකර cached cell values කියවයි.
10. Windows/Android LAN live testing වෙනම සිදු කළ යුතුයි.
