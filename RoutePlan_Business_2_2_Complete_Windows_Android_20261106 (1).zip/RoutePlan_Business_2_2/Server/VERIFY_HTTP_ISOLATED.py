"""Local HTTP smoke tests; uses an ephemeral DB and localhost-only listener."""
import os, sys, json, sqlite3, tempfile, threading, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='routeplan_http_') as temp:
    os.environ['ROUTEPLAN_DATA_DIR']=temp
    os.environ['ROUTEPLAN_HOST']='127.0.0.1'
    os.environ['ROUTEPLAN_PORT']='0'
    sys.path.insert(0,str(ROOT))
    import server
    server.init_db()
    httpd=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
    thread=threading.Thread(target=httpd.serve_forever,daemon=True)
    thread.start()
    url=f'http://127.0.0.1:{httpd.server_port}'
    def request(path,method='GET',payload=None):
        data=None if payload is None else json.dumps(payload).encode()
        req=urllib.request.Request(url+path, data=data,method=method,headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=5) as resp:
                return resp.status,resp.read()
        except urllib.error.HTTPError as err:
            return err.code,err.read()
    try:
        status,body=request('/api/status')
        assert status==200 and json.loads(body)['initialized'] is False
        assert request('/')[0]==200
        assert request('/api/data')[0]==401
        assert request('/api/excel-plan')[0]==401
        assert request('/api/excel-import','POST',{'xlsxBase64':'AAAA'})[0]==401
        assert request('/../../server.py')[0] in (403,404)
        with sqlite3.connect(Path(temp)/'routeplan.db') as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        print('HTTP smoke tests: PASS (status, static, auth protection, isolated DB)')
    finally:
        httpd.shutdown();httpd.server_close();thread.join(timeout=5)
print('Physical Android/LAN/GPS and road-network routing: NOT CERTIFIED')
