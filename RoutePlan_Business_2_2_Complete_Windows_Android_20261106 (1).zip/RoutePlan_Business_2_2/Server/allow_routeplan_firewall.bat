@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
netsh advfirewall firewall add rule name="RoutePlan TCP 8080 - Private LAN" dir=in action=allow protocol=TCP localport=8080 profile=private
if %errorlevel%==0 (
  echo Firewall rule added for private networks.
) else (
  echo Could not create firewall rule. Check administrator permissions.
)
pause
