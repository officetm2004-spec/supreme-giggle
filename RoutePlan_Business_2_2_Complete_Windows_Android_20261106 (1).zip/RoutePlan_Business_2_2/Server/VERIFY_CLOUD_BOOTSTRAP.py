"""Disposable local API test for private first-admin activation."""
import os,tempfile,threading,urllib.request,urllib.error,json
with tempfile.TemporaryDirectory(prefix='routeplan_activation_') as tmp:
 os.environ['ROUTEPLAN_DATA_DIR']=tmp
 os.environ['ROUTEPLAN_SETUP_TOKEN']='synthetic-activation-token-only'
 os.environ['ROUTEPLAN_DISABLE_WEB_SETUP']='0'
 import server
 server.init_db();http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
 threading.Thread(target=http.serve_forever,daemon=True).start()
 base=f'http://127.0.0.1:{http.server_port}'
 def request(path,data=None):
  r=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(r) as s:return s.status,json.load(s)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 try:
  assert request('/api/status')[1]['setupProtected'] is True
  user={'username':'localtestadmin','password':'synthetic-local-password'}
  assert request('/api/setup',user)[0]==403
  assert request('/api/setup',{**user,'setupToken':'wrong'})[0]==403
  assert request('/api/setup',{**user,'setupToken':'වැරදි'})[0]==403
  assert request('/api/setup',{**user,'setupToken':'synthetic-activation-token-only'})[0]==200
  assert request('/api/setup',{**user,'setupToken':'synthetic-activation-token-only'})[0]==409
  assert request('/api/status')[1]['initialized'] is True
  print('PASS: private activation token required; wrong/missing token blocked; first admin created once.')
 finally:http.shutdown();http.server_close()
