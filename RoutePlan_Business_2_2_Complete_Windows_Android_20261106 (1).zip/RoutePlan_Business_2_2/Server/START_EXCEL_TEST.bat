@echo off
cd /d "%~dp0"
set "ROUTEPLAN_PORT=8081"
set "ROUTEPLAN_DATA_DIR=%~dp0data_test"
echo TEST ONLY: http://localhost:8081
python server.py
pause
