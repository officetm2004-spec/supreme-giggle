"""Boundary/transaction checks for AMITH E automatic delivery planning."""
import os,tempfile,uuid
with tempfile.TemporaryDirectory() as tmp:
 os.environ['ROUTEPLAN_DATA_DIR']=tmp
 import server
 from auto_planning import classify,reconcile,current_amounts,amount_band
 server.init_db()
 with server.get_db() as baseline:
  assert baseline.execute('SELECT COUNT(*) FROM sales_entries').fetchone()[0]==150
  assert baseline.execute("SELECT COUNT(*) FROM plans WHERE id LIKE 'amith-%'").fetchone()[0]==12
 server.init_db()
 with server.get_db() as baseline:assert baseline.execute('SELECT COUNT(*) FROM sales_entries').fetchone()[0]==150

 for n,k in [(0,'blue'),(999999.99,'blue'),(1000000,'green'),(1499999.99,'green'),(1500000,'yellow'),(1999999.99,'yellow'),(2000000,'orange'),(3000000,'orange'),(3000000.01,'red')]:assert amount_band(n)['key']==k

 for amount,expected in [(0,None),(99999.99,None),(100000,4),(299999.99,4),(300000,3),(499999.99,3),(500000,2),(899999.99,2),(900000,1)]:assert classify(amount)[0]==expected
 with server.get_db() as db:
  db.execute('DELETE FROM plans');db.execute('DELETE FROM sales_entries');db.execute("UPDATE dispatch SET last_date='2026-02-02',reset_at='2099-01-01'")
  p=db.execute('SELECT * FROM salesmen ORDER BY no LIMIT 1').fetchone();area=p['area']
  def sale(date,amount):
   sid=uuid.uuid4().hex;db.execute('INSERT INTO sales_entries VALUES (?,?,?,?,?,?,?,?,?)',(sid,date,p['no'],p['name'],area,amount,'',server.utcnow(),'test'));return sid
  sale('2026-02-01',900000);sale('2026-02-02',900000)
  assert current_amounts(db).get(area,0)==0,'strict dispatch cutoff'
  sid=sale('2026-02-03',100000)
  assert reconcile(db,server.utcnow())['created']==1
  plan=db.execute("SELECT * FROM plans WHERE id LIKE 'amith-%'").fetchone();pid=plan['id'];assert plan['type']=='Delivery' and 'LOW' in plan['notes']
  assert reconcile(db,server.utcnow())['created']==0
  db.execute('UPDATE sales_entries SET amount=900000 WHERE id=?',(sid,));reconcile(db,server.utcnow())
  assert 'HIGH' in db.execute('SELECT notes FROM plans WHERE id=?',(pid,)).fetchone()[0]
  db.execute('UPDATE sales_entries SET amount=99999 WHERE id=?',(sid,));reconcile(db,server.utcnow());assert not db.execute('SELECT 1 FROM plans WHERE id=?',(pid,)).fetchone()
  db.execute('UPDATE sales_entries SET amount=500000 WHERE id=?',(sid,));reconcile(db,server.utcnow())
  db.execute("UPDATE plans SET status='In Progress',updated_by='admin',notes='Human edit' WHERE id=?",(pid,));db.execute('UPDATE sales_entries SET amount=0 WHERE id=?',(sid,));reconcile(db,server.utcnow());assert db.execute('SELECT notes FROM plans WHERE id=?',(pid,)).fetchone()[0]=='Human edit'
  db.execute('DELETE FROM plans');db.execute('UPDATE sales_entries SET amount=500000 WHERE id=?',(sid,));reconcile(db,server.utcnow())
  db.execute("UPDATE dispatch SET last_date='2026-02-03' WHERE area=?",(area,));reconcile(db,server.utcnow());assert db.execute('SELECT status FROM plans WHERE id=?',(pid,)).fetchone()[0]=='Cancelled'
 print('PASS: all threshold boundaries, strict sales-date cutoff, backdated data, idempotency, amount changes, manual/in-progress preservation, dispatch cycle retirement')
