/* RoutePlan Business navigation and device-local themes. No business data is changed. */
(function(){
 'use strict';
 const paths={home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4M17 3v4M3 11h18M8 15h3M8 18h6"/>',map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15M15 6v15"/><circle cx="15" cy="10" r="2"/>',truck:'<path d="M3 6h11v11H3zM14 10h4l3 4v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',moon:'<path d="M20.5 13a8.8 8.8 0 0 1-10-10 9 9 0 1 0 10 10z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',more:'<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',route:'<circle cx="6" cy="6" r="2.3"/><circle cx="18" cy="18" r="2.3"/><path d="M8.5 6H16a4 4 0 0 1 0 8H8a4 4 0 0 0 0 8"/>',phone:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 18h4"/>'};
 const icon=(key)=>'<svg class="business-icon" viewBox="0 0 24 24" aria-hidden="true">'+paths[key]+'</svg>';
 let current='overview';
 function applyTheme(value){
  const dark=value==='dark';document.body.classList.toggle('rp-dark',dark);document.documentElement.setAttribute('data-business-theme',dark?'dark':'light');
  try{localStorage.setItem('routeplan-business-theme',dark?'dark':'light')}catch{}
  const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=dark?'#111e31':'#ffffff';
  document.querySelectorAll('[data-business-theme-toggle]').forEach(b=>{b.innerHTML=icon(dark?'sun':'moon')+(b.classList.contains('business-theme-choice')?'<span>'+(dark?'Light appearance':'Dark appearance')+'</span>':'');b.setAttribute('aria-label',dark?'Switch to light theme':'Switch to dark theme');b.setAttribute('aria-pressed',String(dark))});
  if(window.RoutePlanDevice&&window.RoutePlanDevice.setTheme)try{window.RoutePlanDevice.setTheme(dark)}catch{}
 }
 function themeButton(className){const b=document.createElement('button');b.type='button';b.className=className||'';b.setAttribute('data-business-theme-toggle','');b.onclick=()=>applyTheme(document.body.classList.contains('rp-dark')?'light':'dark');return b}
 function nativeMenu(){if(window.RoutePlanDevice&&window.RoutePlanDevice.openMenu)window.RoutePlanDevice.openMenu()}
 function updateNav(){
  const active=document.querySelector('.section.active');if(active)current=active.id;
  document.querySelectorAll('[data-business-view]').forEach(b=>{
   const view=b.getAttribute('data-business-view'),original=document.querySelector('.sidebar .navbtn[data-view="'+view+'"]');
   b.hidden=!!original&&original.hidden;
   const selected=view===current;b.classList.toggle('active',selected);if(selected)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
  });
  const nav=document.querySelector('.business-bottom-nav');if(nav){const count=[...nav.querySelectorAll('button')].filter(b=>!b.hidden).length;nav.style.gridTemplateColumns='repeat('+count+',minmax(0,1fr))'}
 }
 function utilityActions(){
  const tools=document.getElementById('businessTools');if(!tools)return;
  document.querySelectorAll('.topactions button').forEach(b=>{const text=b.textContent.trim();if(text==='Print'||text==='Change password'||text==='Sign out'){b.classList.add('business-utility-action');tools.appendChild(b)}});
 }
 function decorateAuth(){const b=document.querySelector('.auth-brand');if(b&&!b.dataset.businessDecorated){b.dataset.businessDecorated='1';b.innerHTML='<span class="business-brand-icon">'+icon('route')+'</span><span>RoutePlan</span>'}}
 function init(){
  document.body.classList.add('rp-business');
  const sharedNotice=[...document.querySelectorAll('.main>.notice')].find(n=>n.textContent.includes('Shared database connected'));if(sharedNotice)sharedNotice.id='businessSharedNotice';
  const bar=document.querySelector('.mobile-nav-bar'),toggle=document.getElementById('menuToggle'),brand=bar&&bar.querySelector('strong');
  if(bar&&toggle&&brand){brand.className='business-wordmark';brand.innerHTML='<span class="business-brand-icon">'+icon('route')+'</span><span>RoutePlan<small>Business workspace</small></span>';const actions=document.createElement('div');actions.className='business-header-actions';actions.appendChild(themeButton());toggle.innerHTML=icon('menu');toggle.setAttribute('aria-label','Open main menu');actions.appendChild(toggle);if(window.RoutePlanDevice){const b=document.createElement('button');b.type='button';b.innerHTML=icon('more');b.setAttribute('aria-label','Phone GPS and connection diagnostics');b.onclick=nativeMenu;actions.appendChild(b)}bar.appendChild(actions)}
  const side=document.getElementById('appSidebar');const tools=document.createElement('div');tools.id='businessTools';tools.className='business-tools';tools.innerHTML='<div class="business-tools-label">Workspace controls</div>';tools.appendChild(themeButton('business-theme-choice'));if(window.RoutePlanDevice){const b=document.createElement('button');b.type='button';b.className='business-theme-choice';b.innerHTML=icon('phone')+'<span>Phone GPS & diagnostics</span>';b.onclick=nativeMenu;tools.appendChild(b);const floating=document.createElement('button');floating.type='button';floating.className='business-auth-tools';floating.setAttribute('aria-label','Device options and connection diagnostics');floating.innerHTML=icon('more');floating.onclick=nativeMenu;document.body.appendChild(floating)}if(side)side.appendChild(tools);
  const nav=document.createElement('nav');nav.className='business-bottom-nav';nav.setAttribute('aria-label','Quick navigation');
  for(const [view,label,key] of [['overview','Home','home'],['planner','Plans','calendar'],['shops','Map','map'],['deliveries','Delivery','truck'],['more','More','grid']]){const b=document.createElement('button');b.type='button';b.setAttribute('data-business-view',view);b.innerHTML=icon(key)+'<span>'+label+'</span>';b.onclick=()=>{if(view==='more')toggle.click();else{if(document.body.classList.contains('menu-open'))document.getElementById('menuClose').click();window.showView(view)}};nav.appendChild(b)}document.body.appendChild(nav);
  const previous=window.showView;if(typeof previous==='function')window.showView=function(v){const result=previous(v);updateNav();return result};
  if(side)new MutationObserver(updateNav).observe(side,{subtree:true,attributes:true,attributeFilter:['class','hidden'],childList:true});
  new MutationObserver(()=>{utilityActions();updateNav()}).observe(document.body,{attributes:true,attributeFilter:['class']});
  const top=document.querySelector('.topactions');if(top)new MutationObserver(utilityActions).observe(top,{childList:true});
  const auth=document.getElementById('authScreen');if(auth)new MutationObserver(decorateAuth).observe(auth,{childList:true});
  utilityActions();decorateAuth();updateNav();let saved='light';try{saved=localStorage.getItem('routeplan-business-theme')||'light'}catch{}applyTheme(saved);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
