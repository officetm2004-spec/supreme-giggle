RouteDelivery.offline().catch(e=>document.getElementById('offlineRoot').textContent='Device storage error: '+e.message);
