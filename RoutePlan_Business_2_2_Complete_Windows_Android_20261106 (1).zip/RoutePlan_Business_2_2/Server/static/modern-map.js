/* MapLibre vector map. Map tiles load only when the user opens the map. */
let crMap=null,crMapMarkers=[],crMapGeometry=null,crMapOrdered=[],crMapSignature='',crMapLoading=false;
function crMapMessage(text){const el=$('crMapStatus');if(el)el.textContent=text}
function crMapClearRoute(){crMapGeometry=null;crMapOrdered=[];if(crMap?.getSource('delivery-road'))crMap.getSource('delivery-road').setData({type:'FeatureCollection',features:[]})}
function crMapShops(){const no=Number($('crSalesman')?.value),scope=$('crScope')?.value;return (state.shops||[]).filter(s=>{const l=crLinks.find(x=>x.shop_id===s.id);return rpGpsValid(s)&&(scope==='all'||(scope==='unassigned'?!l?.salesman_no:l?.salesman_no===no))})}
function crMapSync(clear=false){
 if(!crMap)return;const shops=crMapShops();const sig=JSON.stringify([shops.map(s=>[s.id,s.latitude,s.longitude,crLinks.find(x=>x.shop_id===s.id)]),[...crSelected],$('crLat').value,$('crLon').value,$('crReturn').checked]);
 if(clear||(crMapSignature&&sig!==crMapSignature))crMapClearRoute();crMapSignature=sig;
 crMapMarkers.forEach(m=>m.remove());crMapMarkers=[];
 shops.forEach(s=>{const l=crLinks.find(x=>x.shop_id===s.id),selected=crSelected.has(s.id),verified=crVerified(s,l);const stop=crMapOrdered.findIndex(x=>x.id===s.id);
 const button=document.createElement('button');button.type='button';button.className='cr-map-pin';button.style.background='transparent';button.innerHTML=crPinSvg(selected?'selected':verified?'customer':'review');if(stop>=0){const badge=document.createElement('span');badge.className='cr-stop-badge';badge.textContent=String(stop+1);button.append(badge)}button.title=s.name;
 const content=document.createElement('div');const title=document.createElement('strong');title.textContent=s.name;content.append(title);const detail=document.createElement('p');detail.textContent=verified?'GPS confirmed':'GPS needs confirmation';content.append(detail);
 const select=document.createElement('button');select.type='button';select.textContent=selected?'Remove stop':'Select stop';select.disabled=!verified||l?.salesman_no!==Number($('crSalesman').value);select.onclick=()=>{selected?crSelected.delete(s.id):crSelected.add(s.id);crRender();crMapSync(true)};content.append(select);const remark=document.createElement('button');remark.type='button';remark.textContent='Mark location again';remark.onclick=()=>crLocationEdit(s.id);if(typeof opsProfile==='undefined'||opsProfile?.role!=='Driver')content.append(remark);
 crMapMarkers.push(new maplibregl.Marker({element:button,anchor:'bottom'}).setLngLat([Number(s.longitude),Number(s.latitude)]).setPopup(new maplibregl.Popup({offset:18}).setDOMContent(content)).addTo(crMap));
 });
 const lat=$('crLat').value,lon=$('crLon').value;if(lat!==''&&lon!==''&&Number.isFinite(Number(lat))&&Number.isFinite(Number(lon))&&Math.abs(Number(lat))<=90&&Math.abs(Number(lon))<=180){crMapMarkers.push(new maplibregl.Marker({element:crPinElement('depot'),anchor:'bottom'}).setLngLat([Number(lon),Number(lat)]).setPopup(new maplibregl.Popup().setText('Depot')).addTo(crMap))}
 crMapPaint();
}
function crMapPaint(){if(!crMap?.isStyleLoaded())return;const data=crMapGeometry?{type:'Feature',properties:{},geometry:crMapGeometry}:{type:'FeatureCollection',features:[]};if(!crMap.getSource('delivery-road')){crMap.addSource('delivery-road',{type:'geojson',data});crMap.addLayer({id:'delivery-road-line',type:'line',source:'delivery-road',paint:{'line-color':'#1265df','line-width':6,'line-opacity':.85},layout:{'line-cap':'round','line-join':'round'}})}else crMap.getSource('delivery-road').setData(data)}
function crMapFit(){if(!crMap)return;const points=crMapGeometry?.coordinates||crMapMarkers.map(m=>m.getLngLat().toArray());if(!points.length){crMap.flyTo({center:[80.7,7.8],zoom:6.5});return}const bounds=new maplibregl.LngLatBounds();points.forEach(p=>bounds.extend(p));crMap.fitBounds(bounds,{padding:45,maxZoom:15,duration:400})}
function crMapRoute(result){crMapOrdered=result.stops||[];crMapGeometry=result.geometry?.type==='LineString'?result.geometry:null;if(crMap){crMapSignature=JSON.stringify([crMapShops().map(s=>[s.id,s.latitude,s.longitude,crLinks.find(x=>x.shop_id===s.id)]),[...crSelected],$('crLat').value,$('crLon').value,$('crReturn').checked]);crMapSync();crMapPaint();crMapFit()}crMapMessage(crMapGeometry?'Calculated road route shown. Blue pins = selected stops; green = GPS confirmed; orange = needs review.':'No road geometry available. No straight lines are shown as a road route.')}
// Keep a local renderer for older Android WebViews and CDN interruptions.
let crMapLibraryMode='';
function crMapLibraryCss(href){
 let link=document.getElementById('crMapLibraryCss');
 if(!link){link=document.createElement('link');link.id='crMapLibraryCss';link.rel='stylesheet';document.head.append(link)}
 link.href=href;
}
async function crLoadMapLibrary(){
 if(window.maplibregl?.Map)return;
 crMapLibraryCss('https://unpkg.com/maplibre-gl@6.16.0/dist/maplibre-gl.css');
 try{window.maplibregl=await import('https://unpkg.com/maplibre-gl@6.16.0/dist/maplibre-gl.mjs');crMapLibraryMode='modern';return}catch(error){
  // v6 syntax cannot be parsed by some supported Android WebView versions.
  crMapLibraryCss('/vendor/maplibre-gl-4.7.1.css');
  await new Promise((resolve,reject)=>{
   const script=document.createElement('script');script.src='/vendor/maplibre-gl-4.7.1.js';
   const timer=setTimeout(()=>{script.remove();reject(Error('Map renderer timed out. Reload and retry.'))},20000);
   script.onload=()=>{clearTimeout(timer);if(window.maplibregl?.Map){crMapLibraryMode='compatibility';resolve()}else reject(Error('Map renderer did not start. Update Android System WebView.'))};
   script.onerror=()=>{clearTimeout(timer);script.remove();reject(Error('Map renderer unavailable. Reload and retry.'))};
   document.head.append(script);
  });
 }
}
async function crMapOpen(){
 if(crMap){crMap.resize();return}if(crMapLoading)return;crMapLoading=true;crMapMessage('Loading interactive map…');
 try{
 await crLoadMapLibrary();
 $('crVectorMap').hidden=false;crMap=new maplibregl.Map({container:'crVectorMap',style:'https://tiles.openfreemap.org/styles/liberty',center:[80.7,7.8],zoom:6.5,attributionControl:true});
 crMap.addControl(new maplibregl.NavigationControl(),'top-right');crMap.addControl(new maplibregl.FullscreenControl(),'top-right');crMap.addControl(new maplibregl.ScaleControl());
 crMap.on('load',()=>{crMapSync();crMapFit();crMapMessage('Map ready. Click a customer pin to select a stop. Use “Set depot on map”, then click the depot location.')});
 crMap.on('error',()=>crMapMessage('Map data could not load completely. Check internet access and retry. Customer records are available below.'));
 crMap.on('click',e=>{if(crLocationActive){crLocationPlace(e.lngLat);return}if(!$('crSetDepot').checked)return;$('crLat').value=e.lngLat.lat.toFixed(6);$('crLon').value=e.lngLat.lng.toFixed(6);$('crSetDepot').checked=false;crMapSync(true);crMapMessage('Depot selected. Calculate the road route again.')});
 }catch(e){crMapMessage(e.message);if(crMap){crMap.remove();crMap=null}}finally{crMapLoading=false}
}
function crMapInit(panel){if($('crVectorMap'))return;const box=document.createElement('div');box.innerHTML=`<div class="cr-map-heading"><strong>Interactive Delivery Map</strong><span>MapLibre · OpenFreeMap</span></div><div class="formactions"><button type="button" class="primary" id="crOpenMap">Open map</button><button type="button" class="secondary" id="crFitMap">Fit customers / route</button><label><input type="checkbox" id="crSetDepot"> Set depot on map</label></div><p class="smallnote">Open map loads online map data. Customer pins stay in this browser; routing coordinates go to the configured routing server. Blue: selected · Green: confirmed · Orange: needs GPS review · Purple: depot.</p><div id="crMapStatus" role="status">Open the map to view customers. Internet and WebGL are required.</div><div id="crVectorMap" hidden style="height:480px;width:100%;border-radius:16px;margin:12px 0"></div>`;
 panel.insertBefore(box,$('crCustomers'));$('crOpenMap').onclick=crMapOpen;$('crFitMap').onclick=crMapFit;if(window.crLocationInit)crLocationInit(box);['crLat','crLon','crReturn'].forEach(id=>$(id).addEventListener('change',()=>crMapSync(true)));
 const observer=new ResizeObserver(()=>{if(crMap&&$('crVectorMap').offsetWidth)crMap.resize()});observer.observe(box);
}
const crMapRenderOriginal=crRender;crRender=function(){crMapRenderOriginal();crMapSync()};
const mapStyle=document.createElement('style');mapStyle.textContent='.cr-map-heading{display:flex;justify-content:space-between;gap:12px;margin:20px 0 10px}.cr-map-heading span{font-size:12px;color:#55708c}.cr-map-pin{width:32px;height:32px;border:3px solid white;border-radius:50%;color:white;box-shadow:0 3px 12px #0004;padding:0;font-weight:bold}.maplibregl-popup-content{color:#142b45;max-width:240px}.maplibregl-ctrl button{min-width:0}.maplibregl-ctrl-attrib{font-size:11px}@media(max-width:550px){#crVectorMap{height:360px!important}.cr-map-heading{flex-wrap:wrap}}';document.head.append(mapStyle);

if($('crCustomers'))crMapInit($('crCustomers').closest('.panel'));
