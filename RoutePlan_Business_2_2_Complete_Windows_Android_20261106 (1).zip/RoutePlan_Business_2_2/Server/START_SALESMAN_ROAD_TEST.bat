@echo off
cd /d "%~dp0"
set "ROUTEPLAN_PORT=8082"
set "ROUTEPLAN_DATA_DIR=%~dp0data_release_candidate_test"
if not defined ROUTEPLAN_OSRM_URL set /p "ROUTEPLAN_OSRM_URL=Enter OSRM server URL (blank disables road calculations): "
echo Open http://localhost:8082 and go to Shop Directory.
python server.py
pause
